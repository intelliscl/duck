import { QueryRunner } from "../../query-runner/QueryRunner";
import { TableColumn } from "../../schema-builder/table/TableColumn";
import { Table } from "../../schema-builder/table/Table";
import { TableForeignKey } from "../../schema-builder/table/TableForeignKey";
import { TableIndex } from "../../schema-builder/table/TableIndex";
import { View } from "../../schema-builder/view/View";
import { DuckDBDriver } from "./DuckDBDriver";
import { ReadStream } from "../../platform/PlatformTools";
import { TableUnique } from "../../schema-builder/table/TableUnique";
import { BaseQueryRunner } from "../../query-runner/BaseQueryRunner";
import { OrmUtils } from "../../util/OrmUtils";
import { TableCheck } from "../../schema-builder/table/TableCheck";
import { IsolationLevel } from "../types/IsolationLevel";
import { TableExclusion } from "../../schema-builder/table/TableExclusion";
import { QueryFailedError } from "../../error/QueryFailedError";
import { ReplicationMode } from "../types/ReplicationMode";
import { Broadcaster } from "../../subscriber/Broadcaster";
import { InstanceChecker } from "../../util/InstanceChecker";
import { ObjectLiteral } from "../../common/ObjectLiteral";
import { QueryResult } from "../../query-runner/QueryResult";
import { BroadcasterResult } from "../../subscriber/BroadcasterResult";
import { QueryRunnerAlreadyReleasedError } from "../../error/QueryRunnerAlreadyReleasedError";
import { MetadataTableType } from "../types/MetadataTableType"
import { TableIndexOptions } from "../../schema-builder/options/TableIndexOptions"
import { Query } from "../Query"
import { TypeORMError } from "../../error"
import { ColumnType } from "../../driver/types/ColumnTypes"


/**
 * Runs queries on a single DuckDB database connection.
 */
export class DuckDBQueryRunner extends BaseQueryRunner implements QueryRunner {

    // -------------------------------------------------------------------------
    // Public Implemented Properties
    // -------------------------------------------------------------------------
    /**
     * Database driver used by connection.
     */
    driver: DuckDBDriver;


    // -------------------------------------------------------------------------
    // Protected Properties
    // -------------------------------------------------------------------------
    /**
     * Database connection used by this query runner.
     */
    protected databaseConnection: any;

    /**
     * Special callback provided by a driver used to release a created connection.
     */
    protected releaseCallback: Function | undefined;

    /**
     * Indicates if connection for this query runner is released.
     * Once its released, query runner cannot run queries anymore.
     */
    protected _isReleased = false;

    /**
     * Indicates if transaction is in progress.
     */
    protected _isTransactionActive = false;

    /**
     * Stores all executed queries to be able to run them again if transaction fails.
     */
    protected queries: { query: string; parameters?: any[] }[] = []


    /**
     * Indicates if running queries must be stored
     */
    protected storeQueries: boolean = false

    /**
     * Current number of transaction retries in case of 40001 error.
     */
    protected transactionRetries: number = 0

    // -------------------------------------------------------------------------
    // Constructor
    // -------------------------------------------------------------------------

    constructor(driver: DuckDBDriver, mode: ReplicationMode) {
        super();
        this.driver = driver;
        this.connection = driver.duckdbConnection;
        this.mode = mode;
        this.broadcaster = new Broadcaster(this);
        this.driver.connectedQueryRunners.push(this);
    }

    // -------------------------------------------------------------------------
    // Public Methods
    // -------------------------------------------------------------------------


    async connect(): Promise<any> {
    // Always return the single DuckDB connection instance
    return this.connection;
}


    async release(): Promise<void> {
        if (this.isReleased) return;
        this.isReleased = true;
        // Remove from driver's list
        const idx = this.driver.connectedQueryRunners.indexOf(this);
        if (idx !== -1) this.driver.connectedQueryRunners.splice(idx, 1);
        // Do not close the connection (shared)
    }






    async startTransaction(isolationLevel?: IsolationLevel): Promise<void> {
    if (this.isTransactionActive)
        throw new QueryFailedError(
            "Transaction already started",
            [],
            new Error("Transaction already started")
        );

    // Before starting a transaction
    await this.broadcaster.broadcast("BeforeTransactionStart");
    await this.query("BEGIN TRANSACTION");
    this._isTransactionActive = true;
    // After starting a transaction
    await this.broadcaster.broadcast("AfterTransactionStart");
}


async commitTransaction(): Promise<void> {
    if (!this.isTransactionActive)
        throw new QueryFailedError(
            "Transaction is not started yet",
            [],
            new Error("Transaction is not started yet")
        );

    // Before committing a transaction
    await this.broadcaster.broadcast("BeforeTransactionCommit");
    await this.query("COMMIT");
    this._isTransactionActive = false;
    // After committing a transaction
    await this.broadcaster.broadcast("AfterTransactionCommit");
}




async rollbackTransaction(): Promise<void> {
    if (!this.isTransactionActive)
        throw new QueryFailedError(
            "Transaction is not started yet",
            [],
            new Error("Transaction is not started yet")
        );

    // Before rolling back a transaction
    await this.broadcaster.broadcast("BeforeTransactionRollback");
    await this.query("ROLLBACK");
    this._isTransactionActive = false;
    // After rolling back a transaction
    await this.broadcaster.broadcast("AfterTransactionRollback");
}




async query(
        query: string,
        parameters?: any[],
        useStructuredResult: boolean = false,
    ): Promise<any> {
        if (this.isReleased) throw new QueryRunnerAlreadyReleasedError();

        const databaseConnection = await this.connect();
        const broadcasterResult = new BroadcasterResult();

        this.driver.connection.logger.logQuery(query, parameters, this);
        this.broadcaster.broadcastBeforeQueryEvent(
            broadcasterResult,
            query,
            parameters,
        );

        try {
            const queryStartTime = +new Date();
            // Use the efficient DuckDB query API
            const raw = await databaseConnection.query(query, parameters);

            const queryEndTime = +new Date();
            const queryExecutionTime = queryEndTime - queryStartTime;
            const maxQueryExecutionTime = this.driver.options.maxQueryExecutionTime;

            this.broadcaster.broadcastAfterQueryEvent(
                broadcasterResult,
                query,
                parameters,
                true,
                queryExecutionTime,
                raw,
                undefined,
            );

            if (
                maxQueryExecutionTime &&
                queryExecutionTime > maxQueryExecutionTime
            ) {
                this.driver.connection.logger.logQuerySlow(
                    queryExecutionTime,
                    query,
                    parameters,
                    this,
                );
            }

            // Build QueryResult
            const result = new QueryResult();
            if (raw) {
                // duckdb-node-neo returns { rows, rowCount }
                result.records = raw.rows ?? [];
                result.affected = raw.rowCount ?? undefined;
                result.raw = raw;
                if (!useStructuredResult) {
                    return result.records;
                }
            }

            return result;
        } catch (err) {
            this.driver.connection.logger.logQueryError(
                err,
                query,
                parameters,
                this,
            );
            this.broadcaster.broadcastAfterQueryEvent(
                broadcasterResult,
                query,
                parameters,
                false,
                undefined,
                undefined,
                err,
            );
            throw new QueryFailedError(query, parameters, err);
        } finally {
            await broadcasterResult.wait();
        }
    }



    /**
     * Prepares given value to a value to be persisted, based on its column type.
     */
    prepareHydratedValue(value: any, columnMetadata: { type: string }): any {
        if (value === null || value === undefined) {
            return value;
        }

        switch (columnMetadata.type) {
            case "boolean":
                return !!value;
            case "datetime":
            case "timestamp":
                return typeof value === "string" ? new Date(value) : value;
            case "date":
                return typeof value === "string" ? new Date(value) : value;
            case "time":
                return typeof value === "string" ? value : value;
            case "decimal":
            case "numeric":
                return typeof value === "string" ? parseFloat(value) : value;
            case "int":
            case "integer":
            case "smallint":
            case "bigint":
                return typeof value === "string" ? parseInt(value) : value;
            default:
                return value;
        }
    }


    /**
     * Streams results using DuckDB's stream API.
     */
    async stream(
        query: string,
        parameters?: any[],
        onEnd?: Function,
        onError?: Function,
    ): Promise<ReadStream> {
        if (this.isReleased) throw new QueryRunnerAlreadyReleasedError();

        const databaseConnection = await this.connect();
        this.driver.connection.logger.logQuery(query, parameters, this);

        // Use DuckDB's stream API (duckdb-node-neo)
        const stream = databaseConnection.stream(query, parameters);

        if (onEnd) stream.on("end", onEnd);
        if (onError) stream.on("error", onError);

        return stream;
    }




    async getDatabases(): Promise<string[]> {
        return [this.driver.database || ":memory:"];
    }


    async getSchemas(): Promise<string[]> {
        const result = await this.query("select schema_name from duckdb_schemas()");
        return result.map((row: any) => row.schema_name);
    }




    async hasDatabase(database: string): Promise<boolean> {
        return database === this.driver.database || database === ":memory:";
    }


        /**
     * Returns the name of the current database.
     * For DuckDB, this is the database file name or ":memory:".
     */
    async getCurrentDatabase(): Promise<string | undefined> {
        // DuckDB only has a single database per connection
        return this.driver.database || ":memory:";
    }


    /**
     * Checks if a schema with the given name exists.
     */
    async hasSchema(schema: string): Promise<boolean> {
    const result = await this.query(
        `SELECT COUNT(*) as count FROM from duckdb_schemas() WHERE schema_name = ?`,
        [schema]
    );
    return result[0]?.count > 0;
    }


    async getCurrentSchema(): Promise<string | undefined> {
        const result = await this.query(`SELECT current_schema`);
        return result[0]?.current_schema;
    }



    async hasTable(tableName: string): Promise<boolean> {
        const result = await this.query(
            `SELECT EXISTS (
                SELECT 1 FROM sqlite_master
                WHERE type = 'table' AND name = ?
            )`,
            [tableName]
        );
        return result[0]["EXISTS (SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?)"] === true;
    }



        async hasColumn(tableName: string, columnName: string): Promise<boolean> {
        const result = await this.query(`PRAGMA table_info('${tableName}')`);
        return !!result.find((column: any) => column.name === columnName);
    }

   async createDatabase(database: string, ifNotExist?: boolean): Promise<void> {
        throw new Error("Creating new databases is not supported in DuckDB.");
    }



    async dropDatabase(database: string, ifExist?: boolean): Promise<void> {
        throw new
         Error("Dropping databases is not supported in DuckDB.");
    }

    /**
     * Gets all tables from the database.
     */
    async getTables(): Promise<Table[]> {
    const tableNames: { name: string }[] = await this.query(
        `select table_name From FROM duckdb_tables()`
    );

    return Promise.all(tableNames.map(async (row) => {
        const table = await this.getTable(row.name);
        return table!;
    }));
}







       /**
        * Creates a new table schema.
        */
       async createSchema(
           schemaPath: string,
           ifNotExist?: boolean,
       ): Promise<void> {
           const schema =
               schemaPath.indexOf(".") === -1
                   ? schemaPath
                   : schemaPath.split(".")[1]

           const up = ifNotExist
               ? `CREATE SCHEMA IF NOT EXISTS "${schema}"`
               : `CREATE SCHEMA "${schema}"`
           const down = `DROP SCHEMA "${schema}" CASCADE`
           await this.executeQueries(new Query(up), new Query(down))
       }
      /**
       * Drops table schema.
       */
      async dropSchema(
          schemaPath: string,
          ifExist?: boolean,
          isCascade?: boolean,
      ): Promise<void> {
          const schema =
              schemaPath.indexOf(".") === -1
                  ? schemaPath
                  : schemaPath.split(".")[1]

          const up = ifExist
              ? `DROP SCHEMA IF EXISTS "${schema}" ${isCascade ? "CASCADE" : ""}`
              : `DROP SCHEMA "${schema}" ${isCascade ? "CASCADE" : ""}`
          const down = `CREATE SCHEMA "${schema}"`
          await this.executeQueries(new Query(up), new Query(down))
      }



          async createTable(table: Table, ifNotExist: boolean = false, createForeignKeys: boolean = true): Promise<void> {
        const upQueries: string[] = [];
        const downQueries: string[] = [];

        for (const column of table.columns) {
            if (column.type === "enum" && column.enumName && column.enum) {
                await this.createEnumTypeSql(table, column);
            }
        }

        if (ifNotExist) {
            upQueries.push(`CREATE TABLE IF NOT EXISTS "${table.name}" (`);
        } else {
            upQueries.push(`CREATE TABLE "${table.name}" (`);
        }

        const columnDefinitions = table.columns.map(column => {
        let columnDefinition = `"${column.name}" ${this.driver.createFullType(column)}`;

        if (column.collation)
            columnDefinition += ` COLLATE ${column.collation}`;

        if (column.isNullable !== true)
            columnDefinition += " NOT NULL";

        if (column.default !== undefined && column.default !== null)
            columnDefinition += ` DEFAULT ${column.default}`;

        if (column.isPrimary)
            columnDefinition += " PRIMARY KEY";

        if (column.isGenerated && column.generationStrategy === "increment")
            columnDefinition += " AUTOINCREMENT";

        return columnDefinition;
    }).join(", ");

        upQueries[0] += columnDefinitions;

        // add foreign keys
        if (createForeignKeys && table.foreignKeys.length > 0) {
            const foreignKeyDefinitions = table.foreignKeys.map(fk => {
                const columnNames = fk.columnNames.map(column => `"${column}"`).join(", ");
                const referencedColumnNames = fk.referencedColumnNames.map(column => `"${column}"`).join(", ");
                let constraint = `CONSTRAINT "${fk.name}" FOREIGN KEY (${columnNames}) REFERENCES "${fk.referencedTableName}" (${referencedColumnNames})`;
                if (fk.onDelete)
                    constraint += ` ON DELETE ${fk.onDelete}`;
                if (fk.onUpdate)
                    constraint += ` ON UPDATE ${fk.onUpdate}`;

                return constraint;
            }).join(", ");

            upQueries[0] += `, ${foreignKeyDefinitions}`;
        }

        // add unique constraints
        if (table.uniques.length > 0) {
            const uniqueDefinitions = table.uniques.map(unique => {
                const columnNames = unique.columnNames.map(column => `"${column}"`).join(", ");
                return `CONSTRAINT "${unique.name}" UNIQUE (${columnNames})`;
            }).join(", ");

            upQueries[0] += `, ${uniqueDefinitions}`;
        }

        // add check constraints
        if (table.checks.length > 0) {
            const checkDefinitions = table.checks.map(check => {
                return `CONSTRAINT "${check.name}" CHECK (${check.expression})`;
            }).join(", ");

            upQueries[0] += `, ${checkDefinitions}`;
        }

        upQueries[0] += ")";
        downQueries.push(`DROP TABLE "${table.name}"`);

        // execute queries
        for (const upQuery of upQueries) {
            await this.query(upQuery);
        }
    }


    /**
     * Drops a table.
     */
    async dropTable(
    target: Table | string,
    ifExist?: boolean,
    dropIndices: boolean = true,
): Promise<void> {
    if (ifExist) {
        const tableName = InstanceChecker.isTable(target) ? target.name : target;
        const isTableExist = await this.hasTable(tableName)
        if (!isTableExist) return Promise.resolve()
    }
    const tablePath = this.getTablePath(target)
    const table = await this.getCachedTable(tablePath)
    const upQueries: Query[] = []
    const downQueries: Query[] = []

    if (dropIndices) {
        table.indices.forEach((index) => {
            upQueries.push(this.dropIndexSql(table, index))
            downQueries.push(this.createIndexSql(table, index))
        })
    }

    upQueries.push(this.dropTableSql(table))
    downQueries.push(this.createTableSql(table, false)) // no foreign keys

    // DuckDB does not support generated columns metadata the same way, skip this part

    await this.executeQueries(upQueries, downQueries)
}



    /**
     * Creates a new view.
     */
    async createView(
        view: View,
        syncWithMetadata: boolean = false,
    ): Promise<void> {
        const upQueries: Query[] = []
        const downQueries: Query[] = []
        upQueries.push(this.createViewSql(view))
        if (syncWithMetadata)
            upQueries.push(await this.insertViewDefinitionSql(view))
        downQueries.push(this.dropViewSql(view))
        if (syncWithMetadata)
            downQueries.push(await this.deleteViewDefinitionSql(view))
        await this.executeQueries(upQueries, downQueries)
    }

    /**
     * Drops the view.
     */
    async dropView(target: View | string): Promise<void> {
        const viewName = InstanceChecker.isView(target) ? target.name : target
        const view = await this.getCachedView(viewName)

        const upQueries: Query[] = []
        const downQueries: Query[] = []
        upQueries.push(await this.deleteViewDefinitionSql(view))
        upQueries.push(this.dropViewSql(view))
        downQueries.push(await this.insertViewDefinitionSql(view))
        downQueries.push(this.createViewSql(view))
        await this.executeQueries(upQueries, downQueries)
    }


       /**
     * Renames a table.
     */
async renameTable(
    oldTableOrName: Table | string,
    newTableName: string,
): Promise<void> {
    const upQueries: Query[] = []
    const downQueries: Query[] = []

    const oldTable = InstanceChecker.isTable(oldTableOrName)
        ? oldTableOrName
        : await this.getCachedTable(oldTableOrName)

    const newTable = oldTable.clone()

    const { schema: schemaName, tableName: oldTableName } =
        this.driver.parseTableName(oldTable)

    newTable.name = schemaName
        ? `${schemaName}.${newTableName}`
        : newTableName

    upQueries.push(
        new Query(
            `ALTER TABLE ${this.escapePath(oldTable)} RENAME TO "${newTableName}"`,
        ),
    )
    downQueries.push(
        new Query(
            `ALTER TABLE ${this.escapePath(newTable)} RENAME TO "${oldTableName}"`,
        ),
    )

    // DuckDB does not support renaming constraints or sequences, skip that part.

    await this.executeQueries(upQueries, downQueries)
}



/**
 * Adds a new column to a table in DuckDB.
 */
/**
 * Adds a new column to a table in DuckDB.
 */
async addColumn(tableOrName: Table | string, column: TableColumn): Promise<void> {
    // Get the table name
    const tableName = InstanceChecker.isTable(tableOrName)
        ? tableOrName.name
        : tableOrName;

    // Escape the table name using the driver's escape method
    const escapedTableName = this.driver.escape(tableName);

    // Start building the query
    let addColumnSql = `ALTER TABLE ${escapedTableName} ADD COLUMN `;

    // Handle generated (virtual) columns
    if (column.generatedType && column.asExpression) {
        addColumnSql += `${this.driver.escape(column.name)}`;

        // Optionally add the type if specified
        if (column.type) {
            addColumnSql += ` ${this.driver.createFullType(column)}`;
        }

        // Add GENERATED ALWAYS syntax if specified
        if (column.generatedType === "STORED" || column.generatedType === "VIRTUAL") {
            addColumnSql += ` GENERATED ALWAYS`;
        }

        // Add the expression
        addColumnSql += ` AS (${column.asExpression})`;

        // Add VIRTUAL explicitly if requested
        if (column.generatedType === "VIRTUAL") {
            addColumnSql += ` VIRTUAL`;
        } else if (column.generatedType === "STORED") {
            // DuckDB doesn't support STORED, show a warning
            this.driver.connection.logger.log('warn',
                "DuckDB only supports VIRTUAL generated columns. STORED is not supported and will be ignored."
            );
        }
    } else {
        // Standard column definition
        addColumnSql += `${this.driver.escape(column.name)} ${this.driver.createFullType(column)}`;

        // Default value - DuckDB supports this directly in ALTER TABLE ADD COLUMN
        if (column.default !== undefined && column.default !== null) {
            addColumnSql += ` DEFAULT ${column.default}`;
        }

        // NOT NULL constraint - DuckDB supports this directly
        if (column.isNullable !== true) {
            addColumnSql += " NOT NULL";
        }
    }

    // Prepare up/down queries arrays as per TypeORM convention
    const upQueries: Query[] = [];
    const downQueries: Query[] = [];

    // Add the add column SQL to upQueries
    upQueries.push(new Query(addColumnSql));

    // For downQueries, drop the column (DuckDB supports DROP COLUMN)
    downQueries.push(new Query(
        `ALTER TABLE ${escapedTableName} DROP COLUMN ${this.driver.escape(column.name)}`
    ));

    // Handle primary key and unique constraints
    // Note: Per DuckDB docs, we can add a PRIMARY KEY with ALTER TABLE but not UNIQUE
    if (column.isPrimary) {
        upQueries.push(
            new Query(
                `ALTER TABLE ${escapedTableName} ADD PRIMARY KEY (${this.driver.escape(column.name)})`
            )
        );
        // Down: DuckDB doesn't support dropping PK directly, so this is a no-op or requires table recreation
    } else if (column.isUnique) {
        // For unique constraint, since ALTER TABLE ADD CONSTRAINT is not supported,
        // we need to use the table recreation approach (not implemented here for brevity)
        // You may want to call your recreateTableWithUniqueConstraint helper here.
        this.driver.connection.logger.log('warn',
            "DuckDB does not support adding UNIQUE constraints via ALTER TABLE. " +
            "You must recreate the table to add a unique constraint."
        );
    }

    // Execute the queries
    await this.executeQueries(upQueries, downQueries);
}

    /**
     * Creates a new columns from the column in the table.
     */
    async addColumns(
        tableOrName: Table | string,
        columns: TableColumn[],
    ): Promise<void> {
        for (const column of columns) {
            await this.addColumn(tableOrName, column)
        }
    }
    /**
     * Renames column in the given table.
     */
async renameColumn(
    tableOrName: Table | string,
    oldColumnOrName: TableColumn | string,
    newColumnOrName: TableColumn | string,
): Promise<void> {
    const table = InstanceChecker.isTable(tableOrName)
        ? tableOrName
        : await this.getCachedTable(tableOrName);

    const oldColumn = InstanceChecker.isTableColumn(oldColumnOrName)
        ? oldColumnOrName
        : table.columns.find(c => c.name === oldColumnOrName);

    if (!oldColumn)
        throw new TypeORMError(
            `Column "${oldColumnOrName}" was not found in table "${table.name}".`
        );

    let newColumn: TableColumn;
    if (InstanceChecker.isTableColumn(newColumnOrName)) {
        newColumn = newColumnOrName;
    } else {
        newColumn = oldColumn.clone();
        newColumn.name = newColumnOrName;
    }

    // Use DuckDB's native rename column statement
    const tableName = this.getTablePath(table);
    const upQuery = `ALTER TABLE ${this.escapePath(tableName)} RENAME COLUMN "${oldColumn.name}" TO "${newColumn.name}"`;
    const downQuery = `ALTER TABLE ${this.escapePath(tableName)} RENAME COLUMN "${newColumn.name}" TO "${oldColumn.name}"`;

    await this.executeQueries([new Query(upQuery)], [new Query(downQuery)]);

    // Update column in in-memory Table object if you're using metadata caching
    const columnIndex = table.columns.findIndex(col => col.name === oldColumn.name);
    if (columnIndex !== -1) {
        table.columns[columnIndex] = newColumn;
    }
}



    /**
     * Changes a column in the table.
     * Note: DuckDB doesn't support direct column alterations like many other DBs.
     * Instead, we need to create a new table, copy data, and drop the old table.
     */
    async changeColumn(tableOrName: Table | string, oldColumnOrName: TableColumn | string, newColumn: TableColumn): Promise<void> {
        // This is a complex operation since SQLite and DuckDB don't support ALTER COLUMN
        // We need to:
        // 1. Create a new table with the desired schema
        // 2. Copy data from the old table
        // 3. Drop the old table
        // 4. Rename the new table to the old table name

        const tableName = InstanceChecker.isTable(tableOrName) ? tableOrName.name : tableOrName;

        // Get the existing table definition
        const table = await this.getTable(tableName);
        if (!table)
            throw new Error(`Table "${tableName}" does not exist.`);

        const oldColumnName = InstanceChecker.isTableColumn(oldColumnOrName) ? oldColumnOrName.name : oldColumnOrName;
        const oldColumn = table.columns.find(column => column.name === oldColumnName);
        if (!oldColumn)
            throw new Error(`Column "${oldColumnName}" does not exist in table "${tableName}".`);

        // Create a temporary table name
        const tempTableName = `${tableName}_temp_${Date.now()}`;

        // Create a new table with the same schema but with the changed column
        const newTable = table.clone();
        newTable.name = tempTableName;

        // Replace the old column with the new one
        const newColumnIndex = newTable.columns.findIndex(column => column.name === oldColumnName);
        if (newColumnIndex !== -1) {
            newTable.columns[newColumnIndex] = newColumn;
        }

        // Start a transaction for the multi-step process
        await this.startTransaction();

        try {
            // Create the new table
            await this.createTable(newTable);

            // Generate column names list for the INSERT statement
            const columnNames = table.columns.map(column => `"${column.name}"`).join(", ");

            // Generate a mapping expression for each column
            const columnMapping = table.columns.map(column => {
                if (column.name === oldColumnName) {
                    // If types are compatible, do a direct copy
                    // For more complex type conversions, we may need specific CAST expressions
                    return `"${column.name}"`;
                }
                return `"${column.name}"`;
            }).join(", ");

            // Copy data
            await this.query(`INSERT INTO "${tempTableName}" (${columnNames}) SELECT ${columnMapping} FROM "${tableName}"`);

            // Drop the old table
            await this.dropTable(tableName);

            // Rename the new table to the old table name
            await this.renameTable(tempTableName, tableName);

            // Commit the transaction
            await this.commitTransaction();
        } catch (error) {
            // Rollback in case of any error
            await this.rollbackTransaction();
            throw error;
        }
    }





    /**
     * Changes a column in the table.
     */
    async changeColumns(tableOrName: Table | string, changedColumns: { oldColumn: TableColumn, newColumn: TableColumn }[]): Promise<void> {
        // This operation is complex for DuckDB since it requires recreating the table
        // It's better to do all column changes at once in a single table recreation
        const tableName = InstanceChecker.isTable(tableOrName) ? tableOrName.name : tableOrName;

        // Get the existing table definition
        const table = await this.getTable(tableName);
        if (!table)
            throw new Error(`Table "${tableName}" does not exist.`);

        // Create a temporary table name
        const tempTableName = `${tableName}_temp_${Date.now()}`;

        // Create a new table with the same schema but with all changed columns
        const newTable = table.clone();
        newTable.name = tempTableName;

        // Replace all old columns with new ones
        for (const { oldColumn, newColumn } of changedColumns) {
            const oldColumnName = InstanceChecker.isTableColumn(oldColumn) ? oldColumn.name : oldColumn;
            const newColumnIndex = newTable.columns.findIndex(column => column.name === oldColumnName);
            if (newColumnIndex !== -1) {
                newTable.columns[newColumnIndex] = newColumn;
            }
        }

        // Start a transaction for the multi-step process
        await this.startTransaction();

        try {
            // Create the new table
            await this.createTable(newTable);

            // Generate column names list for the INSERT statement
            const columnNames = table.columns.map(column => `"${column.name}"`).join(", ");

            // Copy data
            await this.query(`INSERT INTO "${tempTableName}" (${columnNames}) SELECT ${columnNames} FROM "${tableName}"`);

            // Drop the old table
            await this.dropTable(tableName);

            // Rename the new table to the old table name
            await this.renameTable(tempTableName, tableName);

            // Commit the transaction
            await this.commitTransaction();
        } catch (error) {
            // Rollback in case of any error
            await this.rollbackTransaction();
            throw error;
        }
    }


        /**
     * Drops column in the table.
     */
    async dropColumn(tableOrName: Table | string, columnOrName: TableColumn | string): Promise<void> {
        const tableName = InstanceChecker.isTable(tableOrName) ? tableOrName.name : tableOrName;
        const columnName = InstanceChecker.isTableColumn(columnOrName) ? columnOrName.name : columnOrName;

        // DuckDB supports DROP COLUMN since it's based on a newer SQLite
        await this.query(`ALTER TABLE "${tableName}" DROP COLUMN "${columnName}"`);
    }




    /**
     * Drops columns in the table.
     */
    async dropColumns(tableOrName: Table | string, columns: TableColumn[] | string[]): Promise<void> {
        for (const column of columns) {
            await this.dropColumn(tableOrName, column);
        }
    }

   /**
     * Creates a new primary key.
     */
    async createPrimaryKey(
        tableOrName: Table | string,
        columnNames: string[],
        constraintName?: string,
    ): Promise<void> {
        const upQueries: Query[] = []
        const downQueries: Query[] = []
        const table = InstanceChecker.isTable(tableOrName)
            ? tableOrName
            : await this.getCachedTable(tableOrName)
        const clonedTable = table.clone()

        upQueries.push (this.createPrimaryKeySql(table, columnNames, constraintName) )

        // mark columns as primary, because dropPrimaryKeySql build constraint name from table primary column names.
        clonedTable.columns.forEach((column) => {
            if (columnNames.find((columnName) => columnName === column.name))
                column.isPrimary = true
        })
        downQueries.push(...this.dropPrimaryKeySql(clonedTable))

        await this.executeQueries(upQueries, downQueries)
        this.replaceCachedTable(table, clonedTable)
    }





        /**
     * Drops a primary key.
     */
    async dropPrimaryKey(tableOrName: Table | string): Promise<void> {
        // DuckDB doesn't support dropping a primary key constraint after table creation
        // We need to recreate the table without the primary key
        const tableName = InstanceChecker.isTable(tableOrName) ? tableOrName.name : tableOrName;

        // Get the existing table definition
        const table = await this.getTable(tableName);
        if (!table)
            throw new Error(`Table "${tableName}" does not exist.`);

        // Update the column definitions to remove the primary key
        for (const column of table.columns) {
            if (column.isPrimary) {
                column.isPrimary = false;
            }
        }
    }


/**
 * Updates composite primary keys for DuckDB.
 */
async updatePrimaryKeys(
    tableOrName: Table | string,
    columns: TableColumn[],
): Promise<void> {
    const table = InstanceChecker.isTable(tableOrName)
        ? tableOrName
        : await this.getCachedTable(tableOrName);
    const clonedTable = table.clone();
    const columnNames = columns.map((column) => column.name);
    const upQueries: Query[] = [];
    const downQueries: Query[] = [];

    // If table already has primary columns, we must recreate the table without them
    // because DuckDB doesn't support DROP CONSTRAINT
    const primaryColumns = clonedTable.primaryColumns;
    if (primaryColumns.length > 0) {
        // Create a temporary table without the primary key constraint
        const tempTable = new Table();
        tempTable.name = `temp_${table.name}`;
        tempTable.schema = table.schema;
        tempTable.database = table.database;

        // Generate column definitions without the primary key constraint
        const columnDefs = table.columns
            .map(column => {
                const columnName = `"${column.name}"`;
                const columnType = this.connection.driver.normalizeType(column);
                const nullability = column.isNullable ? '' : ' NOT NULL';
                const defaultValue = column.default !== undefined
                    ? ` DEFAULT ${column.default}`
                    : '';

                return `${columnName} ${columnType}${nullability}${defaultValue}`;
            })
            .join(', ');

        // Add unique constraints if they exist
        let uniqueConstraintsSql = '';
        if (table.uniques && table.uniques.length > 0) {
            for (const unique of table.uniques) {
                const uniqueColumnNames = unique.columnNames
                    .map((column) => `"${column}"`)
                    .join(", ");

                uniqueConstraintsSql += `, CONSTRAINT "${unique.name}" UNIQUE (${uniqueColumnNames})`;
            }
        }

        // Add check constraints if they exist
        let checkConstraintsSql = '';
        if (table.checks && table.checks.length > 0) {
            for (const check of table.checks) {
                checkConstraintsSql += `, CONSTRAINT "${check.name}" CHECK (${check.expression})`;
            }
        }

        // Add foreign keys if they exist
        let foreignKeysSql = '';
        if (table.foreignKeys && table.foreignKeys.length > 0) {
            for (const fk of table.foreignKeys) {
                const fkColumnNames = fk.columnNames
                    .map((column) => `"${column}"`)
                    .join(", ");
                const fkReferencedColumnNames = fk.referencedColumnNames
                    .map((column) => `"${column}"`)
                    .join(",");

                foreignKeysSql += `, CONSTRAINT "${fk.name}" FOREIGN KEY (${fkColumnNames}) ` +
                    `REFERENCES ${this.escapePath(this.getTablePath(fk))}(${fkReferencedColumnNames})`;

                if (fk.onDelete) foreignKeysSql += ` ON DELETE ${fk.onDelete}`;
                if (fk.onUpdate) foreignKeysSql += ` ON UPDATE ${fk.onUpdate}`;
                if (fk.deferrable) foreignKeysSql += ` DEFERRABLE ${fk.deferrable}`;
            }
        }

        // Add queries to recreate the table without the primary key
        upQueries.push(
            new Query(
                `CREATE TABLE ${this.escapePath(tempTable)} (${columnDefs}${uniqueConstraintsSql}${checkConstraintsSql}${foreignKeysSql})`
            ),
            new Query(
                `INSERT INTO ${this.escapePath(tempTable)} SELECT * FROM ${this.escapePath(table)}`
            ),
            new Query(
                `DROP TABLE ${this.escapePath(table)}`
            ),
            new Query(
                `ALTER TABLE ${this.escapePath(tempTable)} RENAME TO "${table.name}"`
            )
        );


        const primaryColumnNamesString = primaryColumns
            .map((column) => `"${column.name}"`)
            .join(", ");

        downQueries.push(
            new Query(
                `ALTER TABLE ${this.escapePath(table)} ADD PRIMARY KEY (${primaryColumnNamesString})`
            )
        );
    }

    // update columns in table
    clonedTable.columns
        .filter((column) => columnNames.indexOf(column.name) !== -1)
        .forEach((column) => (column.isPrimary = true));

    // Add the new primary key
    const columnNamesString = columnNames
        .map((columnName) => `"${columnName}"`)
        .join(", ");

    upQueries.push(
        new Query(
            `ALTER TABLE ${this.escapePath(table)} ADD PRIMARY KEY (${columnNamesString})`
        )
    );

    // Add down query to drop the new primary key (using the table recreation approach)
    downQueries.push(
        new Query(
            `CREATE TABLE temp_drop_pk AS SELECT * FROM ${this.escapePath(table)}`
        ),
        new Query(
            `DROP TABLE ${this.escapePath(table)}`
        ),
        new Query(
            `CREATE TABLE ${this.escapePath(table)} AS SELECT * FROM temp_drop_pk`
        ),
        new Query(
            `DROP TABLE temp_drop_pk`
        )
    );

    await this.executeQueries(upQueries, downQueries);
    this.replaceCachedTable(table, clonedTable);
}

    async createUniqueConstraint(tableOrName: Table | string, uniqueConstraint: TableUnique): Promise<void> {
    // Get the table object either directly or from cache
    const table = InstanceChecker.isTable(tableOrName)
        ? tableOrName
        : await this.getCachedTable(tableOrName);

    const tableName = table.name;

    // Generate constraint name if not provided
    if (!uniqueConstraint.name) {
        uniqueConstraint.name = this.connection.namingStrategy.uniqueConstraintName(
            table,
            uniqueConstraint.columnNames,
        );
    }

    // In DuckDB, we need to handle unique constraints differently
    // There are two approaches:
    // 1. Using ALTER TABLE to add a constraint (if supported in your DuckDB version)
    // 2. Creating a unique index (which enforces uniqueness)

    // Approach 1: Try to add constraint via ALTER TABLE (preferred if available)
    const columnNames = uniqueConstraint.columnNames.map(column => `"${column}"`).join(", ");

    try {
        // First approach: Using ALTER TABLE (works in newer DuckDB versions)
        const up = `ALTER TABLE "${tableName}" ADD CONSTRAINT "${uniqueConstraint.name}" UNIQUE (${columnNames})`;
        const down = `ALTER TABLE "${tableName}" DROP CONSTRAINT IF EXISTS "${uniqueConstraint.name}"`;

        await this.executeQueries(new Query(up), new Query(down));
    } catch (error) {
        // Fallback approach: If ALTER TABLE fails, create a unique index
        // This is compatible with older DuckDB versions
        const up = `CREATE UNIQUE INDEX "${uniqueConstraint.name}" ON "${tableName}" (${columnNames})`;
        const down = `DROP INDEX IF EXISTS "${uniqueConstraint.name}"`;

        await this.executeQueries(new Query(up), new Query(down));
    }

    // Update the table metadata to include this constraint
    table.addUniqueConstraint(uniqueConstraint);
}


    /**
     * Creates new unique constraints.
     */
    async createUniqueConstraints(tableOrName: Table | string, uniqueConstraints: TableUnique[]): Promise<void> {
        for (const uniqueConstraint of uniqueConstraints) {
            await this.createUniqueConstraint(tableOrName, uniqueConstraint);
        }
    }


/**
 * Drops an unique constraint.
 */
async dropUniqueConstraint(tableOrName: Table | string, uniqueOrName: TableUnique | string): Promise<void> {
    // Get table name and constraint name
    const table = InstanceChecker.isTable(tableOrName)
        ? tableOrName
        : await this.getCachedTable(tableOrName);
    const uniqueName = InstanceChecker.isTableUnique(uniqueOrName) ? uniqueOrName.name : uniqueOrName;

    try {
        // First approach: Try to drop constraint via ALTER TABLE (for newer DuckDB versions)
        const up = `ALTER TABLE "${table.name}" DROP CONSTRAINT IF EXISTS "${uniqueName}"`;
        const down = ""; // No down query for this operation

        await this.executeQueries(new Query(up), new Query(down));
    } catch (error) {
        // Fallback approach: Drop the unique index (for older DuckDB versions)
        const up = `DROP INDEX IF EXISTS "${uniqueName}"`;
        const down = ""; // No down query for this operation

        await this.executeQueries(new Query(up), new Query(down));
    }

    // Remove the constraint from the table metadata if it's a TableUnique object
    if (InstanceChecker.isTableUnique(uniqueOrName)) {
        table.removeUniqueConstraint(uniqueOrName);
    }
}

/**
 * Drops unique constraints.
 */
async dropUniqueConstraints(tableOrName: Table | string, uniqueConstraints: TableUnique[]): Promise<void> {
    // For better performance and to match the pattern in createUniqueConstraint,
    // get the table object once if tableOrName is a string
    const table = InstanceChecker.isTable(tableOrName)
        ? tableOrName
        : await this.getCachedTable(tableOrName);

    // Drop each constraint
    for (const uniqueConstraint of uniqueConstraints) {
        await this.dropUniqueConstraint(table, uniqueConstraint);
    }
}



    /**
     * Creates a new check constraint.
     */
    async createCheckConstraint(tableOrName: Table | string, checkConstraint: TableCheck): Promise<void> {
        // DuckDB doesn't support adding check constraints after table creation
        // We need to recreate the table with the check constraint
        const tableName = InstanceChecker.isTable(tableOrName) ? tableOrName.name : tableOrName;

        // Get the existing table definition
        const table = await this.getTable(tableName);
        if (!table)
            throw new Error(`Table "${tableName}" does not exist.`);

        // Add the check constraint to the table
        table.checks = table.checks || [];
        table.checks.push(checkConstraint);

        // Create a temporary table name
        const tempTableName = `${tableName}_temp_${Date.now()}`;

        // Clone the table for the new definition
        const newTable = table.clone();
        newTable.name = tempTableName;

        // Start a transaction
        await this.startTransaction();

        try {
            // Create the new table with check constraint
            await this.createTable(newTable);

            // Copy data
            const columnNamesString = table.columns.map(column => `"${column.name}"`).join(", ");
            await this.query(`INSERT INTO "${tempTableName}" (${columnNamesString}) SELECT ${columnNamesString} FROM "${tableName}"`);

            // Drop the old table
            await this.dropTable(tableName);

            // Rename the new table to the old table name
            await this.renameTable(tempTableName, tableName);

            // Commit the transaction
            await this.commitTransaction();
        } catch (error) {
            // Rollback in case of any error
            await this.rollbackTransaction();
            throw error;
        }
    }

    /**
     * Creates new check constraints.
     */
    async createCheckConstraints(tableOrName: Table | string, checkConstraints: TableCheck[]): Promise<void> {
        const tableName = InstanceChecker.isTable(tableOrName) ? tableOrName.name : tableOrName;

        // Get the existing table definition
        const table = await this.getTable(tableName);
        if (!table)
            throw new Error(`Table "${tableName}" does not exist.`);

        // Add all check constraints to the table
        table.checks = table.checks || [];
        table.checks.push(...checkConstraints);

        // Create a temporary table name
        const tempTableName = `${tableName}_temp_${Date.now()}`;

        // Clone the table for the new definition
        const newTable = table.clone();
        newTable.name = tempTableName;

        // Start a transaction
        await this.startTransaction();

        try {
            // Create the new table with check constraints
            await this.createTable(newTable);

            // Copy data
            const columnNamesString = table.columns.map(column => `"${column.name}"`).join(", ");
            await this.query(`INSERT INTO "${tempTableName}" (${columnNamesString}) SELECT ${columnNamesString} FROM "${tableName}"`);

            // Drop the old table
            await this.dropTable(tableName);

            // Rename the new table to the old table name
            await this.renameTable(tempTableName, tableName);

            // Commit the transaction
            await this.commitTransaction();
        } catch (error) {
            // Rollback in case of any error
            await this.rollbackTransaction();
            throw error;
        }
    }



    /**
     * Drops a check constraint.
     */
    async dropCheckConstraint(tableOrName: Table | string, checkOrName: TableCheck | string): Promise<void> {
        // DuckDB doesn't support dropping check constraints after table creation
        // We need to recreate the table without the check constraint
        const tableName = InstanceChecker.isTable(tableOrName) ? tableOrName.name : tableOrName;

        // Get the existing table definition
        const table = await this.getTable(tableName);
        if (!table || !table.checks || table.checks.length === 0)
            throw new Error(`Table "${tableName}" does not have any check constraints.`);

        // Find and remove the check constraint
        const checkName = InstanceChecker.isTableCheck(checkOrName) ? checkOrName.name : checkOrName;
        table.checks = table.checks.filter(check => check.name !== checkName);

        // Create a temporary table name
        const tempTableName = `${tableName}_temp_${Date.now()}`;

        // Clone the table for the new definition
        const newTable = table.clone();
        newTable.name = tempTableName;

        // Start a transaction
        await this.startTransaction();

        try {
            // Create the new table without the check constraint
            await this.createTable(newTable);

            // Copy data
            const columnNamesString = table.columns.map(column => `"${column.name}"`).join(", ");
            await this.query(`INSERT INTO "${tempTableName}" (${columnNamesString}) SELECT ${columnNamesString} FROM "${tableName}"`);

            // Drop the old table
            await this.dropTable(tableName);

            // Rename the new table to the old table name
            await this.renameTable(tempTableName, tableName);

            // Commit the transaction
            await this.commitTransaction();
        } catch (error) {
            // Rollback in case of any error
            await this.rollbackTransaction();
            throw error;
        }
    }

    /**
     * Drops check constraints.
     */
    async dropCheckConstraints(tableOrName: Table | string, checkConstraints: TableCheck[]): Promise<void> {
        // We can do this operation in a single table recreation
        const tableName = InstanceChecker.isTable(tableOrName) ? tableOrName.name : tableOrName;

        // Get the existing table definition
        const table = await this.getTable(tableName);
        if (!table || !table.checks || table.checks.length === 0)
            throw new Error(`Table "${tableName}" does not have any check constraints.`);

        // Get the check constraint names to drop
        const checkNames = checkConstraints.map(check => InstanceChecker.isTableCheck(check) ? check.name : check);

        // Remove all specified check constraints
        table.checks = table.checks.filter(check => !checkNames.includes(check.name));

        // Create a temporary table name
        const tempTableName = `${tableName}_temp_${Date.now()}`;

        // Clone the table for the new definition
        const newTable = table.clone();
        newTable.name = tempTableName;

        // Start a transaction
        await this.startTransaction();

        try {
            // Create the new table without the check constraints
            await this.createTable(newTable);

            // Copy data
            const columnNamesString = table.columns.map(column => `"${column.name}"`).join(", ");
            await this.query(`INSERT INTO "${tempTableName}" (${columnNamesString}) SELECT ${columnNamesString} FROM "${tableName}"`);

            // Drop the old table
            await this.dropTable(tableName);

            // Rename the new table to the old table name
            await this.renameTable(tempTableName, tableName);

            // Commit the transaction
            await this.commitTransaction();
        } catch (error) {
            // Rollback in case of any error
            await this.rollbackTransaction();
            throw error;
        }
    }





    /**
     * Creates a new exclusion constraint.
     */
    async createExclusionConstraint(tableOrName: Table | string, exclusionConstraint: TableExclusion): Promise<void> {
        throw new Error("DuckDB does not support exclusion constraints.");
    }

    /**
     * Creates new exclusion constraints.
     */
    async createExclusionConstraints(tableOrName: Table | string, exclusionConstraints: TableExclusion[]): Promise<void> {
        throw new Error("DuckDB does not support exclusion constraints.");
    }

    /**
     * Drops exclusion constraint.
     */
    async dropExclusionConstraint(tableOrName: Table | string, exclusionOrName: TableExclusion | string): Promise<void> {
        throw new Error("DuckDB does not support exclusion constraints.");
    }

    /**
     * Drops exclusion constraints.
     */
    async dropExclusionConstraints(tableOrName: Table | string, exclusionConstraints: TableExclusion[]): Promise<void> {
        throw new Error("DuckDB does not support exclusion constraints.");
    }







    /**
     * Creates a new foreign key.
     */
    async createForeignKey(tableOrName: Table | string, foreignKey: TableForeignKey): Promise<void> {
        // DuckDB doesn't support adding foreign keys after table creation
        // We need to recreate the table with the foreign key
        const tableName = InstanceChecker.isTable(tableOrName) ? tableOrName.name : tableOrName;

        // Get the existing table definition
        const table = await this.getTable(tableName);
        if (!table)
            throw new Error(`Table "${tableName}" does not exist.`);

        // Add the foreign key to the table
        table.foreignKeys = table.foreignKeys || [];
        table.foreignKeys.push(foreignKey);

        // Create a temporary table name
        const tempTableName = `${tableName}_temp_${Date.now()}`;

        // Clone the table for the new definition
        const newTable = table.clone();
        newTable.name = tempTableName;

        // Start a transaction
        await this.startTransaction();

        try {
            // Create the new table with foreign key
            await this.createTable(newTable, false, true);

            // Copy data
            const columnNamesString = table.columns.map(column => `"${column.name}"`).join(", ");
            await this.query(`INSERT INTO "${tempTableName}" (${columnNamesString}) SELECT ${columnNamesString} FROM "${tableName}"`);

            // Drop the old table
            await this.dropTable(tableName);

            // Rename the new table to the old table name
            await this.renameTable(tempTableName, tableName);

            // Commit the transaction
            await this.commitTransaction();
        } catch (error) {
            // Rollback in case of any error
            await this.rollbackTransaction();
            throw error;
        }
    }

    /**
     * Creates a new foreign keys.
     */
    async createForeignKeys(tableOrName: Table | string, foreignKeys: TableForeignKey[]): Promise<void> {
        // We can do this operation in a single table recreation
        const tableName = InstanceChecker.isTable(tableOrName) ? tableOrName.name : tableOrName;

        // Get the existing table definition
        const table = await this.getTable(tableName);
        if (!table)
            throw new Error(`Table "${tableName}" does not exist.`);

        // Add all foreign keys to the table
        table.foreignKeys = table.foreignKeys || [];
        table.foreignKeys.push(...foreignKeys);

        // Create a temporary table name
        const tempTableName = `${tableName}_temp_${Date.now()}`;

        // Clone the table for the new definition
        const newTable = table.clone();
        newTable.name = tempTableName;

        // Start a transaction
        await this.startTransaction();

        try {
            // Create the new table with foreign keys
            await this.createTable(newTable, false, true);

            // Copy data
            const columnNamesString = table.columns.map(column => `"${column.name}"`).join(", ");
            await this.query(`INSERT INTO "${tempTableName}" (${columnNamesString}) SELECT ${columnNamesString} FROM "${tableName}"`);

            // Drop the old table
            await this.dropTable(tableName);

            // Rename the new table to the old table name
            await this.renameTable(tempTableName, tableName);

            // Commit the transaction
            await this.commitTransaction();
        } catch (error) {
            // Rollback in case of any error
            await this.rollbackTransaction();
            throw error;
        }
    }

    /**
     * Drops a foreign key.
     */
    async dropForeignKey(tableOrName: Table | string, foreignKeyOrName: TableForeignKey | string): Promise<void> {
        // DuckDB doesn't support dropping foreign keys after table creation
        // We need to recreate the table without the foreign key
        const tableName = InstanceChecker.isTable(tableOrName) ? tableOrName.name : tableOrName;

        // Get the existing table definition
        const table = await this.getTable(tableName);
        if (!table || !table.foreignKeys || table.foreignKeys.length === 0)
            throw new Error(`Table "${tableName}" does not have any foreign keys.`);

        // Find and remove the foreign key
        const foreignKeyName = InstanceChecker.isTableForeignKey(foreignKeyOrName) ? foreignKeyOrName.name : foreignKeyOrName;
        table.foreignKeys = table.foreignKeys.filter(fk => fk.name !== foreignKeyName);

        // Create a temporary table name
        const tempTableName = `${tableName}_temp_${Date.now()}`;

        // Clone the table for the new definition
        const newTable = table.clone();
        newTable.name = tempTableName;

        // Start a transaction
        await this.startTransaction();

        try {
            // Create the new table without the foreign key
            await this.createTable(newTable, false, true);

            // Copy data
            const columnNamesString = table.columns.map(column => `"${column.name}"`).join(", ");
            await this.query(`INSERT INTO "${tempTableName}" (${columnNamesString}) SELECT ${columnNamesString} FROM "${tableName}"`);

            // Drop the old table
            await this.dropTable(tableName);

            // Rename the new table to the old table name
            await this.renameTable(tempTableName, tableName);

            // Commit the transaction
            await this.commitTransaction();
        } catch (error) {
            // Rollback in case of any error
            await this.rollbackTransaction();
            throw error;
        }
    }



    /**
     * Creates a new index.
     */
    async createIndex(tableOrName: Table | string, index: TableIndex): Promise<void> {
        const tableName = InstanceChecker.isTable(tableOrName) ? tableOrName.name : tableOrName;
        const columnNames = index.columnNames.map(column => `"${column}"`).join(", ");
        const sql = `CREATE${index.isUnique ? " UNIQUE " : " "}INDEX "${index.name}" ON "${tableName}" (${columnNames})`;
        await this.query(sql);
    }


    /**
     * Creates a new indices
     */
    async createIndices(tableOrName: Table | string, indices: TableIndex[]): Promise<void> {
        for (const index of indices) {
            await this.createIndex(tableOrName, index);
        }
    }

    /**
     * Drops an index.
     */
    async dropIndex(tableOrName: Table | string, indexOrName: TableIndex | string): Promise<void> {
        const indexName = InstanceChecker.isTableIndex(indexOrName) ? indexOrName.name : indexOrName;
        await this.query(`DROP INDEX "${indexName}"`);
    }
    /**
     * Drops indices from the table.
     */
    async dropIndices(tableOrName: Table | string, indices: TableIndex[]): Promise<void> {
        for (const index of indices) {
            await this.dropIndex(tableOrName, index);
        }
    }

    /**
     * Clears all table contents.
     * Note: this operation uses SQL's TRUNCATE query which cannot be reverted in transactions.
     */
    async clearTable(tableOrName: Table | string): Promise<void> {
        const tableName = InstanceChecker.isTable(tableOrName) ? tableOrName.name : tableOrName;
        await this.query(`DELETE FROM "${tableName}"`);
    }



    /**
     * Removes all tables from the currently connected database.
     */
    async clearDatabase(database?: string): Promise<void> {
        // Get all tables
        const tables = await this.query(`select table_name From information_schema.tables where table_type = 'BASE TABLE'`);

        // Start a transaction
        await this.startTransaction();

        try {
            // Drop all tables
            for (const table of tables) {
                await this.query(`DROP TABLE "${table.name}"`);
            }

            // Commit the transaction
            await this.commitTransaction();
        } catch (error) {
            // Rollback in case of any error
            await this.rollbackTransaction();
            throw error;
        }
    }


        /**
 * Efficiently inserts multiple rows into a table using a single multi-row INSERT statement.
 * @param tableName The name of the table.
 * @param rows Array of objects representing rows to insert.
 */
    async bulkInsert(tableName: string, rows: ObjectLiteral[]): Promise<void> {
        if (!rows.length) return;

        const columns = Object.keys(rows[0]);
        const columnNames = columns.map(col => `"${col}"`).join(", ");

        // Prepare value placeholders for each row
        const valuePlaceholders = rows.map(
            (_, rowIdx) =>
                `(${columns.map((_, colIdx) => `$${rowIdx * columns.length + colIdx + 1}`).join(", ")})`
        ).join(", ");

        // Flatten all values into a single array
        const values = rows.flatMap(row => columns.map(col => row[col]));

        const sql = `INSERT INTO "${tableName}" (${columnNames}) VALUES ${valuePlaceholders}`;
        await this.query(sql, values);
    }




    // -------------------------------------------------------------------------
    // Protected Methods
    // -------------------------------------------------------------------------

        /**
     * Escapes given table or view path.
     */
    protected escapePath(target: Table | View | string): string {
    const { schema, tableName } = this.driver.parseTableName(target);

    // For DuckDB, main is the default schema if none is specified
    // Always include schema if it's provided, or use main as default
    if (schema) {
        return `"${schema}"."${tableName}"`;
    }

    // If no schema provided, use the table name without schema qualifier
    // This will use the current/default schema (main in DuckDB)
    return `"${tableName}"`;
}
protected async loadViews(viewNames?: string[]): Promise<View[]> {
    const hasTable = await this.hasTable(this.getTypeormMetadataTableName())
    if (!hasTable) return []

    if (!viewNames) {
        viewNames = []
    }

    const currentDatabase = await this.getCurrentDatabase()
    const currentSchema = await this.getCurrentSchema() || 'main' // DuckDB uses 'main' as default schema

    // Build view condition for DuckDB
    const viewsCondition =
        viewNames.length === 0
            ? "1=1"
            : viewNames
                  .map((tableName) => this.driver.parseTableName(tableName))
                  .map(({ schema, tableName }) => {
                      if (!schema) {
                          schema = currentSchema;
                      }
                      return `("t"."schema" = '${schema}' AND "t"."name" = '${tableName}')`
                  })
                  .join(" OR ");

    // Query to get views from typeorm metadata
    const query =
        `SELECT "t".* FROM ${this.escapePath(
            this.getTypeormMetadataTableName(),
        )} "t" WHERE "t"."type" IN ('${MetadataTableType.VIEW}', '${
            MetadataTableType.MATERIALIZED_VIEW
        }') ${viewsCondition ? `AND (${viewsCondition})` : ""}`;

    // Get view metadata
    const dbViews = await this.query(query);

    // Get all indexes using duckdb_indexes() function
    let dbIndices: ObjectLiteral[] = [];

    try {
        // Get all indexes from DuckDB
        const allIndexes = await this.query(`SELECT * FROM duckdb_indexes()`);

        // Process indexes to match the format we need
        for (const idx of allIndexes) {
            // Get the schema and table name
            const schemaName = idx.schema_name || currentSchema;
            const tableName = idx.table_name;

            // We need column info for each index
            // The columns are stored in the constraint_text or index_columns field depending on version
            const columnNamesStr = idx.index_columns || idx.constraint_text || '';

            // Extract column names from the constraint_text or index_columns
            // Format could be like 'UNIQUE (col1, col2)' or just 'col1, col2'
            let columnNames: string[] = [];

            if (columnNamesStr) {
                // Try to extract column names from constraint text
                const match = columnNamesStr.match(/\(([^)]+)\)/);
                if (match && match[1]) {
                    // We have columns within parentheses
                    columnNames = match[1].split(',').map((col: string) => col.trim());
                } else {
                    // Simple comma-separated list of columns
                    columnNames = columnNamesStr.split(',').map((col: string) => col.trim());
                }
            }

            // Create an entry for each column
            for (const column of columnNames) {
                if (column) {
                    dbIndices.push({
                        table_schema: schemaName,
                        table_name: tableName,
                        constraint_name: idx.index_name,
                        column_name: column,
                        is_unique: idx.is_unique ? "TRUE" : "FALSE",
                        condition: null,
                        type_name: null
                    });
                }
            }
        }
    } catch (error) {
        // If duckdb_indexes() fails, try alternative approach with sqlite_master
        try {
            const allIndexes = await this.query(`
                SELECT * FROM sqlite_master
                WHERE type = 'index'
            `);

            for (const idx of allIndexes) {
                // Extract table name from SQL
                const tableMatch = idx.sql.match(/ON\s+["']?([^"'\s(]+)/i);
                const tableName = tableMatch ? tableMatch[1] : null;

                if (tableName) {
                    // Extract column names from SQL
                    const columnsMatch = idx.sql.match(/\(([^)]+)\)/);
                    const columnsStr = columnsMatch ? columnsMatch[1] : '';
                    const columns = columnsStr.split(',').map((col: string) => col.trim());

                    // Check if index is unique
                    const isUnique = idx.sql.toUpperCase().includes('UNIQUE INDEX');

                    // Add an entry for each column
                    for (const column of columns) {
                        if (column) {
                            dbIndices.push({
                                table_schema: currentSchema,
                                table_name: tableName,
                                constraint_name: idx.name,
                                column_name: column.replace(/["`']/g, ''), // Remove quotes
                                is_unique: isUnique ? "TRUE" : "FALSE",
                                condition: null,
                                type_name: null
                            });
                        }
                    }
                }
            }
        } catch (error) {
            // Continue with empty indices
        }
    }

    return dbViews.map((dbView: any) => {
        // Find index constraints of table
        const tableIndexConstraints = OrmUtils.uniq(
            dbIndices.filter((dbIndex) => {
                return (
                    dbIndex["table_name"] === dbView["name"] &&
                    dbIndex["table_schema"] === dbView["schema"]
                )
            }),
            (dbIndex) => dbIndex["constraint_name"],
        );

        const view = new View();
        const schema =
            dbView["schema"] === currentSchema
                ? undefined
                : dbView["schema"];

        view.database = currentDatabase;
        view.schema = dbView["schema"];
        view.name = this.driver.buildTableName(dbView["name"], schema);
        view.expression = dbView["value"];
        view.materialized =
            dbView["type"] === MetadataTableType.MATERIALIZED_VIEW;
        view.indices = tableIndexConstraints.map((constraint) => {
            const indices = dbIndices.filter((index) => {
                return (
                    index["table_schema"] === constraint["table_schema"] &&
                    index["table_name"] === constraint["table_name"] &&
                    index["constraint_name"] === constraint["constraint_name"]
                )
            });

            return new TableIndex(<TableIndexOptions>{
                view: view,
                name: constraint["constraint_name"],
                columnNames: indices.map((i) => i["column_name"]),
                isUnique: constraint["is_unique"] === "TRUE",
                where: constraint["condition"],
                isFulltext: false,
            });
        });

        return view;
    });
}



    /**
     * Loads tables from the database.
     * If tablePaths is provided, only loads those tables.
     */
/**
 * Loads all tables (with given names) from the database and creates a Table from them.
 */
protected async loadTables(tableNames?: string[]): Promise<Table[]> {
    // if no tables given then no need to proceed
    if (tableNames && tableNames.length === 0) {
        return []
    }

    const currentSchema = await this.getCurrentSchema() || 'main' // DuckDB uses 'main' as default schema
    const currentDatabase = await this.getCurrentDatabase()

    // Get all tables from DuckDB
    let dbTables: {
        table_schema: string
        table_name: string
        table_comment: string
    }[] = []

    try {
        if (!tableNames) {
            // Get all tables if no specific table names provided
            // Using information_schema.tables as the official way to query tables
            const tablesSql = `
                SELECT
                    table_schema AS table_schema,
                    table_name,
                    '' AS table_comment
                FROM
                    information_schema.tables
                WHERE
                    table_type = 'BASE TABLE'
            `
            dbTables.push(...(await this.query(tablesSql)))
        } else {
            // Filter tables by name
            const tablesCondition = tableNames
                .map((tableName) => this.driver.parseTableName(tableName))
                .map(({ schema, tableName }) => {
                    return `(table_schema = '${
                        schema || currentSchema
                    }' AND table_name = '${tableName}')`
                })
                .join(" OR ")

            const tablesSql = `
                SELECT
                    table_schema AS table_schema,
                    table_name,
                    '' AS table_comment
                FROM
                    information_schema.tables
                WHERE
                    table_type = 'BASE TABLE'
                    AND (${tablesCondition})
            `
            dbTables.push(...(await this.query(tablesSql)))
        }
    } catch (error) {
        // If information_schema.tables fails, try with duckdb_tables()
        try {
            const tablesCondition = tableNames
                ? tableNames
                    .map((tableName) => this.driver.parseTableName(tableName))
                    .map(({ schema, tableName }) => {
                        return `(schema_name = '${
                            schema || currentSchema
                        }' AND table_name = '${tableName}')`
                    })
                    .join(" OR ")
                : "1=1";

            const tablesSql = `
                SELECT
                    schema_name AS table_schema,
                    table_name,
                    '' AS table_comment
                FROM
                    duckdb_tables()
                WHERE
                    table_type = 'TABLE'
                    AND (${tablesCondition})
            `
            dbTables.push(...(await this.query(tablesSql)))
        } catch (e) {
            // If both approaches fail, return empty array
            return []
        }
    }

    // if tables were not found in the db, no need to proceed
    if (dbTables.length === 0) {
        return []
    }

    // Get column information for all tables using information_schema.columns
    let dbColumns: any[] = []
    try {
        const columnsCondition = dbTables
            .map(({ table_schema, table_name }) => {
                return `(table_schema = '${table_schema}' AND table_name = '${table_name}')`
            })
            .join(" OR ")

        const columnsSql = `
            SELECT
                table_schema,
                table_name,
                column_name,
                data_type,
                is_nullable,
                column_default,
                character_maximum_length,
                numeric_precision,
                numeric_scale,
                CAST(FALSE AS BOOLEAN) AS is_identity,
                CAST(FALSE AS BOOLEAN) AS is_generated,
                NULL AS generation_expression,
                NULL AS description
            FROM
                information_schema.columns
            WHERE
                ${columnsCondition}
            ORDER BY
                table_schema, table_name, ordinal_position
        `
        dbColumns = await this.query(columnsSql)
    } catch (error) {
        // If information_schema.columns fails, try with duckdb_columns() table function
        try {
            const columnsCondition = dbTables
                .map(({ table_schema, table_name }) => {
                    return `(schema_name = '${table_schema}' AND table_name = '${table_name}')`
                })
                .join(" OR ")

            const columnsSql = `
                SELECT
                    schema_name AS table_schema,
                    table_name,
                    column_name,
                    data_type,
                    CASE WHEN "null" = TRUE THEN 'YES' ELSE 'NO' END AS is_nullable,
                    default_value AS column_default,
                    NULL AS character_maximum_length,
                    NULL AS numeric_precision,
                    NULL AS numeric_scale,
                    CAST(FALSE AS BOOLEAN) AS is_identity,
                    CAST(FALSE AS BOOLEAN) AS is_generated,
                    NULL AS generation_expression,
                    NULL AS description
                FROM
                    duckdb_columns()
                WHERE
                    ${columnsCondition}
                ORDER BY
                    schema_name, table_name, column_idx
            `
            dbColumns = await this.query(columnsSql)
        } catch (e) {
            // If both approaches fail, use PRAGMA for each table
            for (const dbTable of dbTables) {
                try {
                    // Using PRAGMA table_info to get column information
                    const columns = await this.query(`PRAGMA table_info('${dbTable.table_schema}.${dbTable.table_name}')`)

                    // Transform to match our expected format
                    for (const column of columns) {
                        dbColumns.push({
                            table_schema: dbTable.table_schema,
                            table_name: dbTable.table_name,
                            column_name: column.name,
                            data_type: column.type,
                            is_nullable: column.notnull === 0 ? "YES" : "NO",
                            column_default: column.dflt_value,
                            character_maximum_length: null,
                            numeric_precision: null,
                            numeric_scale: null,
                            is_identity: false,
                            is_generated: false,
                            generation_expression: null,
                            description: null,
                        })
                    }
                } catch (error) {
                    // If PRAGMA fails, skip this table's columns
                }
            }
        }
    }

    // Get index information using duckdb_indexes() table function
    let dbIndices: any[] = []
    try {
        const indicesCondition = dbTables
            .map(({ table_schema, table_name }) => {
                return `(schema_name = '${table_schema}' AND table_name = '${table_name}')`
            })
            .join(" OR ")

        const indicesSql = `
            SELECT
                schema_name AS table_schema,
                table_name,
                index_name AS constraint_name,
                column_name,
                CASE WHEN is_unique THEN 'TRUE' ELSE 'FALSE' END AS is_unique,
                NULL AS condition,
                NULL AS type_name,
                'btree' AS index_type
            FROM
                duckdb_indexes()
            WHERE
                ${indicesCondition}
        `

        try {
            // First try with the most detailed duckdb_indexes version (which returns column_name directly)
            dbIndices = await this.query(indicesSql)
        } catch (error) {
            // Fallback approach for older DuckDB versions where duckdb_indexes() doesn't return column_name
            const basicIndicesSql = `
                SELECT
                    schema_name AS table_schema,
                    table_name,
                    index_name AS constraint_name,
                    is_unique,
                    index_columns
                FROM
                    duckdb_indexes()
                WHERE
                    ${indicesCondition}
            `

            const basicIndices = await this.query(basicIndicesSql)

            // Process indices and extract column information
            for (const idx of basicIndices) {
                // Parse index columns - typically comes as a comma-separated string or in parentheses
                const columnStr = idx.index_columns || '';
                let columnNames: string[] = [];

                // Try to extract column names
                const match = columnStr.match(/\(([^)]+)\)/);
                if (match && match[1]) {
                    // We have columns within parentheses
                    columnNames = match[1].split(',').map((col: string) => col.trim());
                } else {
                    // Simple comma-separated list
                    columnNames = columnStr.split(',').map((col: string) => col.trim());
                }

                // Add an entry for each column
                for (const columnName of columnNames) {
                    if (columnName) {
                        dbIndices.push({
                            table_schema: idx.table_schema,
                            table_name: idx.table_name,
                            constraint_name: idx.constraint_name,
                            column_name: columnName.replace(/["`']/g, ''), // Remove quotes
                            is_unique: idx.is_unique ? "TRUE" : "FALSE",
                            condition: null,
                            type_name: null,
                            index_type: 'btree' // Default in DuckDB
                        });
                    }
                }
            }
        }
    } catch (error) {
        // If duckdb_indexes() fails, try with information_schema.statistics
        try {
            const indicesCondition = dbTables
                .map(({ table_schema, table_name }) => {
                    return `(table_schema = '${table_schema}' AND table_name = '${table_name}')`
                })
                .join(" OR ")

            const indicesSql = `
                SELECT
                    table_schema,
                    table_name,
                    index_name AS constraint_name,
                    column_name,
                    CASE WHEN non_unique = FALSE THEN 'TRUE' ELSE 'FALSE' END AS is_unique,
                    NULL AS condition,
                    NULL AS type_name,
                    index_type
                FROM
                    information_schema.statistics
                WHERE
                    ${indicesCondition}
            `
            dbIndices = await this.query(indicesSql)
        } catch (error) {
            // If both approaches fail, try with sqlite_master as last resort
            try {
                for (const dbTable of dbTables) {
                    const indices = await this.query(`
                        SELECT
                            name,
                            tbl_name AS table_name,
                            sql
                        FROM
                            sqlite_master
                        WHERE
                            type = 'index'
                            AND tbl_name = '${dbTable.table_name}'
                    `)

                    for (const idx of indices) {
                        // Extract column names from SQL
                        const columnsMatch = idx.sql.match(/\(([^)]+)\)/);
                        const columnsStr = columnsMatch ? columnsMatch[1] : '';
                        const columns = columnsStr.split(',').map((col: string) => col.trim());

                        // Check if index is unique
                        const isUnique = idx.sql.toUpperCase().includes('UNIQUE INDEX');

                        // Add an entry for each column
                        for (const column of columns) {
                            if (column) {
                                dbIndices.push({
                                    table_schema: dbTable.table_schema,
                                    table_name: idx.table_name,
                                    constraint_name: idx.name,
                                    column_name: column.replace(/["`']/g, ''), // Remove quotes
                                    is_unique: isUnique ? "TRUE" : "FALSE",
                                    condition: null,
                                    type_name: null,
                                    index_type: 'btree' // Default in DuckDB
                                });
                            }
                        }
                    }
                }
            } catch (e) {
                // If all approaches fail, continue without indices
            }
        }
    }

    // Get foreign key information
    let dbForeignKeys: any[] = []
    try {
        // First try with information_schema.key_column_usage and information_schema.referential_constraints
        const fkCondition = dbTables
            .map(({ table_schema, table_name }) => {
                return `(kcu.table_schema = '${table_schema}' AND kcu.table_name = '${table_name}')`
            })
            .join(" OR ")

        const foreignKeysSql = `
            SELECT
                rc.constraint_name,
                kcu.table_schema,
                kcu.table_name,
                kcu.column_name,
                kcu.referenced_table_schema,
                kcu.referenced_table_name,
                kcu.referenced_column_name,
                rc.delete_rule AS on_delete,
                rc.update_rule AS on_update,
                FALSE AS deferrable,
                'INITIALLY IMMEDIATE' AS deferred
            FROM
                information_schema.key_column_usage kcu
            JOIN
                information_schema.referential_constraints rc
                ON kcu.constraint_name = rc.constraint_name
                AND kcu.table_schema = rc.constraint_schema
            WHERE
                kcu.referenced_table_name IS NOT NULL
                AND (${fkCondition})
        `

        try {
            dbForeignKeys = await this.query(foreignKeysSql)
        } catch (error) {
            // Fallback to PRAGMA for each table if information_schema approach fails
            for (const dbTable of dbTables) {
                try {
                    // Using PRAGMA foreign_key_list to get foreign key information
                    const foreignKeys = await this.query(`PRAGMA foreign_key_list('${dbTable.table_schema}.${dbTable.table_name}')`)

                    for (const fk of foreignKeys) {
                        // Parse table reference which might include schema
                        const tableRef = fk.table;
                        let refSchema = dbTable.table_schema;
                        let refTable = tableRef;

                        // Check if table reference includes schema
                        if (tableRef.includes('.')) {
                            const parts = tableRef.split('.');
                            refSchema = parts[0];
                            refTable = parts[1];
                        }

                        dbForeignKeys.push({
                            constraint_name: `fk_${dbTable.table_name}_${fk.id}`, // DuckDB doesn't always name FKs, so we generate a name
                            table_schema: dbTable.table_schema,
                            table_name: dbTable.table_name,
                            column_name: fk.from,
                            referenced_table_schema: refSchema,
                            referenced_table_name: refTable,
                            referenced_column_name: fk.to,
                            on_delete: fk.on_delete || 'NO ACTION',
                            on_update: fk.on_update || 'NO ACTION',
                            deferrable: false,
                            deferred: 'INITIALLY IMMEDIATE'
                        });
                    }
                } catch (error) {
                    // If PRAGMA fails, continue without foreign keys for this table
                }
            }
        }
    } catch (error) {
        // If both approaches fail, continue without foreign keys
    }

    // Get constraint information (primary key, unique, check)
    let dbConstraints: any[] = []
    try {
        // Get constraints from information_schema
        const constraintsCondition = dbTables
            .map(({ table_schema, table_name }) => {
                return `(tc.table_schema = '${table_schema}' AND tc.table_name = '${table_name}')`
            })
            .join(" OR ")

        const constraintsSql = `
            SELECT
                tc.constraint_schema AS table_schema,
                tc.table_name,
                tc.constraint_name,
                ccu.column_name,
                tc.constraint_type,
                CASE
                    WHEN tc.constraint_type = 'CHECK' THEN cc.check_clause
                    ELSE NULL
                END AS expression
            FROM
                information_schema.table_constraints tc
            LEFT JOIN
                information_schema.constraint_column_usage ccu
                ON tc.constraint_schema = ccu.constraint_schema
                AND tc.constraint_name = ccu.constraint_name
            LEFT JOIN
                information_schema.check_constraints cc
                ON tc.constraint_schema = cc.constraint_schema
                AND tc.constraint_name = cc.constraint_name
            WHERE
                (${constraintsCondition})
        `

        try {
            dbConstraints = await this.query(constraintsSql)
        } catch (error) {
            // If information_schema approach fails, try alternatives for constraints

            // For primary keys, add from column info that has primary key flag set
            for (const column of dbColumns) {
                if (column.is_identity || (column.column_default && column.column_default.includes('AUTOINCREMENT'))) {
                    dbConstraints.push({
                        table_schema: column.table_schema,
                        table_name: column.table_name,
                        constraint_name: `pk_${column.table_name}`,
                        column_name: column.column_name,
                        constraint_type: 'PRIMARY KEY',
                        expression: null
                    })
                }
            }

            // Add unique constraints from indices
            for (const idx of dbIndices) {
                if (idx.is_unique === 'TRUE') {
                    dbConstraints.push({
                        table_schema: idx.table_schema,
                        table_name: idx.table_name,
                        constraint_name: idx.constraint_name,
                        column_name: idx.column_name,
                        constraint_type: 'UNIQUE',
                        expression: null
                    })
                }
            }

            // For truly desperate situations, try to read primary keys from PRAGMA
            for (const dbTable of dbTables) {
                try {
                    const tableInfo = await this.query(`PRAGMA table_info('${dbTable.table_schema}.${dbTable.table_name}')`)

                    // Process primary key columns
                    for (const column of tableInfo) {
                        if (column.pk > 0) {
                            dbConstraints.push({
                                table_schema: dbTable.table_schema,
                                table_name: dbTable.table_name,
                                constraint_name: `pk_${dbTable.table_name}`,
                                column_name: column.name,
                                constraint_type: 'PRIMARY KEY',
                                expression: null
                            });
                        }
                    }
                } catch (error) {
                    // If PRAGMA fails, continue without constraints for this table
                }
            }
        }
    } catch (error) {
        // If all constraint approaches fail, continue without constraints
    }

    // create tables for loaded tables
    return Promise.all(
        dbTables.map(async (dbTable) => {
            const table = new Table()

            const getSchemaFromKey = (dbObject: any, key: string) => {
                return dbObject[key] === currentSchema
                    ? undefined
                    : dbObject[key]
            }

            // We do not need to join schema name, when database is by default.
            const schema = getSchemaFromKey(dbTable, "table_schema")
            table.database = currentDatabase
            table.schema = dbTable["table_schema"]
            table.comment = dbTable["table_comment"] || undefined
            table.name = this.driver.buildTableName(
                dbTable["table_name"],
                schema,
            )

            // create columns from the loaded columns
            table.columns = await Promise.all(
                dbColumns
                    .filter(
                        (dbColumn) =>
                            dbColumn["table_name"] === dbTable["table_name"] &&
                            dbColumn["table_schema"] === dbTable["table_schema"],
                    )
                    .map(async (dbColumn) => {
                        const columnConstraints = dbConstraints.filter(
                            (dbConstraint) => {
                                return (
                                    dbConstraint["table_name"] === dbColumn["table_name"] &&
                                    dbConstraint["table_schema"] === dbColumn["table_schema"] &&
                                    dbConstraint["column_name"] === dbColumn["column_name"]
                                )
                            },
                        )

                        const tableColumn = new TableColumn()
                        tableColumn.name = dbColumn["column_name"]

                        // Map DuckDB types to TypeORM types
                        tableColumn.type = this.getTypeFromDuckDBType(dbColumn["data_type"])

                        // Handle precision and scale for numeric types
                        if (
                            tableColumn.type === "numeric" ||
                            tableColumn.type === "decimal" ||
                            tableColumn.type === "float"
                        ) {
                            // First check if precision and scale are available in the column info
                            if (dbColumn["numeric_precision"] !== null && dbColumn["numeric_precision"] !== undefined) {
                                const numericPrecision = dbColumn["numeric_precision"];

                                if (numericPrecision && !this.isDefaultColumnPrecision(table, tableColumn, numericPrecision)) {
                                    tableColumn.precision = numericPrecision ?? undefined;
                                }
                            }

                            if (dbColumn["numeric_scale"] !== null && dbColumn["numeric_scale"] !== undefined) {
                                const numericScale = dbColumn["numeric_scale"];

                                if (numericScale !== null && !this.isDefaultColumnScale(table, tableColumn, numericScale)) {
                                    tableColumn.scale = numericScale;
                                }
                            }

                            // If not available, try to extract from the type definition
                            if (tableColumn.precision === undefined && tableColumn.scale === undefined) {
                                const match = dbColumn["data_type"].match(/(\w+)\s*\(\s*(\d+)(?:\s*,\s*(\d+))?\s*\)/i);
                                if (match) {
                                    const precision = parseInt(match[2]);
                                    const scale = match[3] ? parseInt(match[3]) : undefined;

                                    if (precision && !this.isDefaultColumnPrecision(table, tableColumn, precision)) {
                                        tableColumn.precision = precision;
                                    }

                                    if (scale !== undefined && !this.isDefaultColumnScale(table, tableColumn, scale)) {
                                        tableColumn.scale = scale;
                                    }
                                }
                            }
                        }

                        // Check for array types
                        if (dbColumn["data_type"].endsWith('[]')) {
                            tableColumn.isArray = true;
                            tableColumn.type = tableColumn.type.replace('[]', '');
                        }

                        // Set length for string types
                        if (
                            this.driver.withLengthColumnTypes.indexOf(
                                tableColumn.type as ColumnType,
                            ) !== -1
                        ) {
                            // First try character_maximum_length if available
                            if (dbColumn["character_maximum_length"] !== null && dbColumn["character_maximum_length"] !== undefined) {
                                const length = dbColumn["character_maximum_length"].toString();
                                if (length && !this.isDefaultColumnLength(table, tableColumn, length)) {
                                    tableColumn.length = length;
                                }
                            } else {
                                // Extract length from type definition if not available in column info
                                const match = dbColumn["data_type"].match(/(\w+)\s*\(\s*(\d+)\s*\)/i);
                                if (match) {
                                    const length = match[2];
                                    if (length && !this.isDefaultColumnLength(table, tableColumn, length)) {
                                        tableColumn.length = length;
                                    }
                                }
                            }
                        }

                        // Set nullability
                        tableColumn.isNullable = dbColumn["is_nullable"] === "YES"

                        // Set primary key
                        const primaryConstraint = columnConstraints.find(
                            (constraint) => constraint["constraint_type"] === "PRIMARY KEY",
                        )
                        if (primaryConstraint) {
                            tableColumn.isPrimary = true;

                            // Find other columns in the same primary key
                            const anotherPrimaryConstraints = dbConstraints.filter(
                                (constraint) =>
                                    constraint["table_name"] === dbColumn["table_name"] &&
                                    constraint["table_schema"] === dbColumn["table_schema"] &&
                                    constraint["column_name"] !== dbColumn["column_name"] &&
                                    constraint["constraint_type"] === "PRIMARY KEY",
                            )

                            // Collect all column names
                            const columnNames = anotherPrimaryConstraints.map(
                                (constraint) => constraint["column_name"],
                            )
                            columnNames.push(dbColumn["column_name"])

                            // Build default primary key constraint name
                            const pkName = this.connection.namingStrategy.primaryKeyName(
                                table,
                                columnNames,
                            )

                            // If primary key has user-defined constraint name, write it in table column
                            if (primaryConstraint["constraint_name"] !== pkName) {
                                tableColumn.primaryKeyConstraintName = primaryConstraint["constraint_name"]
                            }
                        }

                        // Set uniqueness
                        const uniqueConstraints = columnConstraints.filter(
                            (constraint) => constraint["constraint_type"] === "UNIQUE",
                        )
                        const isConstraintComposite = uniqueConstraints.every((uniqueConstraint) => {
                            return dbConstraints.some(
                                (dbConstraint) =>
                                    dbConstraint["constraint_type"] === "UNIQUE" &&
                                    dbConstraint["constraint_name"] === uniqueConstraint["constraint_name"] &&
                                    dbConstraint["column_name"] !== dbColumn["column_name"],
                            )
                        })
                        tableColumn.isUnique = uniqueConstraints.length > 0 && !isConstraintComposite

                        // Handle default values
                        if (dbColumn["column_default"] !== null && dbColumn["column_default"] !== undefined) {
                            // Handle autoincrement
                            if (dbColumn["column_default"].includes('AUTOINCREMENT') ||
                                dbColumn["column_default"].includes('nextval') ||
                                dbColumn["is_identity"] === true) {
                                tableColumn.isGenerated = true;
                                tableColumn.generationStrategy = "increment";
                            }
                            // Handle UUID generation
                            else if (dbColumn["column_default"].includes('gen_random_uuid()') ||
                                     dbColumn["column_default"].includes('uuid_generate')) {
                                if (tableColumn.type === "uuid") {
                                    tableColumn.isGenerated = true;
                                    tableColumn.generationStrategy = "uuid";
                                } else {
                                    tableColumn.default = dbColumn["column_default"];
                                }
                            }
                            // Handle current timestamp defaults
                            else if (dbColumn["column_default"].includes('CURRENT_TIMESTAMP') ||
                                     dbColumn["column_default"].includes('now()') ||
                                     dbColumn["column_default"].includes('current_timestamp')) {
                                tableColumn.default = dbColumn["column_default"];
                            }
                            // Handle regular defaults
                            else {
                                // Trim quotes from string defaults
                                if (typeof dbColumn["column_default"] === 'string' &&
                                    dbColumn["column_default"].startsWith("'") &&
                                    dbColumn["column_default"].endsWith("'")) {
                                    tableColumn.default = dbColumn["column_default"].substring(1, dbColumn["column_default"].length - 1);
                                } else {
                                    tableColumn.default = dbColumn["column_default"];
                                }
                            }
                        }

                        // Set generated columns
                        if (dbColumn["is_generated"] === true || dbColumn["is_generated"] === "ALWAYS") {
                            tableColumn.generatedType = "STORED"; // DuckDB only supports stored generated columns
                            tableColumn.asExpression = dbColumn["generation_expression"] || "";
                        }

                        // Set comment if available
                        if (dbColumn["description"]) {
                            tableColumn.comment = dbColumn["description"];
                        }

                        return tableColumn;
                    }),
            )

            // find unique constraints of table, group them by constraint name and build TableUnique.
            const tableUniqueConstraints = OrmUtils.uniq(
                dbConstraints.filter((dbConstraint) => {
                    return (
                        dbConstraint["table_name"] === dbTable["table_name"] &&
                        dbConstraint["table_schema"] === dbTable["table_schema"] &&
                        dbConstraint["constraint_type"] === "UNIQUE"
                    )
                }),
                (dbConstraint) => dbConstraint["constraint_name"],
            )

            table.uniques = tableUniqueConstraints.map((constraint) => {
                const uniques = dbConstraints.filter(
                    (dbC) => dbC["constraint_name"] === constraint["constraint_name"],
                )
                return new TableUnique({
                    name: constraint["constraint_name"],
                    columnNames: uniques.map((u) => u["column_name"]).filter(Boolean),
                    deferrable: undefined // DuckDB doesn't support deferrable constraints
                })
            })

            // find check constraints of table, group them by constraint name and build TableCheck.
            const tableCheckConstraints = OrmUtils.uniq(
                dbConstraints.filter((dbConstraint) => {
                    return (
                        dbConstraint["table_name"] === dbTable["table_name"] &&
                        dbConstraint["table_schema"] === dbTable["table_schema"] &&
                        dbConstraint["constraint_type"] === "CHECK"
                    )
                }),
                (dbConstraint) => dbConstraint["constraint_name"],
            )

            table.checks = tableCheckConstraints.map((constraint) => {
                return new TableCheck({
                    name: constraint["constraint_name"],
                    columnNames: [], // DuckDB doesn't provide this information reliably
                    expression: constraint["expression"] || ""
                })
            })

            // DuckDB doesn't support exclusion constraints, so table.exclusions remains empty

            // find foreign key constraints of table, group them by constraint name and build TableForeignKey.
            const tableForeignKeyConstraints = OrmUtils.uniq(
                dbForeignKeys.filter((dbForeignKey) => {
                    return (
                        dbForeignKey["table_name"] === dbTable["table_name"] &&
                        dbForeignKey["table_schema"] === dbTable["table_schema"]
                    )
                }),
                (dbForeignKey) => dbForeignKey["constraint_name"],
            )

            table.foreignKeys = tableForeignKeyConstraints.map(
                (dbForeignKey) => {
                    const foreignKeys = dbForeignKeys.filter(
                        (dbFk) => dbFk["constraint_name"] === dbForeignKey["constraint_name"],
                    )

          // if referenced table located in currently used schema, we don't need to concat schema name to table name.
                    const schema = getSchemaFromKey(
                        dbForeignKey,
                        "referenced_table_schema",
                    )
                    const referencedTableName = this.driver.buildTableName(
                        dbForeignKey["referenced_table_name"],
                        schema,
                    )

                    return new TableForeignKey({
                        name: dbForeignKey["constraint_name"],
                        columnNames: foreignKeys.map(
                            (dbFk) => dbFk["column_name"],
                        ),
                        referencedSchema: dbForeignKey["referenced_table_schema"],
                        referencedTableName: referencedTableName,
                        referencedColumnNames: foreignKeys.map(
                            (dbFk) => dbFk["referenced_column_name"],
                        ),
                        onDelete: dbForeignKey["on_delete"],
                        onUpdate: dbForeignKey["on_update"],
                        deferrable: undefined // DuckDB doesn't support deferrable constraints
                    })
                },
            )

            // find index constraints of table, group them by constraint name and build TableIndex.
            const tableIndexConstraints = OrmUtils.uniq(
                dbIndices.filter((dbIndex) => {
                    return (
                        dbIndex["table_name"] === dbTable["table_name"] &&
                        dbIndex["table_schema"] === dbTable["table_schema"]
                    )
                }),
                (dbIndex) => dbIndex["constraint_name"],
            )

            table.indices = tableIndexConstraints.map((constraint) => {
                const indices = dbIndices.filter((index) => {
                    return (
                        index["table_schema"] === constraint["table_schema"] &&
                        index["table_name"] === constraint["table_name"] &&
                        index["constraint_name"] === constraint["constraint_name"]
                    )
                })
                return new TableIndex(<TableIndexOptions>{
                    table: table,
                    name: constraint["constraint_name"],
                    columnNames: indices.map((i) => i["column_name"]).filter(Boolean),
                    isUnique: constraint["is_unique"] === "TRUE",
                    where: constraint["condition"],
                    isSpatial: false, // DuckDB doesn't support spatial indices
                    isFulltext: false // DuckDB doesn't support fulltext indices
                })
            })

            return table
        }),
    )
}

/**
 * Helper method to convert DuckDB types to TypeORM types
 */
private getTypeFromDuckDBType(duckDBType: string): string {
    if (!duckDBType) return "undefined";

    // Remove size/precision/scale information for base type detection
    const baseType = duckDBType.replace(/\(\d+(?:,\d+)?\)/, '').trim().toLowerCase();

    // Map DuckDB types to TypeORM types
    switch (baseType) {
        case 'boolean':
        case 'bool':
            return 'boolean';
        case 'tinyint':
            return 'tinyint';
        case 'smallint':
        case 'int2':
            return 'smallint';
        case 'integer':
        case 'int':
        case 'int4':
            return 'integer';
        case 'bigint':
        case 'int8':
            return 'bigint';
        case 'hugeint':
            return 'bigint';
        case 'utinyint':
        case 'usmallint':
        case 'uinteger':
        case 'ubigint':
            return 'numeric';
        case 'real':
        case 'float4':
            return 'float';
        case 'double':
        case 'float8':
            return 'double';
        case 'decimal':
        case 'numeric':
            return 'decimal';
        case 'varchar':
        case 'character varying':
            return 'varchar';
        case 'char':
        case 'character':
            return 'char';
        case 'text':
            return 'text';
        case 'blob':
        case 'bytea':
        case 'binary':
        case 'varbinary':
            return 'blob';
        case 'timestamp':
        case 'timestamp_ms':
        case 'timestamp_ns':
        case 'timestamp_s':
            return 'timestamp';
        case 'timestamptz':
        case 'timestamp with time zone':
            return 'timestamp with time zone';
        case 'date':
            return 'date';
        case 'time':
            return 'time';
        case 'timetz':
        case 'time with time zone':
            return 'time with time zone';
        case 'interval':
            return 'interval';
        case 'uuid':
            return 'uuid';
        case 'json':
        case 'jsonb':
            return 'json';
        case 'enum':
            return 'enum';
        case 'struct':
        case 'map':
        case 'list':
        case 'union':
        case 'array':
            // These are complex DuckDB types that don't map directly to TypeORM
            // We'll handle them as JSON for now
            return 'json';
        default:
            // For unknown types, return as is
            return duckDBType;
    }
}





/**
 * Builds create table sql for DuckDB.
 */
protected createTableSql(table: Table, createForeignKeys?: boolean): Query {
    const columnDefinitions = table.columns
        .map((column) => this.buildCreateColumnSql(table, column))
        .join(", ")

    // Start with basic CREATE TABLE
    let sql = `CREATE TABLE ${this.escapePath(table)} (${columnDefinitions}`

    // Handle columns marked as unique
    table.columns
        .filter((column) => column.isUnique)
        .forEach((column) => {
            const isUniqueExist = table.uniques.some(
                (unique) =>
                    unique.columnNames.length === 1 &&
                    unique.columnNames[0] === column.name,
            )
            if (!isUniqueExist)
                table.uniques.push(
                    new TableUnique({
                        name: this.connection.namingStrategy.uniqueConstraintName(
                            table,
                            [column.name],
                        ),
                        columnNames: [column.name],
                    }),
                )
        })

    // Add UNIQUE constraints
    if (table.uniques.length > 0) {
        const uniquesSql = table.uniques
            .map((unique) => {
                const uniqueName = unique.name
                    ? unique.name
                    : this.connection.namingStrategy.uniqueConstraintName(
                          table,
                          unique.columnNames,
                      )
                const columnNames = unique.columnNames
                    .map((columnName) => `"${columnName}"`)
                    .join(", ")

                // DuckDB supports standard UNIQUE constraints but not the DEFERRABLE clause
                return `CONSTRAINT "${uniqueName}" UNIQUE (${columnNames})`
            })
            .join(", ")

        sql += `, ${uniquesSql}`
    }

    // Add CHECK constraints
    if (table.checks.length > 0) {
        const checksSql = table.checks
            .map((check) => {
                const checkName = check.name
                    ? check.name
                    : this.connection.namingStrategy.checkConstraintName(
                          table,
                          check.expression!,
                      )
                return `CONSTRAINT "${checkName}" CHECK (${check.expression})`
            })
            .join(", ")

        sql += `, ${checksSql}`
    }

    // DuckDB doesn't support exclusion constraints, so skip table.exclusions

    // Add FOREIGN KEY constraints if createForeignKeys is true
    if (table.foreignKeys.length > 0 && createForeignKeys) {
        const foreignKeysSql = table.foreignKeys
            .map((fk) => {
                const columnNames = fk.columnNames
                    .map((columnName) => `"${columnName}"`)
                    .join(", ")
                if (!fk.name)
                    fk.name = this.connection.namingStrategy.foreignKeyName(
                        table,
                        fk.columnNames,
                        this.getTablePath(fk),
                        fk.referencedColumnNames,
                    )

                const referencedColumnNames = fk.referencedColumnNames
                    .map((columnName) => `"${columnName}"`)
                    .join(", ")

                // DuckDB supports standard foreign key syntax but not the DEFERRABLE clause
                let constraint = `CONSTRAINT "${
                    fk.name
                }" FOREIGN KEY (${columnNames}) REFERENCES ${this.escapePath(
                    this.getTablePath(fk),
                )} (${referencedColumnNames})`

                // DuckDB supports standard ON DELETE and ON UPDATE actions
                if (fk.onDelete) constraint += ` ON DELETE ${fk.onDelete}`
                if (fk.onUpdate) constraint += ` ON UPDATE ${fk.onUpdate}`

                return constraint
            })
            .join(", ")

        sql += `, ${foreignKeysSql}`
    }

    // Add PRIMARY KEY constraint
    const primaryColumns = table.columns.filter(
        (column) => column.isPrimary,
    )
    if (primaryColumns.length > 0) {
        const primaryKeyName = primaryColumns[0].primaryKeyConstraintName
            ? primaryColumns[0].primaryKeyConstraintName
            : this.connection.namingStrategy.primaryKeyName(
                  table,
                  primaryColumns.map((column) => column.name),
              )

        const columnNames = primaryColumns
            .map((column) => `"${column.name}"`)
            .join(", ")
        sql += `, CONSTRAINT "${primaryKeyName}" PRIMARY KEY (${columnNames})`
    }

    sql += `)`

    // DuckDB doesn't support column comments in the same way as PostgreSQL
    // So we'll handle them separately if needed in the future

    return new Query(sql)
}


    /**
     * Loads Duckdb version.
     */
    protected async getVersion(): Promise<string> {
        const result = await this.query(`SELECT version()`)
        return (result[0]?.version || "").toString().replace(/^v/, "")
    }


     protected dropTableSql(tableOrPath: Table | string): Query {
            return new Query(`DROP TABLE ${this.escapePath(tableOrPath)}`)
        }



            protected createViewSql(view: View): Query {
        const materializedClause = view.materialized ? "MATERIALIZED " : ""
        const viewName = this.escapePath(view)

        if (typeof view.expression === "string") {
            return new Query(
                `CREATE ${materializedClause}VIEW ${viewName} AS ${view.expression}`,
            )
        } else {
            return new Query(
                `CREATE ${materializedClause}VIEW ${viewName} AS ${view
                    .expression(this.connection)
                    .getQuery()}`,
            )
        }
    }



    protected async insertViewDefinitionSql(view: View): Promise<Query> {
        const currentSchema = await this.getCurrentSchema()

        let { schema, tableName: name } = this.driver.parseTableName(view)

        if (!schema) {
            schema = currentSchema
        }

        const type = view.materialized
            ? MetadataTableType.MATERIALIZED_VIEW
            : MetadataTableType.VIEW
        const expression =
            typeof view.expression === "string"
                ? view.expression.trim()
                : view.expression(this.connection).getQuery()
        return this.insertTypeormMetadataSql({
            type,
            schema,
            name,
            value: expression,
        })
    }




        /**
     * Builds drop view sql.
     */
    protected dropViewSql(view: View): Query {
        const materializedClause = view.materialized ? "MATERIALIZED " : ""
        return new Query(
            `DROP ${materializedClause}VIEW ${this.escapePath(view)}`,
        )
    }

            /**
     * Builds remove view sql.
     */
    protected async deleteViewDefinitionSql(view: View): Promise<Query> {
        const currentSchema = await this.getCurrentSchema()

        let { schema, tableName: name } = this.driver.parseTableName(view)

        if (!schema) {
            schema = currentSchema
        }

        const type = view.materialized
            ? MetadataTableType.MATERIALIZED_VIEW
            : MetadataTableType.VIEW
        return this.deleteTypeormMetadataSql({ type, schema, name })
    }




        /**
     * Builds ENUM type name from given table and column.
     */
    protected buildEnumName(
        table: Table,
        column: TableColumn,
        withSchema: boolean = true,
        disableEscape?: boolean,
        toOld?: boolean,
    ): string {
        const { schema, tableName } = this.driver.parseTableName(table)
        let enumName = column.enumName
            ? column.enumName
            : `${tableName}_${column.name.toLowerCase()}_enum`
        if (schema && withSchema) enumName = `${schema}.${enumName}`
        if (toOld) enumName = enumName + "_old"
        return enumName
            .split(".")
            .map((i) => {
                return disableEscape ? i : `"${i}"`
            })
            .join(".")
    }



/**
 * Drops ENUM type from given schemas in DuckDB.
 */
protected async dropEnumTypes(schemaNames: string): Promise<void> {
    // Step 1: Identify columns using the ENUM type
    const selectColumnsQuery = `
        SELECT table_name, column_name
        FROM information_schema.columns
        WHERE data_type = 'ENUM' AND table_schema IN (${schemaNames})
    `;
    const columnsToDrop = await this.query(selectColumnsQuery);

    // Step 2: Drop each column
    for (const { table_name, column_name } of columnsToDrop) {
        const dropColumnQuery = `
            ALTER TABLE "${table_name}" DROP COLUMN "${column_name}"
        `;
        await this.query(dropColumnQuery);
    }

    // Step 3: Drop the ENUM type
    const dropEnumQuery = `
        DROP TYPE IF EXISTS "${schemaNames}".your_enum_type
    `;
    await this.query(dropEnumQuery);
}



protected async hasEnumType(
    table: Table,
    column: TableColumn,
): Promise<boolean> {
    const enumName = this.buildEnumName(table, column, false, true);

    const result = await this.query(`
        SELECT 1
        FROM duckdb_types()
        WHERE type_name = '${enumName}'
          AND type_category = 'ENUM'
          AND internal = FALSE
        LIMIT 1
    `);

    return result.length > 0;
}

/**
 * Builds CREATE TYPE ... AS ENUM(...) SQL for DuckDB.
 */
protected createEnumTypeSql(
    table: Table,
    column: TableColumn,
    enumName?: string,
): Query {
    // Use custom name if provided; otherwise build default ENUM name
    if (!enumName) enumName = this.buildEnumName(table, column);

    // Escape enum values (e.g., single quotes inside values)
    const enumValues = column.enum!
        .map(value => `'${value.replace(/'/g, "''")}'`) // SQL escape
        .join(", ");

    // DuckDB supports CREATE TYPE for ENUMs
    return new Query(`CREATE TYPE "${enumName}" AS ENUM(${enumValues})`);
}



/**
 * Builds DROP TYPE ... SQL for DuckDB.
 */
protected dropEnumTypeSql(
    table: Table,
    column: TableColumn,
    enumName?: string,
): Query {
    if (!enumName) enumName = this.buildEnumName(table, column);

    // DuckDB supports DROP TYPE IF EXISTS for user-defined types
    return new Query(`DROP TYPE IF EXISTS "${enumName}"`);
}





/**
 * Builds CREATE INDEX SQL for DuckDB.
 */
protected createIndexSql(table: Table, index: TableIndex): Query {
    const columns = index.columnNames
        .map((columnName) => `"${columnName}"`)
        .join(", ");

    // DuckDB only supports basic CREATE [UNIQUE] INDEX ON table (columns)
    const sql = `CREATE ${index.isUnique ? "UNIQUE " : ""}INDEX "${index.name}" ON ${this.escapePath(table)} (${columns})`;

    return new Query(sql);
}




/**
 * Builds DROP INDEX SQL for DuckDB.
 */
protected dropIndexSql(
    table: Table | View,
    indexOrName: TableIndex | string,
): Query {
    const indexName = InstanceChecker.isTableIndex(indexOrName)
        ? indexOrName.name
        : indexOrName;

    const { schema } = this.driver.parseTableName(table);

    // DuckDB does not support CONCURRENTLY, so we will remove that part
    return schema
        ? new Query(
              `DROP INDEX IF EXISTS "${schema}"."${indexName}"`,
          )
        : new Query(`DROP INDEX IF EXISTS "${indexName}"`);
}


protected createPrimaryKeySql(
    table: Table,
    columnNames: string[],
    constraintName?: string,
): Query {
    // Create column names string for primary key
    const columnNamesString = columnNames
        .map((columnName) => `"${columnName}"`)
        .join(", ");

    // Generate SQL query to add primary key constraint
    return new Query(
        `ALTER TABLE ${this.escapePath(table)} ADD PRIMARY KEY (${columnNamesString})`
    );
}



/**
 * Builds drop primary key sql for DuckDB.
 * Since DuckDB doesn't directly support DROP CONSTRAINT,
 * we need to recreate the table without the primary key.
 */
protected dropPrimaryKeySql(table: Table): Query[] {
    if (!table.primaryColumns.length)
        throw new TypeORMError(`Table ${table} has no primary keys.`)

    // Create column definitions string without primary key constraint
    const columnDefs = table.columns
        .map(column => {
            const columnName = `"${column.name}"`;
            const columnType = this.connection.driver.normalizeType(column);
            const nullability = column.isNullable ? '' : ' NOT NULL';
            // Add any other constraints except primary key
            const defaultValue = column.default !== undefined
                ? ` DEFAULT ${column.default}`
                : '';

            return `${columnName} ${columnType}${nullability}${defaultValue}`;
        })
        .join(', ');

    // Create temporary table name
    const tempTableName = `temp_${table.name}`;

    // Use proper table naming
    const schema = table.schema ? `"${table.schema}".` : '';
    const tablePath = `${schema}"${table.name}"`;
    const tempTablePath = `${schema}"${tempTableName}"`;

    // Generate SQL queries
    return [
        // 1. Create temporary table without primary key constraint
        new Query(
            `CREATE TABLE ${tempTablePath} (${columnDefs})`
        ),
        // 2. Copy data from original table to temporary table
        new Query(
            `INSERT INTO ${tempTablePath} SELECT * FROM ${tablePath}`
        ),
        // 3. Drop original table
        new Query(
            `DROP TABLE ${tablePath}`
        ),
        // 4. Rename temporary table to original table name
        new Query(
            `ALTER TABLE ${tempTablePath} RENAME TO "${table.name}"`
        )
    ];
}



/***
 * Builds create unique constraint sql for DuckDB.
 * Since DuckDB doesn't support ADD CONSTRAINT directly,
 * we need to recreate the table with the unique constraint.
 */
protected createUniqueConstraintSql(
    table: Table,
    uniqueConstraint: TableUnique,
): Query[] {
    // Get column definitions
    const columnDefs = table.columns
        .map(column => {
            const columnName = `"${column.name}"`;
            const columnType = this.connection.driver.normalizeType(column);
            const nullability = column.isNullable ? '' : ' NOT NULL';
            const defaultValue = column.default !== undefined
                ? ` DEFAULT ${column.default}`
                : '';

            return `${columnName} ${columnType}${nullability}${defaultValue}`;
        })
        .join(', ');

    // Create unique constraint definition
    const uniqueColumnNames = uniqueConstraint.columnNames
        .map((column) => `"${column}"`)
        .join(", ");

    // Check if table has a primary key constraint
    const primaryKeyConstraintSql = table.primaryColumns.length > 0
        ? `, PRIMARY KEY (${table.primaryColumns.map(col => `"${col.name}"`).join(', ')})`
        : '';

    // Create unique constraint
    const uniqueConstraintSql = `, CONSTRAINT "${uniqueConstraint.name}" UNIQUE (${uniqueColumnNames})`;

    // Create temporary table name
    const tempTable = new Table();
    tempTable.name = `temp_${table.name}`;
    tempTable.schema = table.schema;
    tempTable.database = table.database;

    // Generate SQL queries
    return [
        // 1. Create temporary table with the unique constraint
        new Query(
            `CREATE TABLE ${this.escapePath(tempTable)} (${columnDefs}${primaryKeyConstraintSql}${uniqueConstraintSql})`
        ),
        // 2. Copy data from original table to temporary table
        new Query(
            `INSERT INTO ${this.escapePath(tempTable)} SELECT * FROM ${this.escapePath(table)}`
        ),
        // 3. Drop original table
        new Query(
            `DROP TABLE ${this.escapePath(table)}`
        ),
        // 4. Rename temporary table to original table name
        new Query(
            `ALTER TABLE ${this.escapePath(tempTable)} RENAME TO "${table.name}"`
        )
    ];
}


/**
 * Builds drop unique constraint sql for DuckDB.
 * Since DuckDB doesn't support DROP CONSTRAINT directly,
 * we need to recreate the table without the unique constraint.
 */
protected dropUniqueConstraintSql(
    table: Table,
    uniqueOrName: TableUnique | string,
): Query[] {
    const uniqueName = InstanceChecker.isTableUnique(uniqueOrName)
        ? uniqueOrName.name
        : uniqueOrName;

    // Get column definitions without the unique constraint we want to drop
    const columnDefs = table.columns
        .map(column => {
            const columnName = `"${column.name}"`;
            const columnType = this.connection.driver.normalizeType(column);
            const nullability = column.isNullable ? '' : ' NOT NULL';
            const defaultValue = column.default !== undefined
                ? ` DEFAULT ${column.default}`
                : '';

            return `${columnName} ${columnType}${nullability}${defaultValue}`;
        })
        .join(', ');

    // Add primary key constraint if it exists
    const primaryKeyConstraintSql = table.primaryColumns.length > 0
        ? `, PRIMARY KEY (${table.primaryColumns.map(col => `"${col.name}"`).join(', ')})`
        : '';

    // Add all unique constraints EXCEPT the one we're dropping
    let uniqueConstraintsSql = '';
    if (table.uniques && table.uniques.length > 0) {
        for (const unique of table.uniques) {
            // Skip the constraint we're dropping
            if (unique.name === uniqueName) continue;

            const uniqueColumnNames = unique.columnNames
                .map((column) => `"${column}"`)
                .join(", ");

            uniqueConstraintsSql += `, CONSTRAINT "${unique.name}" UNIQUE (${uniqueColumnNames})`;
        }
    }

    // Create temporary table name
    const tempTable = new Table();
    tempTable.name = `temp_${table.name}`;
    tempTable.schema = table.schema;
    tempTable.database = table.database;

    // Generate SQL queries
    return [
        // 1. Create temporary table without the unique constraint
        new Query(
            `CREATE TABLE ${this.escapePath(tempTable)} (${columnDefs}${primaryKeyConstraintSql}${uniqueConstraintsSql})`
        ),
        // 2. Copy data from original table to temporary table
        new Query(
            `INSERT INTO ${this.escapePath(tempTable)} SELECT * FROM ${this.escapePath(table)}`
        ),
        // 3. Drop original table
        new Query(
            `DROP TABLE ${this.escapePath(table)}`
        ),
        // 4. Rename temporary table to original table name
        new Query(
            `ALTER TABLE ${this.escapePath(tempTable)} RENAME TO "${table.name}"`
        )
    ];
}



/**
 * Builds create check constraint sql for DuckDB.
 * Since DuckDB doesn't support ADD CONSTRAINT directly,
 * we need to recreate the table with the check constraint.
 */
protected createCheckConstraintSql(
    table: Table,
    checkConstraint: TableCheck,
): Query[] {
    // Get column definitions
    const columnDefs = table.columns
        .map(column => {
            const columnName = `"${column.name}"`;
            const columnType = this.connection.driver.normalizeType(column);
            const nullability = column.isNullable ? '' : ' NOT NULL';
            const defaultValue = column.default !== undefined
                ? ` DEFAULT ${column.default}`
                : '';

            return `${columnName} ${columnType}${nullability}${defaultValue}`;
        })
        .join(', ');

    // Add primary key constraint if it exists
    const primaryKeyConstraintSql = table.primaryColumns.length > 0
        ? `, PRIMARY KEY (${table.primaryColumns.map(col => `"${col.name}"`).join(', ')})`
        : '';

    // Add unique constraints if they exist
    let uniqueConstraintsSql = '';
    if (table.uniques && table.uniques.length > 0) {
        for (const unique of table.uniques) {
            const uniqueColumnNames = unique.columnNames
                .map((column) => `"${column}"`)
                .join(", ");

            uniqueConstraintsSql += `, CONSTRAINT "${unique.name}" UNIQUE (${uniqueColumnNames})`;
        }
    }

    // Add existing check constraints and the new one
    let checkConstraintsSql = '';
    if (table.checks && table.checks.length > 0) {
        for (const check of table.checks) {
            checkConstraintsSql += `, CONSTRAINT "${check.name}" CHECK (${check.expression})`;
        }
    }

    // Add the new check constraint
    checkConstraintsSql += `, CONSTRAINT "${checkConstraint.name}" CHECK (${checkConstraint.expression})`;

    // Create temporary table name
    const tempTable = new Table();
    tempTable.name = `temp_${table.name}`;
    tempTable.schema = table.schema;
    tempTable.database = table.database;

    // Generate SQL queries
    return [
        // 1. Create temporary table with the check constraint
        new Query(
            `CREATE TABLE ${this.escapePath(tempTable)} (${columnDefs}${primaryKeyConstraintSql}${uniqueConstraintsSql}${checkConstraintsSql})`
        ),
        // 2. Copy data from original table to temporary table
        new Query(
            `INSERT INTO ${this.escapePath(tempTable)} SELECT * FROM ${this.escapePath(table)}`
        ),
        // 3. Drop original table
        new Query(
            `DROP TABLE ${this.escapePath(table)}`
        ),
        // 4. Rename temporary table to original table name
        new Query(
            `ALTER TABLE ${this.escapePath(tempTable)} RENAME TO "${table.name}"`
        )
    ];
}

/**
 * Builds drop check constraint sql for DuckDB.
 * Since DuckDB doesn't support DROP CONSTRAINT directly,
 * we need to recreate the table without the check constraint.
 */
protected dropCheckConstraintSql(
    table: Table,
    checkOrName: TableCheck | string,
): Query[] {
    const checkName = InstanceChecker.isTableCheck(checkOrName)
        ? checkOrName.name
        : checkOrName;

    // Get column definitions
    const columnDefs = table.columns
        .map(column => {
            const columnName = `"${column.name}"`;
            const columnType = this.connection.driver.normalizeType(column);
            const nullability = column.isNullable ? '' : ' NOT NULL';
            const defaultValue = column.default !== undefined
                ? ` DEFAULT ${column.default}`
                : '';

            return `${columnName} ${columnType}${nullability}${defaultValue}`;
        })
        .join(', ');

    // Add primary key constraint if it exists
    const primaryKeyConstraintSql = table.primaryColumns.length > 0
        ? `, PRIMARY KEY (${table.primaryColumns.map(col => `"${col.name}"`).join(', ')})`
        : '';

    // Add unique constraints if they exist
    let uniqueConstraintsSql = '';
    if (table.uniques && table.uniques.length > 0) {
        for (const unique of table.uniques) {
            const uniqueColumnNames = unique.columnNames
                .map((column) => `"${column}"`)
                .join(", ");

            uniqueConstraintsSql += `, CONSTRAINT "${unique.name}" UNIQUE (${uniqueColumnNames})`;
        }
    }

    // Add all check constraints EXCEPT the one we're dropping
    let checkConstraintsSql = '';
    if (table.checks && table.checks.length > 0) {
        for (const check of table.checks) {
            // Skip the constraint we're dropping
            if (check.name === checkName) continue;

            checkConstraintsSql += `, CONSTRAINT "${check.name}" CHECK (${check.expression})`;
        }
    }

    // Create temporary table name
    const tempTable = new Table();
    tempTable.name = `temp_${table.name}`;
    tempTable.schema = table.schema;
    tempTable.database = table.database;

    // Generate SQL queries
    return [
        // 1. Create temporary table without the check constraint
        new Query(
            `CREATE TABLE ${this.escapePath(tempTable)} (${columnDefs}${primaryKeyConstraintSql}${uniqueConstraintsSql}${checkConstraintsSql})`
        ),
        // 2. Copy data from original table to temporary table
        new Query(
            `INSERT INTO ${this.escapePath(tempTable)} SELECT * FROM ${this.escapePath(table)}`
        ),
        // 3. Drop original table
        new Query(
            `DROP TABLE ${this.escapePath(table)}`
        ),
        // 4. Rename temporary table to original table name
        new Query(
            `ALTER TABLE ${this.escapePath(tempTable)} RENAME TO "${table.name}"`
        )
    ];
}



/**
 * Builds create foreign key sql for DuckDB.
 * Since DuckDB doesn't support ADD CONSTRAINT directly,
 * we need to recreate the table with the foreign key.
 */
protected createForeignKeySql(
    table: Table,
    foreignKey: TableForeignKey,
): Query[] {
    // Get column definitions
    const columnDefs = table.columns
        .map(column => {
            const columnName = `"${column.name}"`;
            const columnType = this.connection.driver.normalizeType(column);
            const nullability = column.isNullable ? '' : ' NOT NULL';
            const defaultValue = column.default !== undefined
                ? ` DEFAULT ${column.default}`
                : '';

            return `${columnName} ${columnType}${nullability}${defaultValue}`;
        })
        .join(', ');

    // Add primary key constraint if it exists
    const primaryKeyConstraintSql = table.primaryColumns.length > 0
        ? `, PRIMARY KEY (${table.primaryColumns.map(col => `"${col.name}"`).join(', ')})`
        : '';

    // Add unique constraints if they exist
    let uniqueConstraintsSql = '';
    if (table.uniques && table.uniques.length > 0) {
        for (const unique of table.uniques) {
            const uniqueColumnNames = unique.columnNames
                .map((column) => `"${column}"`)
                .join(", ");

            uniqueConstraintsSql += `, CONSTRAINT "${unique.name}" UNIQUE (${uniqueColumnNames})`;
        }
    }

    // Add check constraints if they exist
    let checkConstraintsSql = '';
    if (table.checks && table.checks.length > 0) {
        for (const check of table.checks) {
            checkConstraintsSql += `, CONSTRAINT "${check.name}" CHECK (${check.expression})`;
        }
    }

    // Add existing foreign keys and the new one
    let foreignKeysSql = '';
    if (table.foreignKeys && table.foreignKeys.length > 0) {
        for (const fk of table.foreignKeys) {
            // Skip the foreign key we're adding to avoid duplication
            if (fk.name === foreignKey.name) continue;

            const fkColumnNames = fk.columnNames
                .map((column) => `"${column}"`)
                .join(", ");
            const fkReferencedColumnNames = fk.referencedColumnNames
                .map((column) => `"${column}"`)
                .join(",");

            foreignKeysSql += `, CONSTRAINT "${fk.name}" FOREIGN KEY (${fkColumnNames}) ` +
                `REFERENCES ${this.escapePath(this.getTablePath(fk))}(${fkReferencedColumnNames})`;

            if (fk.onDelete) foreignKeysSql += ` ON DELETE ${fk.onDelete}`;
            if (fk.onUpdate) foreignKeysSql += ` ON UPDATE ${fk.onUpdate}`;
            if (fk.deferrable) foreignKeysSql += ` DEFERRABLE ${fk.deferrable}`;
        }
    }

    // Add the new foreign key
    const columnNames = foreignKey.columnNames
        .map((column) => `"${column}"`)
        .join(", ");
    const referencedColumnNames = foreignKey.referencedColumnNames
        .map((column) => `"${column}"`)
        .join(",");

    foreignKeysSql += `, CONSTRAINT "${foreignKey.name}" FOREIGN KEY (${columnNames}) ` +
        `REFERENCES ${this.escapePath(this.getTablePath(foreignKey))}(${referencedColumnNames})`;

    if (foreignKey.onDelete) foreignKeysSql += ` ON DELETE ${foreignKey.onDelete}`;
    if (foreignKey.onUpdate) foreignKeysSql += ` ON UPDATE ${foreignKey.onUpdate}`;
    if (foreignKey.deferrable) foreignKeysSql += ` DEFERRABLE ${foreignKey.deferrable}`;

    // Create temporary table name
    const tempTable = new Table();
    tempTable.name = `temp_${table.name}`;
    tempTable.schema = table.schema;
    tempTable.database = table.database;

    // Generate SQL queries
    return [
        // 1. Create temporary table with the foreign key
        new Query(
            `CREATE TABLE ${this.escapePath(tempTable)} (${columnDefs}${primaryKeyConstraintSql}${uniqueConstraintsSql}${checkConstraintsSql}${foreignKeysSql})`
        ),
        // 2. Copy data from original table to temporary table
        new Query(
            `INSERT INTO ${this.escapePath(tempTable)} SELECT * FROM ${this.escapePath(table)}`
        ),
        // 3. Drop original table
        new Query(
            `DROP TABLE ${this.escapePath(table)}`
        ),
        // 4. Rename temporary table to original table name
        new Query(
            `ALTER TABLE ${this.escapePath(tempTable)} RENAME TO "${table.name}"`
        )
    ];
}


   /**
     * Builds drop foreign key sql.
     */
    protected dropForeignKeySql(
        table: Table,
        foreignKeyOrName: TableForeignKey | string,
    ): Query {
        const foreignKeyName = InstanceChecker.isTableForeignKey(
            foreignKeyOrName,
        )
            ? foreignKeyOrName.name
            : foreignKeyOrName
        return new Query(
            `ALTER TABLE ${this.escapePath(
                table,
            )} DROP CONSTRAINT "${foreignKeyName}"`,
        )
    }

        /**
     * Drops a foreign keys from the table.
     */
    async dropForeignKeys(
        tableOrName: Table | string,
        foreignKeys: TableForeignKey[],
    ): Promise<void> {
        for (const foreignKey of foreignKeys) {
            await this.dropForeignKey(tableOrName, foreignKey)
        }
    }


        /**
     * Escapes a given comment so it's safe to include in a query.
     */
    protected escapeComment(comment?: string) {
        if (!comment || comment.length === 0) {
            return "NULL"
        }

        comment = comment.replace(/'/g, "''").replace(/\u0000/g, "") // Null bytes aren't allowed in comments

        return `'${comment}'`
    }



    /**
     * Get the table name with table schema
     * Note: Without ' or "
     */
    protected async getTableNameWithSchema(target: Table | string) {
        const tableName = InstanceChecker.isTable(target) ? target.name : target
        if (tableName.indexOf(".") === -1) {
            const schemaResult = await this.query(`SELECT current_schema()`)
            const schema = schemaResult[0]["current_schema"]
            return `${schema}.${tableName}`
        } else {
            return `${tableName.split(".")[0]}.${tableName.split(".")[1]}`
        }
    }



        /**
     * Normalizes type of the column based on the column info.
     */
    protected normalizeType(column: { type: string, length?: number, precision?: number, scale?: number, enumName?: string }): string {
        if (column.type === "enum" && column.enumName) {
            return `"${column.enumName}"`;
        }

        let type = column.type.toLowerCase();

        switch (type) {
            case "integer":
            case "int":
                return "INTEGER";
            case "text":
                return "TEXT";
            case "blob":
                return "BLOB";
            case "real":
            case "float":
            case "double":
                return "DOUBLE";
            case "boolean":
            case "bool":
                return "BOOLEAN";
            case "date":
                return "DATE";
            case "time":
                return "TIME";
            case "datetime":
            case "timestamp":
                return "TIMESTAMP";
            case "varchar":
            case "character varying":
                return column.length ? `VARCHAR(${column.length})` : "VARCHAR";
            case "decimal":
            case "numeric":
                if (column.precision !== undefined && column.scale !== undefined) {
                    return `DECIMAL(${column.precision},${column.scale})`;
                } else if (column.precision !== undefined) {
                    return `DECIMAL(${column.precision})`;
                } else {
                    return "DECIMAL";
                }
            case "uuid":
                return "UUID";
            default:
                return type;
        }
    }

    /**
     * Normalizes default value based on the column info.
     */
    protected normalizeDefault(column: any): string | undefined {
        if (column.dflt_value === null || column.dflt_value === undefined) {
            return undefined;
        }

        // Handle special cases for SQLite/DuckDB default values
        if (typeof column.dflt_value === "string") {
            if (column.dflt_value.startsWith("'") && column.dflt_value.endsWith("'")) {
                return column.dflt_value;
            } else if (column.dflt_value === "CURRENT_TIMESTAMP") {
                return "CURRENT_TIMESTAMP";
            } else if (column.dflt_value === "NULL") {
                return undefined;
            } else {
                return column.dflt_value;
            }
        }

        return `${column.dflt_value}`;
    }


    /**
 * Builds create column sql for DuckDB.
 */
protected buildCreateColumnSql(table: Table, column: TableColumn) {
    let c = '"' + column.name + '"';

    // Use the normalized type instead of directly using column.type
    const normalizedType = this.normalizeType({
        type: column.type,
        length: typeof column.length === "string" ? parseInt(column.length, 10) : column.length,
        precision: column.precision ?? undefined,
        scale: column.scale,
        enumName: column.enumName
    });

    // Handle auto-increment columns
    if (column.isGenerated === true &&
        column.generationStrategy !== "uuid") {

        if (normalizedType === "INTEGER" || normalizedType === "BIGINT") {
            // For integer primary keys, we can use auto-increment
            c += ` ${normalizedType}`;

            // Add auto-increment functionality
            if (column.isPrimary) {
                c += " AUTOINCREMENT";  // If DuckDB supports this syntax
            }
        } else {
            // For non-integer types, just use the type as is
            c += ` ${normalizedType}`;
        }
    } else if (column.type === "enum" || column.type === "simple-enum") {
        // DuckDB doesn't have native enum type, convert to VARCHAR
        if (column.enum && column.enum.length) {
            c += " VARCHAR";
        } else {
            c += " VARCHAR";
        }

        if (column.isArray) c += "[]"; // Array notation for DuckDB
    } else if (!column.isGenerated || column.type === "uuid") {
        // Use the normalized type for regular columns
        c += ` ${normalizedType}`;
    }

    // Handle generated columns
    if (column.asExpression) {
        c += ` AS (${column.asExpression}) VIRTUAL`;
    }

    if (column.isNullable !== true) c += " NOT NULL";

    // Use normalizeDefault to properly format the default value
    const normalizedDefault = this.normalizeDefault(column);
    if (normalizedDefault !== undefined) {
        c += " DEFAULT " + normalizedDefault;
    }

    // Handle UUID generation only if no default is already set
    if (column.isGenerated &&
        column.generationStrategy === "uuid" &&
        normalizedDefault === undefined) {
        // Use DuckDB's UUID generation if available
        c += ` DEFAULT gen_random_uuid()`;
    }

    return c;
}


    /**
     * Process the result from a query into a standardized format.
     */
    protected processResult(result: any): any {
        // Process result types based on what the DuckDB client returns
        if (!result) return [];

        // For newer DuckDB clients that use the node-api
        if (result.columnNames && typeof result.getRows === "function") {
            return result.getRows();
        }

        // For older DuckDB clients
        if (Array.isArray(result)) {
            return result;
        }

        // If result has a data property (some DuckDB drivers)
        if (result.data && Array.isArray(result.data)) {
            return result.data;
        }

        // Default case
        return [];
    }


/**
 * Change table comment for DuckDB.
 * DuckDB supports the COMMENT ON statement with PostgreSQL-compatible syntax.
 */
async changeTableComment(
    tableOrName: Table | string,
    newComment?: string,
): Promise<void> {
    const upQueries: Query[] = [];
    const downQueries: Query[] = [];

    const table = InstanceChecker.isTable(tableOrName)
        ? tableOrName
        : await this.getCachedTable(tableOrName);

    newComment = this.escapeComment(newComment);
    const comment = this.escapeComment(table.comment);

    if (newComment === comment) {
        return;
    }

    const newTable = table.clone();

    // Use the COMMENT ON TABLE syntax supported by DuckDB
    upQueries.push(
        new Query(
            `COMMENT ON TABLE ${this.escapePath(
                newTable,
            )} IS ${newComment}`,
        ),
    );

    downQueries.push(
        new Query(
            `COMMENT ON TABLE ${this.escapePath(table)} IS ${comment}`,
        ),
    );

    await this.executeQueries(upQueries, downQueries);

    table.comment = newTable.comment;
    this.replaceCachedTable(table, newTable);
}



}
