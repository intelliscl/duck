import { Driver } from "../Driver";
import { DriverPackageNotInstalledError } from "../../error/DriverPackageNotInstalledError";
import { DriverOptionNotSetError } from "../../error/DriverOptionNotSetError";
import { PlatformTools } from "../../platform/PlatformTools";
import { DataSource } from "../../data-source/DataSource";
import { CteCapabilities } from "../types/CteCapabilities";
import { ColumnType } from "../types/ColumnTypes";
import { MappedColumnTypes } from "../types/MappedColumnTypes";
import { ColumnMetadata } from "../../metadata/ColumnMetadata";
import { DuckDBQueryRunner } from "./DuckDBQueryRunner";
import { ObjectLiteral } from "../../common/ObjectLiteral";
import { TableColumn } from "../../schema-builder/table/TableColumn";
import { EntityMetadata } from "../../metadata/EntityMetadata";
import { DateUtils } from "../../util/DateUtils";
import { ApplyValueTransformers } from "../../util/ApplyValueTransformers";
import { ReplicationMode } from "../types/ReplicationMode";
import { Table } from "../../schema-builder/table/Table";
import { DataTypeDefaults } from "../types/DataTypeDefaults";
import { View } from "../../schema-builder/view/View";
import { TableForeignKey } from "../../schema-builder/table/TableForeignKey";
import { UpsertType } from "../types/UpsertType";
import { OnDeleteType } from "../../metadata/types/OnDeleteType";
import { OnUpdateType } from "../../metadata/types/OnUpdateType";
import { DuckDBConnectionOptions } from "./DuckDBConnectionOptions";
import { DuckDBInstance, DuckDBConnection } from '@duckdb/node-api';
import duckdb from '@duckdb/node-api';
//import {duckdb} from '@duckdb/node-api';
/**
 * Organizes communication with DuckDB RDBMS.
 */
export class DuckDBDriver implements Driver {
    connection: DataSource;
    options: DuckDBConnectionOptions;
    duckdbInstance?: DuckDBInstance
    duckdbConnection?: DuckDBConnection



    // -------------------------------------------------------------------------
    // Constructor
    // -------------------------------------------------------------------------

    constructor(connection: DataSource) {
        this.connection = connection;
        this.options = connection.options as DuckDBConnectionOptions;
        if (!this.options.type) throw new DriverOptionNotSetError("type");
        const database = this.options.database || ":memory:";
        this.loadDependencies();
    }


        protected loadDependencies(): void {
        try {
            require("@duckdb/node-api");
        } catch (e) {
            throw new DriverPackageNotInstalledError("@duckdb", "@duckdb/node-api");
        }
    }

    // -------------------------------------------------------------------------
    // Public Implemented Properties
    // -------------------------------------------------------------------------



    /**
     * Creates a generated map for an entity.
     */
      createGeneratedMap(metadata: EntityMetadata, insertResult: ObjectLiteral): ObjectLiteral | undefined {
        // DuckDB does not return generated columns in the same way as some other DBs.
        // If insertResult contains generated columns, map them to entity properties.
        if (!insertResult) return undefined;

        const generatedMap: ObjectLiteral = {};
        for (const column of metadata.generatedColumns) {
            // DuckDB does not support RETURNING, so insertResult may not have the value.
            // If the value is present, map it.
            if (Object.prototype.hasOwnProperty.call(insertResult, column.databaseName)) {
                generatedMap[column.propertyName] = insertResult[column.databaseName];
            }
        }
        // If nothing was mapped, return undefined for consistency with TypeORM drivers.
        return Object.keys(generatedMap).length > 0 ? generatedMap : undefined;
    }


    /**
     * Finds changed columns between column metadatas.
     * Not implemented for DuckDB, return an empty array.
     */
    findChangedColumns(tableColumns: TableColumn[], columnMetadatas: ColumnMetadata[]): ColumnMetadata[] {
    // DuckDB-specific: compare only supported properties
    return columnMetadatas.filter(metadata => {
        const tableColumn = tableColumns.find(tc => tc.name === metadata.databaseName);
        if (!tableColumn) return false; // New column, not changed

        // Compare relevant properties supported by DuckDB
        if (
            tableColumn.type !== this.normalizeType(metadata) ||
            (tableColumn.length && tableColumn.length.toString()) !== this.getColumnLength(metadata) ||
            (tableColumn.precision ?? undefined) !== this.getColumnPrecision(metadata) ||
            (tableColumn.scale ?? undefined) !== this.getColumnScale(metadata) ||
            (tableColumn.default ?? undefined) !== this.normalizeDefault(metadata) ||
            tableColumn.isNullable !== metadata.isNullable ||
            (tableColumn.isUnique ?? false) !== this.normalizeIsUnique(metadata)
        ) {
            return true;
        }
        return false;
    });
}

    /**
     * Creates a parameter placeholder for a given index.
     */
    createParameter(parameterName: string, index: number): string {
        return `$${index + 1}`;
    }

    /**
     * Normalizes column type for DuckDB.
     */
    normalizeType(column: ColumnMetadata): string {
        // Basic normalization, extend as needed
        if (typeof column.type === "string") {
            return column.type.toLowerCase();
        }
        return "";
    }

    /**
     * Normalizes default value for DuckDB.
     */
    normalizeDefault(columnMetadata: ColumnMetadata): string | undefined {
        if (typeof columnMetadata.default === "function") {
            return columnMetadata.default();
        }
        return columnMetadata.default !== undefined ? `${columnMetadata.default}` : undefined;
    }

    /**
     * Normalizes isUnique property for DuckDB.
     */
    normalizeIsUnique(column: ColumnMetadata): boolean {
        return !!(column as any).isUnique;
    }

    /**
     * Gets column length.
     */
    getColumnLength(column: ColumnMetadata): string {
        if (column.length) return column.length.toString();
        if (typeof column.type === "string" && this.dataTypeDefaults[column.type.toUpperCase()]) {
            return this.dataTypeDefaults[column.type.toUpperCase()].length?.toString() || "";
        }
        return "";
    }

    /**
     * Gets column precision.
     */
    getColumnPrecision(column: ColumnMetadata): number | undefined {
        if (column.precision !== undefined)
            return column.precision === null ? undefined : column.precision;
        if (typeof column.type === "string" && this.dataTypeDefaults[column.type.toUpperCase()]) {
            return this.dataTypeDefaults[column.type.toUpperCase()].precision;
        }
        return undefined;
    }

    /**
     * Gets column scale.
     */
    getColumnScale(column: ColumnMetadata): number | undefined {
        if (column.scale !== undefined) return column.scale;
        if (typeof column.type === "string" && this.dataTypeDefaults[column.type.toUpperCase()]) {
            return this.dataTypeDefaults[column.type.toUpperCase()].scale;
        }
        return undefined;
    }




    /**
     * Checks if the driver supports RETURNING clause.
     */
    isReturningSqlSupported(): boolean {
        return false;
    }

    /**
     * Checks if the driver supports uuid generation.
     */
    isUUIDGenerationSupported(): boolean {
        return true;
    }
    /**
    * Returns the SQL expression to generate a UUID in DuckDB.
     */
    getUUIDFunction(): string {
    // DuckDB supports the uuid() function for generating UUIDs
    return "uuid()";
}

    /**
     * Checks if the driver supports fulltext indices.
     */
    isFullTextColumnTypeSupported(): boolean {
        // If the extension is loaded, support is available.
        // Optionally, you could track loaded extensions and check here.
        return !!this.fullTextSearchEnabled;
    }
    /**
     * Internal flag to track if full_text_search extension is enabled.
     */
    private fullTextSearchEnabled: boolean = false;



    /**
     * Checks if the driver supports array column types.
     */
    isArrayColumnTypeSupported(): boolean {
        return true;
    }




    /**
     * DuckDB underlying library.
     */
    duckdb: any;


    /**
     * Database name used to perform all write queries.
     */
    database?: string;

    /**
     * Schema name used to perform all write queries.
     */
    schema?: string;

    /**
     * Indicates if replication is enabled.
     */
    isReplicated: boolean = false;

    /**
     * Indicates if tree tables are supported by this driver.
     */
    treeSupport: boolean = true;

    /**
     * Represents transaction support level in the driver.
     */
    transactionSupport:  "simple" | "none" = "simple";

    /**
     * Gets list of supported column data types by a driver.
     *
     * @see https://duckdb.org/docs/sql/data_types/overview.html
     */
    supportedDataTypes: ColumnType[] = [
        "bigint",
        "bit",
        "blob",
        "boolean",
        "date",
        "decimal",
        "double",
        "float",
        "hugeint",
        "integer",
        "interval",
        "smallint",
        "text",
        "time",
        "timestamp",
        "tinyint",
        "uuid",
        "varchar",
        // Nested types
        "array",
        "list",
        "map",
        "struct",
        "union"
    ];

    /**
     * Returns type of upsert supported by driver if any
     */
    supportedUpsertTypes: UpsertType[] = [];

    /**
     * Gets list of spatial column data types.
     */
    spatialTypes: ColumnType[] = [];

    /**
     * Gets list of column data types that support length by a driver.
     */
    withLengthColumnTypes: ColumnType[] = [
        "varchar",
        "bit"
    ];

    /**
     * Gets list of column data types that support precision by a driver.
     */
    withPrecisionColumnTypes: ColumnType[] = [
        "decimal"
    ];

    /**
     * Gets list of column data types that support scale by a driver.
     */
    withScaleColumnTypes: ColumnType[] = [
        "decimal"
    ];

    /**
     * Orm has special columns and we need to know what database column types should be for those types.
     * Column types are driver dependant.
     */
    mappedDataTypes: MappedColumnTypes = {
        createDate: "timestamp",
        createDateDefault: "current_timestamp",
        updateDate: "timestamp",
        updateDateDefault: "current_timestamp",
        deleteDate: "timestamp",
        deleteDateNullable: true,
        version: "integer",
        treeLevel: "integer",
        migrationId: "integer",
        migrationName: "varchar",
        migrationTimestamp: "bigint",
        cacheId: "integer",
        cacheIdentifier: "varchar",
        cacheTime: "bigint",
        cacheDuration: "integer",
        cacheQuery: "text",
        cacheResult: "text",
        metadataType: "varchar",
        metadataDatabase: "varchar",
        metadataSchema: "varchar",
        metadataTable: "varchar",
        metadataName: "varchar",
        metadataValue: "text",
    };

    /**
     * Default values of length, precision and scale depends on column data type.
     * Used in the cases when length/precision/scale is not specified by user.
     */
    dataTypeDefaults: DataTypeDefaults = {
        "VARCHAR": { length: 255 },
        "DECIMAL": { precision: 18, scale: 3 },
    };

    /**
     * Max length allowed by DuckDB for aliases.
     */
    maxAliasLength?: number;

    cteCapabilities: CteCapabilities = {
        enabled: true,
        materializedHint: false,
        requiresRecursiveHint: true
    };

    /**
     * Gets list of supported ON DELETE types by a driver.
     */
    supportedOnDeleteTypes: OnDeleteType[] = [
        "RESTRICT",
        "CASCADE",
        "SET NULL",
        "NO ACTION"
    ];

    /**
     * Gets list of supported ON UPDATE types by a driver.
     */
    supportedOnUpdateTypes: OnUpdateType[] = [
        "RESTRICT",
        "CASCADE",
        "SET NULL",
        "NO ACTION"
    ];

    /**
     * Default schema name.
     */
    defaultSchema: string = "main";

    /**
     * Indicates if connection pooling is supported.
     * DuckDB is in-process, so pooling is not applicable.
     */
    isPoolSupported: boolean = false;

    /**
     * Indicates if this driver supports creating indices.
     */
    isIndexSupported: boolean = true;

    /**
     * Indicates if this driver supports creating foreign keys.
     */
    isForeignKeySupported: boolean = true;

    /**
     * Indicates if this driver supports unique constraints.
     */
    isUniqueConstraintSupported: boolean = true;



    /**
     * List of query runners that are connected to the database.
     */
    connectedQueryRunners: DuckDBQueryRunner[] = [];

    /**
     * Logging hook for queries and errors.
     */
    logQuery(query: string, parameters?: any[]): void {
        if (this.options.logging) {
            console.log("[DuckDB Query]:", query, parameters || "");
        }
    }

    logError(error: any, query?: string, parameters?: any[]): void {
        if (this.options.logging) {
            console.error("[DuckDB Error]:", error, query || "", parameters || "");
        }
    }



    // -------------------------------------------------------------------------
    // Public Methods
    // -------------------------------------------------------------------------


      /**
     * Connect to DuckDB using the official node-api.
     */
    async connect(): Promise<void> {
        try {
            this.duckdbInstance = await DuckDBInstance.create(this.options.database || ":memory:");
            this.duckdbConnection = await this.duckdbInstance.connect();

            // Apply DuckDB config flags
            if (this.options.duckdbConfig) {
                for (const [key, value] of Object.entries(this.options.duckdbConfig)) {
                    await this.duckdbConnection.execute(`SET ${key}='${value}'`);
                }
            }

            // Install and load extensions
            if (this.options.extensions && Array.isArray(this.options.extensions)) {
                for (const ext of this.options.extensions) {
                    await this.duckdbConnection.execute(`INSTALL ${ext}`);
                    await this.duckdbConnection.execute(`LOAD ${ext}`);
                }
            }

            // Enable foreign keys if requested
            if (this.options.foreignKeys) {
                await this.duckdbConnection.execute("PRAGMA foreign_keys = ON;");
            }
        } catch (error) {
            throw new Error(`Error connecting to DuckDB: ${error instanceof Error ? error.message : String(error)}`);
        }
    }

    /**
     * Disconnect from DuckDB.
     */
    async disconnect(): Promise<void> {
        if (this.duckdbConnection) {
            await this.duckdbConnection.close();
            this.duckdbConnection = undefined;
        }
        if (this.duckdbInstance) {
            await this.duckdbInstance.close();
            this.duckdbInstance = undefined;
        }
    }



    /**
     * DuckDB does not support replication, so this returns the master connection.
     */
    async obtainSlaveConnection(): Promise<any> {
        return this.obtainMasterConnection();
    }



    /**
     * Before connect hook.
     */
    async beforeConnect(): Promise<void> {
        // No-op, but available for extension
    }

    /**
     * After disconnect hook.
     */
    async afterDisconnect(): Promise<void> {
        // No-op, but available for extension
    }


    /**
     * Makes any action after connection (e.g. create extensions in Postgres driver).
     */
    async afterConnect(): Promise<void> {
        // Nothing to do for DuckDB
    }




    /**
     * Creates a schema builder used to build and sync a schema.
     * DuckDB does not support full schema sync. Use migrations or manual schema management.
     * @throws Error if synchronize: true is used.
     */
    createSchemaBuilder() {
        return {
            build: async () => {
                throw new Error(
                    "Schema builder is not implemented for DuckDB driver. " +
                    "Automatic schema synchronization (synchronize: true) and auto-migrations are not supported. " +
                    "Please use migrations or manage your schema manually."
                );
            },
            log: async () => ({
                upQueries: [],
                downQueries: [],
            }),
        };
    }

    /**
     * Creates full type with length/precision/scale for DuckDB, including generated columns.
     */
    createFullType(column: TableColumn): string {
        let type = column.type;
        if (this.withLengthColumnTypes.includes(type as ColumnType) && column.length) {
            type += `(${column.length})`;
        } else if (this.withPrecisionColumnTypes.includes(type as ColumnType) && column.precision !== undefined && column.scale !== undefined) {
            type += `(${column.precision},${column.scale})`;
        } else if (this.withPrecisionColumnTypes.includes(type as ColumnType) && column.precision !== undefined) {
            type += `(${column.precision})`;
        }
        // DuckDB generated columns
        if (column.asExpression) {
            type += ` GENERATED ALWAYS AS (${column.asExpression}) STORED`;
        }
        return type;
    }

    /**
     * Adds a comment to a table.
     */
    async setTableComment(tableName: string, comment: string): Promise<void> {
        await this.duckdbConnection.run(`COMMENT ON TABLE ${this.escape(tableName)} IS '${comment.replace(/'/g, "''")}'`);
    }

    /**
     * Adds a comment to a column.
     */
    async setColumnComment(tableName: string, columnName: string, comment: string): Promise<void> {
        await this.duckdbConnection.run(`COMMENT ON COLUMN ${this.escape(tableName)}.${this.escape(columnName)} IS '${comment.replace(/'/g, "''")}'`);
    }

    /**
     * Creates a view.
     */
    async createView(viewName: string, expression: string, replace: boolean = false): Promise<void> {
        const replaceClause = replace ? "OR REPLACE " : "";
        await this.duckdbConnection.run(`CREATE ${replaceClause}VIEW ${this.escape(viewName)} AS ${expression}`);
    }

    /**
     * Drops a view.
     */
    async dropView(viewName: string, ifExists: boolean = true): Promise<void> {
        const ifExistsClause = ifExists ? "IF EXISTS " : "";
        await this.duckdbConnection.run(`DROP VIEW ${ifExistsClause}${this.escape(viewName)}`);
    }

    /**
     * Updates a view (by dropping and recreating).
     */
    async updateView(viewName: string, expression: string): Promise<void> {
        await this.dropView(viewName, true);
        await this.createView(viewName, expression, false);
    }

    /**
     * Creates a CHECK constraint.
     */
    async createCheckConstraint(tableName: string, constraintName: string, expression: string): Promise<void> {
        await this.duckdbConnection.run(
            `ALTER TABLE ${this.escape(tableName)} ADD CONSTRAINT ${this.escape(constraintName)} CHECK (${expression})`
        );
    }

    /**
     * Drops a CHECK constraint.
     */
    async dropCheckConstraint(tableName: string, constraintName: string): Promise<void> {
        await this.duckdbConnection.run(
            `ALTER TABLE ${this.escape(tableName)} DROP CONSTRAINT ${this.escape(constraintName)}`
        );
    }

    /**
     * Throws error for exclusion constraints (not supported in DuckDB).
     */
    async createExclusionConstraint(): Promise<void> {
        throw new Error("Exclusion constraints are not supported by DuckDB.");
    }
    async dropExclusionConstraint(): Promise<void> {
        throw new Error("Exclusion constraints are not supported by DuckDB.");
    }

    /**
     * Savepoint helpers for nested transactions.
     */
    async startSavepoint(connection: any, name: string): Promise<void> {
        await connection.run(`SAVEPOINT ${this.escape(name)}`);
    }
    async releaseSavepoint(connection: any, name: string): Promise<void> {
        await connection.run(`RELEASE SAVEPOINT ${this.escape(name)}`);
    }
    async rollbackSavepoint(connection: any, name: string): Promise<void> {
        await connection.run(`ROLLBACK TO SAVEPOINT ${this.escape(name)}`);
    }

    /**
     * Extension awareness: tracks all loaded extensions.
     */
    private loadedExtensions: Set<string> = new Set();

    /**
     * Loads DuckDB extensions if specified in options.
     */
    async loadExtensions(): Promise<void> {
        if (this.options.extensions && Array.isArray(this.options.extensions)) {
            for (const ext of this.options.extensions) {
                await this.duckdbConnection.run(`INSTALL ${ext}`);
                await this.duckdbConnection.run(`LOAD ${ext}`);
                this.loadedExtensions.add(ext);
                if (ext === "fts" || ext === "full_text_search") {
                    this.fullTextSearchEnabled = true;
                }
            }
        }
    }

    /**
     * Checks if an extension is loaded.
     */
    isExtensionLoaded(extension: string): boolean {
        return this.loadedExtensions.has(extension);
    }
    /**
     * Obtains a new database connection.
     */
    async obtainMasterConnection(): Promise<any> {
        if (!this.duckdbInstance) {
            await this.connect();
        }
        return this.duckdbConnection;
    }

    /**
     * Releases a database connection.
     */
    async releaseMasterConnection(connection: any): Promise<void> {
        // DuckDB is in-process, nothing to release
    }


    /**
     * Creates a new index on a table.
     */
    async createIndex(tableName: string, indexName: string, columnNames: string[], isUnique: boolean = false): Promise<void> {
        const unique = isUnique ? "UNIQUE " : "";
        const columns = columnNames.map(name => this.escape(name)).join(", ");
        const sql = `CREATE ${unique}INDEX ${this.escape(indexName)} ON ${this.escape(tableName)} (${columns})`;
        await this.duckdbConnection.run(sql);
    }

    /**
     * Drops an index from a table.
     */
    async dropIndex(indexName: string): Promise<void> {
        const sql = `DROP INDEX IF EXISTS ${this.escape(indexName)}`;
        await this.duckdbConnection.run(sql);
    }

    /**
     * Creates a foreign key on a table.
     */
    async createForeignKey(tableName: string, columnNames: string[], referencedTable: string, referencedColumnNames: string[], onDelete?: string, onUpdate?: string): Promise<void> {
        const fkName = `fk_${tableName}_${columnNames.join("_")}`;
        const columns = columnNames.map(name => this.escape(name)).join(", ");
        const refColumns = referencedColumnNames.map(name => this.escape(name)).join(", ");
        let sql = `ALTER TABLE ${this.escape(tableName)} ADD CONSTRAINT ${this.escape(fkName)} FOREIGN KEY (${columns}) REFERENCES ${this.escape(referencedTable)} (${refColumns})`;
        if (onDelete) sql += ` ON DELETE ${onDelete}`;
        if (onUpdate) sql += ` ON UPDATE ${onUpdate}`;
        await this.duckdbConnection.run(sql);
    }

    /**
     * Drops a foreign key from a table.
     */
    async dropForeignKey(tableName: string, fkName: string): Promise<void> {
        const sql = `ALTER TABLE ${this.escape(tableName)} DROP CONSTRAINT ${this.escape(fkName)}`;
        await this.duckdbConnection.run(sql);
    }

    /**
     * Creates a unique constraint on a table.
     */
    async createUniqueConstraint(tableName: string, columnNames: string[], constraintName?: string): Promise<void> {
        const name = constraintName || `uq_${tableName}_${columnNames.join("_")}`;
        const columns = columnNames.map(name => this.escape(name)).join(", ");
        const sql = `ALTER TABLE ${this.escape(tableName)} ADD CONSTRAINT ${this.escape(name)} UNIQUE (${columns})`;
        await this.duckdbConnection.run(sql);
    }

    /**
     * Drops a unique constraint from a table.
     */
    async dropUniqueConstraint(tableName: string, constraintName: string): Promise<void> {
        const sql = `ALTER TABLE ${this.escape(tableName)} DROP CONSTRAINT ${this.escape(constraintName)}`;
        await this.duckdbConnection.run(sql);
    }

    /**
     * Escapes identifiers (table, column, index, constraint names) robustly.
     */
    escape(identifier: string): string {
        // DuckDB uses double quotes for identifiers, escape any double quotes in the name
        return `"${identifier.replace(/"/g, '""')}"`;
    }

    /**
     * Build full table name with schema name and table name.
     * E.g. myDB.mySchema.myTable
     */
    buildTableName(tableName: string, schema?: string): string {
        if (schema) {
            return `${schema}.${tableName}`;
        }
        return tableName;
    }

    /**
     * Parse a target table name or other type and return a normalized table definition.
     */
    parseTableName(target: EntityMetadata | Table | View | TableForeignKey | string): { database?: string, schema?: string, tableName: string } {
        if (target instanceof EntityMetadata) {
            return {
                schema: target.schema,
                tableName: target.tableName
            };
        }

        if (target instanceof Table) {
            return {
                schema: target.schema,
                tableName: target.name
            };
        }

        if (target instanceof View) {
            return {
                schema: target.schema,
                tableName: target.name
            };
        }

        if (target instanceof TableForeignKey) {
            return {
                schema: target.referencedSchema,
                tableName: target.referencedTableName
            };
        }

        const parts = (typeof target === "string" ? target : "").split(".");

        if (parts.length === 3) {
            return {
                database: parts[0],
                schema: parts[1],
                tableName: parts[2]
            };
        } else if (parts.length === 2) {
            return {
                schema: parts[0],
                tableName: parts[1]
            };
        } else {
            return {
                tableName: typeof target === "string" ? target : ""
            };
        }
    }

    /**
     * Prepares given value to a value to be persisted, based on its column type and metadata.
     * Extended for DuckDB nested types.
     */
    preparePersistentValue(value: any, columnMetadata: ColumnMetadata): any {
        if (value === null || value === undefined)
            return value;

        if (columnMetadata.transformer)
            value = ApplyValueTransformers.transformTo(columnMetadata.transformer, value);

        if (value === null || value === undefined)
            return value;

        if (columnMetadata.type === "boolean" || columnMetadata.type === Boolean) {
            return value === true ? 1 : 0;
        } else if (columnMetadata.type === "date") {
            return DateUtils.mixedDateToDateString(value);
        } else if (columnMetadata.type === "time") {
            return DateUtils.mixedDateToTimeString(value);
        } else if (columnMetadata.type === "timestamp" || columnMetadata.type === "datetime") {
            return DateUtils.mixedDateToDate(value).toISOString();
        } else if (columnMetadata.type === "simple-array") {
            return DateUtils.simpleArrayToString(value);
        } else if (columnMetadata.type === "simple-json") {
            return DateUtils.simpleJsonToString(value);
        } else if (columnMetadata.type === "simple-enum") {
            return DateUtils.simpleEnumToString(value);
        } else if (columnMetadata.type === "uuid") {
            return value;
        } else if (
            columnMetadata.type === "json" ||
            columnMetadata.type === "list" ||
            columnMetadata.type === "array" ||
            columnMetadata.type === "struct" ||
            columnMetadata.type === "map" ||
            columnMetadata.type === "union"
        ) {
            return JSON.stringify(value);
        }

        return value;
    }

    /**
     * Prepares given value to a value to be hydrated, based on its column type and metadata.
     * Extended for DuckDB nested types.
     */
    prepareHydratedValue(value: any, columnMetadata: ColumnMetadata): any {
        if (value === null || value === undefined)
            return columnMetadata.transformer ? ApplyValueTransformers.transformFrom(columnMetadata.transformer, value) : value;

        if (columnMetadata.type === "boolean" || columnMetadata.type === Boolean) {
            value = Boolean(value);
        } else if (columnMetadata.type === "timestamp" || columnMetadata.type === "datetime") {
            value = DateUtils.normalizeHydratedDate(value);
        } else if (columnMetadata.type === "date") {
            value = DateUtils.mixedDateToDateString(value);
        } else if (columnMetadata.type === "time") {
            value = DateUtils.mixedTimeToString(value);
        } else if (columnMetadata.type === "simple-array") {
            value = DateUtils.stringToSimpleArray(value);
        } else if (columnMetadata.type === "simple-json") {
            value = DateUtils.stringToSimpleJson(value);
        } else if (columnMetadata.type === "simple-enum") {
            value = DateUtils.stringToSimpleEnum(value, columnMetadata);
        } else if (columnMetadata.type === "uuid") {
            // No conversion needed for uuid in DuckDB
        } else if (
            columnMetadata.type === "json" ||
            columnMetadata.type === "list" ||
            columnMetadata.type === "array" ||
            columnMetadata.type === "struct" ||
            columnMetadata.type === "map" ||
            columnMetadata.type === "union"
        ) {
            value = typeof value === "string" ? JSON.parse(value) : value;
        }

        if (columnMetadata.transformer)
            value = ApplyValueTransformers.transformFrom(columnMetadata.transformer, value);

        return value;
    }

    /**
     * Replaces parameters in the given SQL with special escaping character
     * and an array of parameter names to be passed to a query.
     */
    escapeQueryWithParameters(
        sql: string,
        parameters: ObjectLiteral,
        nativeParameters: ObjectLiteral,
    ): [string, any[]] {
        const escapedParameters: any[] = Object.keys(nativeParameters).map(key => nativeParameters[key]);
        if (!parameters || !Object.keys(parameters).length)
            return [sql, escapedParameters];

        sql = sql.replace(/:(\.\.\.)?([A-Za-z0-9_.]+)/g, (full, isArray: string, key: string): string => {
            if (!parameters.hasOwnProperty(key)) {
                return full;
            }

            let value: any = parameters[key];

            if (isArray) {
                return value.map((v: any) => {
                    escapedParameters.push(v);
                    return `$${escapedParameters.length}`;
                }).join(", ");
            }

            escapedParameters.push(value);
            return `$${escapedParameters.length}`;
        });

        return [sql, escapedParameters];
    }

    /**
     * Creates a query runner used to execute database queries.
     */
    createQueryRunner(mode: ReplicationMode) {
        return new DuckDBQueryRunner(this, mode);
    }

    // -------------------------------------------------------------------------
    // Protected Methods
    // -------------------------------------------------------------------------

    /**
     * If driver dependency is not given explicitly, then try to load it via require.
     */
    protected loadDependencies(): void {

            let duckdbPath = "";
            try {
                // Try to load the official node-api version first
                duckdbPath = this.options.nativeBinding || "@duckdb/node-api";
                this.duckdb = PlatformTools.load(duckdbPath);
            } catch (e)  {
            throw new DriverPackageNotInstalledError("@duckdb", "@duckdb/node-api");

            }

        }
    /**
     * Used to check if a given table exists in the database.
     */
    async hasTable(tableName: string): Promise<boolean> {
        const sql = `SELECT name FROM sqlite_master WHERE type = 'table' AND name = '${tableName}'`;
        const result = await this.duckdbConnection.run(sql);
        return result.length > 0;
    }

    /**
     * Used to check if a given column exists in the table.
     */
    async hasColumn(tableName: string, columnName: string): Promise<boolean> {
        const sql = `PRAGMA table_info('${tableName}')`;
        const result = await this.duckdbConnection.run(sql);
        return !!result.find((column: any) => column.name === columnName);
    }
}
