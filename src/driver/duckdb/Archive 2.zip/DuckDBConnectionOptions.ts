import { BaseDataSourceOptions } from "../../data-source/BaseDataSourceOptions"

/**
 * DuckDB-specific connection options.
 */
export interface DuckDBConnectionOptions extends BaseDataSourceOptions {
    /**
     * Database type.
     */
  //  readonly type: "duckdb";

    /**
     * Database name or path to database file.
     * Default is ":memory:" for in-memory database.
     */
    readonly database: string;

    readonly extensions?: string[];

    /**
     * Access mode for the database.
     * Can be "read_only", "read_write", or undefined for default.
     */
    readonly accessMode?: "read_only" | "read_write";

    /**
     * DuckDB configuration options.
     * These are key-value pairs passed to DuckDB during initialization.
     */
    readonly duckdbConfig?: { [key: string]: string };

    /**
     * Optional function to be executed on the database instance before it's used.
     * Useful for setting up custom configuration or extensions.
     */
    readonly prepareDatabase?: (db: any) => void;

    /**
     * Maximum number of concurrent connections to the database.
     * Default is 1.
     */
    readonly poolSize?: number;

    /**
     * Enables logging of executed SQL queries.
     */
    readonly logging?: boolean;

    /**
     * If set to true, foreign key constraints will be checked.
     */
    readonly foreignKeys?: boolean;

    /**
     * Path to the native module instance.
     * Useful for non-standard installations.
     */
    readonly nativeBinding?: string;
}
