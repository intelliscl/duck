import "reflect-metadata";
import { DataSource } from "typeorm";
import { DuckDBDriver } from "../src/driver/duckdb/DuckDBDriver";
import { DuckDBQueryRunner } from "../src/driver/duckdb/DuckDBQueryRunner";
import { User } from "./entity/User";
import { Post } from "./entity/Post";
import { Category } from "./entity/Category";
import { expect } from "chai";
import * as sinon from "sinon";

describe("DuckDBDriver", () => {
    let dataSource: DataSource;
    let driver: DuckDBDriver;
    let queryRunner: DuckDBQueryRunner;

    // Setup before tests
    beforeEach(async () => {
        // Create an in-memory DuckDB database for testing
        dataSource = new DataSource({
            type: "duckdb",
            database: ":memory:",
            entities: [User, Post, Category],
            synchronize: true,
            logging: false
        });

        await dataSource.initialize();
        driver = dataSource.driver as DuckDBDriver;
        queryRunner = dataSource.createQueryRunner() as DuckDBQueryRunner;
        await queryRunner.connect();
    });

    // Cleanup after tests
    afterEach(async () => {
        await queryRunner.release();
        await dataSource.destroy();
    });

    describe("Connection", () => {
        it("should connect to DuckDB database", () => {
            expect(dataSource.isInitialized).to.be.true;
            expect(driver.duckdbConnection).to.exist;
        });

        it("should create a query runner", () => {
            expect(queryRunner).to.be.instanceOf(DuckDBQueryRunner);
        });
    });

    describe("Basic Operations", () => {
        it("should create a table", async () => {
            // Create a test table
            await queryRunner.query(`
                CREATE TABLE test_table (
                    id INTEGER PRIMARY KEY,
                    name VARCHAR,
                    active BOOLEAN
                )
            `);

            // Check if table exists
            const result = await queryRunner.query(
                `SELECT name FROM sqlite_master WHERE type='table' AND name='test_table'`
            );

            expect(result).to.have.lengthOf(1);
            expect(result[0].name).to.equal('test_table');
        });

        it("should insert and retrieve data", async () => {
            // Create a test table
            await queryRunner.query(`
                CREATE TABLE test_table (
                    id INTEGER PRIMARY KEY,
                    name VARCHAR,
                    active BOOLEAN
                )
            `);

            // Insert test data
            await queryRunner.query(`
                INSERT INTO test_table (id, name, active) VALUES
                (1, 'Test 1', true),
                (2, 'Test 2', false),
                (3, 'Test 3', true)
            `);

            // Retrieve data
            const result = await queryRunner.query(`SELECT * FROM test_table ORDER BY id`);

            expect(result).to.have.lengthOf(3);
            expect(result[0].id).to.equal(1);
            expect(result[0].name).to.equal('Test 1');
            expect(result[0].active).to.be.true;
            expect(result[1].id).to.equal(2);
            expect(result[1].active).to.be.false;
        });

        it("should update data", async () => {
            // Create and populate test table
            await queryRunner.query(`
                CREATE TABLE test_table (
                    id INTEGER PRIMARY KEY,
                    name VARCHAR,
                    active BOOLEAN
                )
            `);

            await queryRunner.query(`
                INSERT INTO test_table (id, name, active) VALUES
                (1, 'Test 1', true)
            `);

            // Update data
            await queryRunner.query(`
                UPDATE test_table SET name = 'Updated Test', active = false WHERE id = 1
            `);

            // Verify update
            const result = await queryRunner.query(`SELECT * FROM test_table WHERE id = 1`);

            expect(result).to.have.lengthOf(1);
            expect(result[0].name).to.equal('Updated Test');
            expect(result[0].active).to.be.false;
        });

        it("should delete data", async () => {
            // Create and populate test table
            await queryRunner.query(`
                CREATE TABLE test_table (
                    id INTEGER PRIMARY KEY,
                    name VARCHAR
                )
            `);

            await queryRunner.query(`
                INSERT INTO test_table (id, name) VALUES
                (1, 'Test 1'),
                (2, 'Test 2'),
                (3, 'Test 3')
            `);

            // Delete data
            await queryRunner.query(`DELETE FROM test_table WHERE id = 2`);

            // Verify deletion
            const result = await queryRunner.query(`SELECT * FROM test_table ORDER BY id`);

            expect(result).to.have.lengthOf(2);
            expect(result[0].id).to.equal(1);
            expect(result[1].id).to.equal(3);
        });
    });

    describe("Parameter Binding", () => {
        it("should support positional parameters", async () => {
            // Create test table
            await queryRunner.query(`
                CREATE TABLE test_table (
                    id INTEGER PRIMARY KEY,
                    name VARCHAR,
                    value INTEGER
                )
            `);

            // Insert with parameters
            await queryRunner.query(
                `INSERT INTO test_table (id, name, value) VALUES (?, ?, ?)`,
                [1, 'Test Name', 42]
            );

            // Query with parameters
            const result = await queryRunner.query(
                `SELECT * FROM test_table WHERE id = ? AND value > ?`,
                [1, 40]
            );

            expect(result).to.have.lengthOf(1);
            expect(result[0].name).to.equal('Test Name');
            expect(result[0].value).to.equal(42);
        });

        it("should handle different parameter types", async () => {
            // Create test table with various column types
            await queryRunner.query(`
                CREATE TABLE test_types (
                    id INTEGER PRIMARY KEY,
                    text_val VARCHAR,
                    int_val INTEGER,
                    float_val DOUBLE,
                    bool_val BOOLEAN,
                    date_val DATE,
                    time_val TIME,
                    timestamp_val TIMESTAMP
                )
            `);

            const now = new Date();
            const dateStr = now.toISOString().split('T')[0];
            const timeStr = now.toTimeString().split(' ')[0];

            // Insert with different parameter types
            await queryRunner.query(
                `INSERT INTO test_types
                (id, text_val, int_val, float_val, bool_val, date_val, time_val, timestamp_val)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                [1, 'text value', 42, 3.14, true, dateStr, timeStr, now]
            );

            // Query the data
            const result = await queryRunner.query(`SELECT * FROM test_types WHERE id = 1`);

            expect(result).to.have.lengthOf(1);
            expect(result[0].text_val).to.equal('text value');
            expect(result[0].int_val).to.equal(42);
            expect(result[0].float_val).to.equal(3.14);
            expect(result[0].bool_val).to.be.true;
            // Note: Date comparison may need formatting depending on how DuckDB returns dates
        });
    });

    describe("Transaction Support", () => {
        it("should commit transactions", async () => {
            // Create test table
            await queryRunner.query(`
                CREATE TABLE test_transaction (
                    id INTEGER PRIMARY KEY,
                    name VARCHAR
                )
            `);

            // Start a transaction
            await queryRunner.startTransaction();

            try {
                // Execute queries within the transaction
                await queryRunner.query(`
                    INSERT INTO test_transaction (id, name) VALUES (1, 'Test 1')
                `);

                await queryRunner.query(`
                    INSERT INTO test_transaction (id, name) VALUES (2, 'Test 2')
                `);

                // Commit the transaction
                await queryRunner.commitTransaction();

                // Verify data was committed
                const result = await queryRunner.query(`
                    SELECT * FROM test_transaction ORDER BY id
                `);

                expect(result).to.have.lengthOf(2);
                expect(result[0].name).to.equal('Test 1');
                expect(result[1].name).to.equal('Test 2');
            } catch (error) {
                // Rollback in case of error
                await queryRunner.rollbackTransaction();
                throw error;
            }
        });

        it("should rollback transactions", async () => {
            // Create test table
            await queryRunner.query(`
                CREATE TABLE test_transaction (
                    id INTEGER PRIMARY KEY,
                    name VARCHAR
                )
            `);

            // Insert initial data
            await queryRunner.query(`
                INSERT INTO test_transaction (id, name) VALUES (1, 'Initial')
            `);

            // Start a transaction
            await queryRunner.startTransaction();

            // Make changes in the transaction
            await queryRunner.query(`
                UPDATE test_transaction SET name = 'Modified' WHERE id = 1
            `);

            await queryRunner.query(`
                INSERT INTO test_transaction (id, name) VALUES (2, 'New Record')
            `);

            // Rollback the transaction
            await queryRunner.rollbackTransaction();

            // Verify data was not committed
            const result = await queryRunner.query(`
                SELECT * FROM test_transaction
            `);

            expect(result).to.have.lengthOf(1);
            expect(result[0].id).to.equal(1);
            expect(result[0].name).to.equal('Initial');
        });
    });

    describe("Schema Operations", () => {
        it("should get table information", async () => {
            // Create a test table with various column types
            await queryRunner.query(`
                CREATE TABLE test_schema (
                    id INTEGER PRIMARY KEY,
                    name VARCHAR NOT NULL,
                    description TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    is_active BOOLEAN DEFAULT true,
                    count INTEGER DEFAULT 0,
                    price DECIMAL(10, 2)
                )
            `);

            // Use the driver's getTable method
            const table = await queryRunner.getTable("test_schema");

            expect(table).to.exist;
            expect(table!.name).to.equal("test_schema");
            expect(table!.columns).to.have.lengthOf(7);

            // Check column properties
            const idColumn = table!.columns.find(column => column.name === "id");
            expect(idColumn).to.exist;
            expect(idColumn!.isPrimary).to.be.true;

            const nameColumn = table!.columns.find(column => column.name === "name");
            expect(nameColumn).to.exist;
            expect(nameColumn!.isNullable).to.be.false;

            const createdAtColumn = table!.columns.find(column => column.name === "created_at");
            expect(createdAtColumn).to.exist;
            expect(createdAtColumn!.default).to.include("CURRENT_TIMESTAMP");
        });

        it("should create and drop tables", async () => {
            // Create a table schema
            const table = new Table({
                name: "programmatic_table",
                columns: [
                    {
                        name: "id",
                        type: "integer",
                        isPrimary: true,
                        isGenerated: true,
                        generationStrategy: "increment"
                    },
                    {
                        name: "name",
                        type: "varchar",
                        length: "255",
                        isNullable: false
                    },
                    {
                        name: "created_at",
                        type: "timestamp",
                        default: "CURRENT_TIMESTAMP"
                    }
                ]
            });

            // Create the table using the query runner
            await queryRunner.createTable(table);

            // Verify table was created
            let exists = await queryRunner.hasTable("programmatic_table");
            expect(exists).to.be.true;

            // Drop the table
            await queryRunner.dropTable("programmatic_table");

            // Verify table was dropped
            exists = await queryRunner.hasTable("programmatic_table");
            expect(exists).to.be.false;
        });

        it("should add and drop columns", async () => {
            // Create a test table
            await queryRunner.query(`
                CREATE TABLE test_alter (
                    id INTEGER PRIMARY KEY,
                    name VARCHAR
                )
            `);

            // Add a column
            await queryRunner.addColumn("test_alter", {
                name: "email",
                type: "varchar",
                isNullable: true
            });

            // Verify column was added
            let hasColumn = await queryRunner.hasColumn("test_alter", "email");
            expect(hasColumn).to.be.true;

            // Drop the column
            await queryRunner.dropColumn("test_alter", "email");

            // Verify column was dropped
            hasColumn = await queryRunner.hasColumn("test_alter", "email");
            expect(hasColumn).to.be.false;
        });
    });

    describe("DuckDB Specific Features", () => {
        it("should support DuckDB LIST type", async () => {
            // Create a table with a LIST column
            await queryRunner.query(`
                CREATE TABLE test_list (
                    id INTEGER PRIMARY KEY,
                    tags INTEGER[]
                )
            `);

            // Insert data with LIST values
            await queryRunner.query(`
                INSERT INTO test_list VALUES
                (1, [1, 2, 3]),
                (2, [10, 20, 30, 40]),
                (3, NULL)
            `);

            // Query the data
            const result = await queryRunner.query(`
                SELECT id, tags, tags[1] as first_tag FROM test_list ORDER BY id
            `);

            expect(result).to.have.lengthOf(3);
            expect(result[0].tags).to.deep.equal([1, 2, 3]);
            expect(result[0].first_tag).to.equal(1);
            expect(result[1].tags).to.deep.equal([10, 20, 30, 40]);
            expect(result[2].tags).to.be.null;
        });

        it("should support DuckDB MAP type", async () => {
            // Create a table with a MAP column
            await queryRunner.query(`
                CREATE TABLE test_map (
                    id INTEGER PRIMARY KEY,
                    properties MAP(VARCHAR, INTEGER)
                )
            `);

            // Insert data with MAP values
            await queryRunner.query(`
                INSERT INTO test_map VALUES
                (1, MAP(['width', 'height'], [100, 200])),
                (2, MAP(['x', 'y', 'z'], [5, 10, 15])),
                (3, NULL)
            `);

            // Query the data
            const result = await queryRunner.query(`
                SELECT id, properties, properties['width'] as width FROM test_map WHERE id = 1
            `);

            expect(result).to.have.lengthOf(1);
            // The exact format of how DuckDB returns MAP types may vary depending on the driver
            expect(result[0].width).to.equal(100);
        });

        it("should support DuckDB STRUCT type", async () => {
            // Create a table with a STRUCT column
            await queryRunner.query(`
                CREATE TABLE test_struct (
                    id INTEGER PRIMARY KEY,
                    user_info STRUCT(name VARCHAR, age INTEGER)
                )
            `);

            // Insert data with STRUCT values
            await queryRunner.query(`
                INSERT INTO test_struct VALUES
                (1, {'name': 'John', 'age': 30}),
                (2, {'name': 'Jane', 'age': 25}),
                (3, NULL)
            `);

            // Query the data
            const result = await queryRunner.query(`
                SELECT id, user_info, user_info.name, user_info.age FROM test_struct ORDER BY id
            `);

            expect(result).to.have.lengthOf(3);
            expect(result[0]['user_info.name']).to.equal('John');
            expect(result[0]['user_info.age']).to.equal(30);
            expect(result[1]['user_info.name']).to.equal('Jane');
            expect(result[2].user_info).to.be.null;
        });
    });

    describe("Entity Operations", () => {
        it("should save and retrieve entities", async () => {
            // Create a new user entity
            const user = new User();
            user.firstName = "John";
            user.lastName = "Doe";
            user.age = 30;
            user.email = "john@example.com";

            // Save the entity
            await dataSource.manager.save(user);

            // Retrieve the entity
            const retrievedUser = await dataSource.manager.findOneBy(User, { id: user.id });

            expect(retrievedUser).to.exist;
            expect(retrievedUser!.firstName).to.equal("John");
            expect(retrievedUser!.lastName).to.equal("Doe");
            expect(retrievedUser!.age).to.equal(30);
            expect(retrievedUser!.email).to.equal("john@example.com");
        });

        it("should support entity relations", async () => {
            // Create user and categories
            const user = new User();
            user.firstName = "Jane";
            user.lastName = "Smith";
            user.age = 28;
            await dataSource.manager.save(user);

            const category1 = new Category();
            category1.name = "TypeORM";
            category1.description = "Posts about TypeORM";
            await dataSource.manager.save(category1);

            const category2 = new Category();
            category2.name = "DuckDB";
            category2.description = "Posts about DuckDB";
            await dataSource.manager.save(category2);

            // Create post with relations
            const post = new Post();
            post.title = "Using DuckDB with TypeORM";
            post.content = "This is a test post...";
            post.author = user;
            post.categories = [category1, category2];
            await dataSource.manager.save(post);

            // Retrieve post with relations
            const retrievedPost = await dataSource.manager.findOne(Post, {
                where: { id: post.id },
                relations: {
                    author: true,
                    categories: true
                }
            });

            expect(retrievedPost).to.exist;
            expect(retrievedPost!.title).to.equal("Using DuckDB with TypeORM");
            expect(retrievedPost!.author).to.exist;
            expect(retrievedPost!.author.firstName).to.equal("Jane");
            expect(retrievedPost!.categories).to.have.lengthOf(2);
            expect(retrievedPost!.categories[0].name).to.equal("TypeORM");
            expect(retrievedPost!.categories[1].name).to.equal("DuckDB");
        });
    });

    describe("Error Handling", () => {
        it("should handle SQL syntax errors", async () => {
            try {
                await queryRunner.query(`SELECT * FROMM invalid_syntax`);
                // If the query doesn't throw an error, fail the test
                expect.fail("Expected query to throw an error");
            } catch (error) {
                expect(error).to.exist;
                expect(error.message).to.include("syntax");
            }
        });

        it("should handle constraint violations", async () => {
            // Create a table with a primary key
            await queryRunner.query(`
                CREATE TABLE test_constraint (
                    id INTEGER PRIMARY KEY,
                    name VARCHAR
                )
            `);

            // Insert initial data
            await queryRunner.query(`
                INSERT INTO test_constraint (id, name) VALUES (1, 'Test')
            `);

            try {
                // Try to insert a duplicate primary key
                await queryRunner.query(`
                    INSERT INTO test_constraint (id, name) VALUES (1, 'Duplicate')
                `);

                // If the query doesn't throw an error, fail the test
                expect.fail("Expected query to throw a constraint violation error");
            } catch (error) {
                expect(error).to.exist;
                // The exact error message depends on DuckDB's implementation
                expect(error.message).to.include("constraint");
            }
        });
    });
});
