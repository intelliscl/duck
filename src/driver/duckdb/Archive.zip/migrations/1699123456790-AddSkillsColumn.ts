import { MigrationInterface, QueryRunner, TableColumn } from "typeorm";

/**
 * Example migration for DuckDB driver to add skills column
 */
export class AddSkillsColumn1699123456790 implements MigrationInterface {
    public async up(queryRunner: QueryRunner): Promise<void> {
        // Add skills column (simple-array)
        await queryRunner.addColumn("user", new TableColumn({
            name: "skills",
            type: "text",
            isNullable: true
        }));

        // Update existing records with some skills
        await queryRunner.query(`
            UPDATE "user"
            SET "skills" = 'JavaScript,TypeScript,SQL'
            WHERE "firstName" = 'John'
        `);

        await queryRunner.query(`
            UPDATE "user"
            SET "skills" = 'Python,Data Science,TypeScript'
            WHERE "firstName" = 'Jane'
        `);

        // Add additionalInfo column (simple-json)
        await queryRunner.addColumn("user", new TableColumn({
            name: "additionalInfo",
            type: "text",
            isNullable: true
        }));

        // Update existing records with additionalInfo
        await queryRunner.query(`
            UPDATE "user"
            SET "additionalInfo" = '{"department":"Engineering","location":"New York"}'
            WHERE "firstName" = 'John'
        `);

        await queryRunner.query(`
            UPDATE "user"
            SET "additionalInfo" = '{"department":"Data Science","location":"San Francisco"}'
            WHERE "firstName" = 'Jane'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.dropColumn("user", "additionalInfo");
        await queryRunner.dropColumn("user", "skills");
    }
}
