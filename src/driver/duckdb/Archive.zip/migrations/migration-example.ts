import { DataSource } from "typeorm";
import { User } from "./entity/User";

/**
 * Example of using migrations with the DuckDB driver
 */

// Create a DataSource with migrations configuration
const dataSource = new DataSource({
    type: "duckdb",
    database: "migration_database.db",
    entities: [User],
    migrations: [__dirname + "/migrations/*.ts"],
    migrationsTableName: "migrations",
    logging: true
});

async function runMigrations() {
    try {
        // Initialize the connection
        await dataSource.initialize();
        console.log("Connected to DuckDB");

        // Run pending migrations
        const migrations = await dataSource.runMigrations();
        console.log(`Executed ${migrations.length} migrations`);

        // Show migration table
        const migrationTable = await dataSource.manager.query(
            "SELECT * FROM migrations ORDER BY id DESC"
        );
        console.log("Migration history:", migrationTable);

        // Close the connection
        await dataSource.destroy();
        console.log("Connection closed");
    } catch (error) {
        console.error("Error:", error);
    }
}

// Run the function
runMigrations();
