import { MigrationInterface, QueryRunner, Table } from "typeorm";

/**
 * Example migration for DuckDB driver to create User table
 */
export class CreateUserTable1699123456789 implements MigrationInterface {
    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.createTable(new Table({
            name: "user",
            columns: [
                {
                    name: "id",
                    type: "integer",
                    isPrimary: true,
                    isGenerated: true,
                    generationStrategy: "increment"
                },
                {
                    name: "firstName",
                    type: "varchar",
                },
                {
                    name: "lastName",
                    type: "varchar",
                },
                {
                    name: "age",
                    type: "integer",
                },
                {
                    name: "email",
                    type: "varchar",
                    isNullable: true
                },
                {
                    name: "isActive",
                    type: "boolean",
                    default: true
                },
                {
                    name: "createdAt",
                    type: "timestamp",
                    default: "CURRENT_TIMESTAMP"
                }
            ]
        }), true);

        // Add some initial data
        await queryRunner.query(`
            INSERT INTO "user" ("firstName", "lastName", "age", "email")
            VALUES
                ('John', 'Doe', 30, 'john@example.com'),
                ('Jane', 'Smith', 25, 'jane@example.com')
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.dropTable("user");
    }
}
