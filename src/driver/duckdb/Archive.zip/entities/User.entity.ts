import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

/**
 * Example entity for the DuckDB driver
 *
 * This entity demonstrates various column types supported by DuckDB
 */
@Entity()
export class User {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    firstName: string;

    @Column()
    lastName: string;

    @Column()
    age: number;

    @Column({ nullable: true })
    email: string;

    @Column({ type: "boolean", default: true })
    isActive: boolean;

    @Column({ type: "timestamp", default: () => "CURRENT_TIMESTAMP" })
    createdAt: Date;

    @Column({ type: "decimal", precision: 10, scale: 2, nullable: true })
    salary: number;

    @Column({ type: "simple-array", nullable: true })
    skills: string[];

    @Column({ type: "simple-json", nullable: true })
    additionalInfo: { [key: string]: any };
}
