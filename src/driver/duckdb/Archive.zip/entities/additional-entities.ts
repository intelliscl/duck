import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, ManyToMany, JoinTable } from "typeorm";
import { User } from "./User.entity";

/**
 * Post entity for demonstrating relations in DuckDB
 */
@Entity()
export class Post {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    title: string;

    @Column("text")
    content: string;

    @Column({ type: "timestamp", default: () => "CURRENT_TIMESTAMP" })
    createdAt: Date;

    @Column({ type: "simple-json", nullable: true })
    metadata: {
        tags: string[];
        views: number;
        publishedAt: string;
    };

    @ManyToOne(() => User, user => user.posts)
    author: User;

    @ManyToMany(() => Category)
    @JoinTable()
    categories: Category[];
}

/**
 * Category entity for demonstrating many-to-many relations
 */
@Entity()
export class Category {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name: string;

    @Column("text", { nullable: true })
    description: string;
}

// Update the User entity to include posts relation
import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm";
import { Post } from "./Post";

@Entity()
export class User {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    firstName: string;

    @Column()
    lastName: string;

    @Column()
    age: number;

    @Column({ nullable: true })
    email: string;

    @Column({ type: "boolean", default: true })
    isActive: boolean;

    @Column({ type: "timestamp", default: () => "CURRENT_TIMESTAMP" })
    createdAt: Date;

    @Column({ type: "decimal", precision: 10, scale: 2, nullable: true })
    salary: number;

    @Column({ type: "simple-array", nullable: true })
    skills: string[];

    @Column({ type: "simple-json", nullable: true })
    additionalInfo: { [key: string]: any };

    @OneToMany(() => Post, post => post.author)
    posts: Post[];
}
