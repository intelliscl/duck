import { DataSource } from "typeorm";
import { User } from "./entity/User";
import { Post } from "./entity/Post";
import { Category } from "./entity/Category";

/**
 * Advanced example for DuckDB driver usage with TypeORM
 *
 * This example demonstrates:
 * 1. Working with relations
 * 2. Using nested types specific to DuckDB
 * 3. Using query runner for transactions and schema changes
 * 4. Advanced querying capabilities
 */

// Create a connection
const dataSource = new DataSource({
    type: "duckdb",
    database: "advanced_database.db",
    entities: [User, Post, Category],
    synchronize: true,
    logging: true,
    duckdbConfig: {
        memory_limit: "1GB"
    }
});

async function main() {
    try {
        // Initialize the connection
        await dataSource.initialize();
        console.log("Connected to DuckDB");

        // Using QueryRunner for more complex operations
        const queryRunner = dataSource.createQueryRunner();
        await queryRunner.connect();

        // Start a transaction
        await queryRunner.startTransaction();

        try {
            // Create a user
            const user = new User();
            user.firstName = "Alice";
            user.lastName = "Johnson";
            user.age = 32;
            user.email = "alice@example.com";
            user.skills = ["TypeScript", "Node.js", "SQL"];
            user.additionalInfo = {
                address: "123 Main St",
                department: "Engineering"
            };

            await queryRunner.manager.save(user);

            // Create some categories
            const category1 = new Category();
            category1.name = "TypeORM";
            category1.description = "Posts about TypeORM";

            const category2 = new Category();
            category2.name = "DuckDB";
            category2.description = "Posts about DuckDB";

            await queryRunner.manager.save([category1, category2]);

            // Create a post with relations
            const post = new Post();
            post.title = "Using DuckDB with TypeORM";
            post.content = "This is a post about using DuckDB with TypeORM...";
            post.author = user;
            post.categories = [category1, category2];
            post.metadata = {
                tags: ["database", "typescript", "orm"],
                views: 0,
                publishedAt: new Date().toISOString()
            };

            await queryRunner.manager.save(post);

            // Commit the transaction
            await queryRunner.commitTransaction();
            console.log("Transaction committed successfully");
        } catch (error) {
            // Rollback the transaction in case of error
            await queryRunner.rollbackTransaction();
            console.error("Transaction failed:", error);
        } finally {
            // Release the query runner
            await queryRunner.release();
        }

        // Using native DuckDB features with LIST and structured types
        await dataSource.manager.query(`
            CREATE OR REPLACE TABLE analytics (
                user_id INTEGER,
                visit_dates TIMESTAMP[],
                page_views MAP(VARCHAR, INTEGER),
                user_agent STRUCT(browser VARCHAR, os VARCHAR, version VARCHAR)
            )
        `);

        await dataSource.manager.query(`
            INSERT INTO analytics VALUES (
                1,
                [TIMESTAMP '2023-01-01 10:00:00', TIMESTAMP '2023-01-02 14:30:00'],
                MAP(['home', 'profile', 'settings'], [10, 5, 2]),
                {'browser': 'Chrome', 'os': 'Windows', 'version': '108.0.5359.125'}
            )
        `);

        const analyticsResult = await dataSource.manager.query(`
            SELECT
                user_id,
                visit_dates,
                page_views['home'] as home_views,
                user_agent.browser
            FROM analytics
        `);

        console.log("Analytics with complex types:", analyticsResult);

        // Find posts with relations
        const posts = await dataSource.manager.find(Post, {
            relations: {
                author: true,
                categories: true
            }
        });

        console.log("Posts with relations:", JSON.stringify(posts, null, 2));

        // Complex query using query builder
        const result = await dataSource.createQueryBuilder()
            .select("user")
            .from(User, "user")
            .leftJoinAndSelect("user.posts", "posts")
            .where("user.age > :age", { age: 30 })
            .andWhere("posts.title LIKE :title", { title: "%DuckDB%" })
            .orderBy("user.firstName", "ASC")
            .getMany();

        console.log("Complex query result:", result);

        // Close the connection
        await dataSource.destroy();
        console.log("Connection closed");
    } catch (error) {
        console.error("Error:", error);
    }
}

main();
