import { DataSource } from "typeorm";
import { User } from "./entity/User";

/**
 * Example of setting up a DuckDB connection using TypeORM
 *
 * This example demonstrates:
 * 1. Creating a connection to DuckDB
 * 2. Setting common options for DuckDB
 * 3. Creating and using an entity
 */

// Create a new DataSource with DuckDB
const dataSource = new DataSource({
    type: "duckdb",
    database: "mydatabase.db", // Use ":memory:" for in-memory database
    entities: [User],
    synchronize: true,
    logging: true,
    // DuckDB specific options
    accessMode: "read_write", // Optional: "read_only" or "read_write"
    duckdbConfig: {
        memory_limit: "512MB", // Optional: Set DuckDB memory limit
        threads: "4" // Optional: Set number of threads
    },
    // Optional: Function to be executed before using the database
    prepareDatabase: (db) => {
        // Here you can set pragma settings or execute other setup SQL
        console.log("Preparing database:", db);
    }
});

async function main() {
    try {
        // Initialize the connection
        await dataSource.initialize();
        console.log("Connected to DuckDB");

        // Create a new user
        const user = new User();
        user.firstName = "John";
        user.lastName = "Doe";
        user.age = 30;

        // Save the user
        await dataSource.manager.save(user);
        console.log("User saved:", user);

        // Find all users
        const users = await dataSource.manager.find(User);
        console.log("All users:", users);

        // Use QueryBuilder
        const result = await dataSource.createQueryBuilder()
            .select("user")
            .from(User, "user")
            .where("user.age > :age", { age: 25 })
            .getMany();
        console.log("Users older than 25:", result);

        // Raw SQL example
        const rawResult = await dataSource.manager.query("SELECT * FROM user WHERE age = ?", [30]);
        console.log("Raw query result:", rawResult);

        // Use transaction
        await dataSource.manager.transaction(async (transactionalEntityManager) => {
            const newUser = new User();
            newUser.firstName = "Jane";
            newUser.lastName = "Smith";
            newUser.age = 28;

            await transactionalEntityManager.save(newUser);
            console.log("User saved in transaction:", newUser);
        });

        // Close the connection
        await dataSource.destroy();
        console.log("Connection closed");
    } catch (error) {
        console.error("Error:", error);
    }
}

main();
