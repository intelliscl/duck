# DuckDB Driver for TypeORM

This is a custom DuckDB driver implementation for TypeORM. DuckDB is an in-process SQL OLAP database management system focused on analytical queries. This driver enables using DuckDB with TypeORM, allowing you to leverage the power of both tools together.

## Features

- Full support for TypeORM functionality with DuckDB
- Support for DuckDB's specialized data types (LIST, MAP, STRUCT, etc.)
- Transaction support
- Schema creation and synchronization
- Entity-based data modeling
- Query builder integration
- Raw SQL execution

## Installation

1. Install TypeORM and the DuckDB driver:

```bash
npm install typeorm @duckdb/node-api
```

or for older DuckDB clients:

```bash
npm install typeorm duckdb
```

2. Copy the DuckDB driver files into your project or reference them from where they're located.

## Usage

### Basic Connection Setup

```typescript
import { DataSource } from "typeorm";
import { User } from "./entity/User";

const dataSource = new DataSource({
    type: "duckdb",
    database: "mydatabase.db", // or ":memory:" for in-memory database
    entities: [User],
    synchronize: true,
    logging: true
});

// Initialize the connection
await dataSource.initialize();
```

### Configuration Options

The DuckDB driver supports several DuckDB-specific options:

```typescript
const dataSource = new DataSource({
    type: "duckdb",
    database: "mydatabase.db",
    entities: [User],
    synchronize: true,
    logging: true,
    // DuckDB specific options
    accessMode: "read_write", // "read_only" or "read_write"
    duckdbConfig: {
        memory_limit: "512MB", // Set DuckDB memory limit
        threads: "4"           // Set number of threads
        // Any other DuckDB config options
    },
    // Function to execute before using the database
    prepareDatabase: (db) => {
        // Here you can set pragma settings or execute other setup SQL
    }
});
```

### Working with Entities

Define your entities just like with any other TypeORM driver:

```typescript
import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export class User {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    firstName: string;

    @Column()
    lastName: string;

    @Column()
    age: number;

    @Column({ type: "boolean", default: true })
    isActive: boolean;

    @Column({ type: "timestamp", default: () => "CURRENT_TIMESTAMP" })
    createdAt: Date;
}
```

### Working with DuckDB-specific Types

DuckDB offers specialized types like LIST, MAP, STRUCT, and UNION that can be used with raw SQL:

```typescript
// Create a table with DuckDB complex types
await dataSource.manager.query(`
    CREATE OR REPLACE TABLE analytics (
        user_id INTEGER,
        visit_dates TIMESTAMP[],  -- ARRAY type
        page_views MAP(VARCHAR, INTEGER),  -- MAP type
        user_agent STRUCT(browser VARCHAR, os VARCHAR)  -- STRUCT type
    )
`);

// Insert data with complex types
await dataSource.manager.query(`
    INSERT INTO analytics VALUES (
        1,
        [TIMESTAMP '2023-01-01', TIMESTAMP '2023-01-02'],
        MAP(['home', 'profile'], [10, 5]),
        {'browser': 'Chrome', 'os': 'Windows'}
    )
`);
```

### Transactions

The driver supports transactions similar to other TypeORM drivers:

```typescript
// Using transaction manager
await dataSource.manager.transaction(async (transactionalEntityManager) => {
    const user = new User();
    user.firstName = "John";
    user.lastName = "Doe";
    user.age = 30;

    await transactionalEntityManager.save(user);
});

// Using query runner
const queryRunner = dataSource.createQueryRunner();
await queryRunner.connect();
await queryRunner.startTransaction();

try {
    const user = new User();
    user.firstName = "Jane";
    user.lastName = "Smith";
    user.age = 25;

    await queryRunner.manager.save(user);
    await queryRunner.commitTransaction();
} catch (error) {
    await queryRunner.rollbackTransaction();
    throw error;
} finally {
    await queryRunner.release();
}
```

## Limitations

- DuckDB doesn't support certain SQL features found in other databases, like stored procedures or certain constraint types.
- Some schema modification operations (ALTER TABLE) in DuckDB may have limitations compared to other database systems.
- Performance characteristics differ from traditional OLTP databases, as DuckDB is optimized for analytical queries.

## Contributing

Feel free to contribute to this driver by submitting issues or pull requests for improvements, bug fixes, or additional features.

## License

This driver is released under the same license as TypeORM.
