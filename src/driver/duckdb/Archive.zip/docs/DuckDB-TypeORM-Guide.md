# DuckDB Driver for TypeORM: Comprehensive Guide

## Introduction

DuckDB is an in-process analytical database management system focused on analytical queries, similar to SQLite but optimized for OLAP workflows rather than OLTP. This guide covers how to use the DuckDB driver with TypeORM for powerful analytics and data processing capabilities.

## Table of Contents

1. [Installation](#installation)
2. [Connection Setup](#connection-setup)
3. [Connection Options](#connection-options)
4. [Working with Entities](#working-with-entities)
5. [TypeORM CRUD Operations](#typeorm-crud-operations)
6. [Transactions](#transactions)
7. [Migrations](#migrations)
8. [Advanced DuckDB Features](#advanced-duckdb-features)
9. [Performance Optimization](#performance-optimization)
10. [Limitations and Considerations](#limitations-and-considerations)
11. [Troubleshooting](#troubleshooting)

## Installation

First, install TypeORM and DuckDB:

```bash
# Install TypeORM
npm install typeorm reflect-metadata

# Install DuckDB - different options based on your needs:
# Option 1: Modern DuckDB Node.js API (recommended)
npm install @duckdb/node-api

# Option 2: Alternative clients
npm install duckdb-async
# OR
npm install duckdb
```

### TypeScript Configuration

Ensure your `tsconfig.json` has the necessary options:

```json
{
  "compilerOptions": {
    "experimentalDecorators": true,
    "emitDecoratorMetadata": true,
    "esModuleInterop": true
  }
}
```

## Connection Setup

### Basic Connection

```typescript
import "reflect-metadata";
import { DataSource } from "typeorm";
import { User } from "./entity/User";

// Create a DuckDB DataSource
const dataSource = new DataSource({
    type: "duckdb",
    database: "mydatabase.db", // file path or ":memory:" for in-memory database
    entities: [User],
    synchronize: true,
    logging: true
});

// Initialize connection
await dataSource.initialize();
console.log("Connected to DuckDB");
```

### ESM Module Setup

```typescript
import { DataSource } from "typeorm";
import { User } from "./entity/User.js";

const dataSource = new DataSource({
    type: "duckdb",
    database: ":memory:",
    entities: [User],
    synchronize: true
});

export default dataSource;
```

## Connection Options

DuckDB driver supports a variety of options:

```typescript
const dataSource = new DataSource({
    // Standard TypeORM options
    type: "duckdb",
    database: "analytical_db.db", // File path or ":memory:"
    entities: [/* entity classes */],
    synchronize: true, // Auto-create schema (dev only)
    logging: true,

    // DuckDB-specific options
    accessMode: "read_write", // "read_only" or "read_write"

    // DuckDB configuration parameters
    duckdbConfig: {
        memory_limit: "4GB", // Memory limit
        threads: "4", // Thread count
        default_order: "DESC", // Default ordering
        null_order: "NULLS_FIRST" // NULL ordering
        // ... other DuckDB config options
    },

    // Function to run before using the database
    prepareDatabase: (db) => {
        // Set up extensions, pragmas, or other configuration
        console.log("Preparing database:", db);
    },

    // Foreign key constraint enforcement
    foreignKeys: true,

    // Optional path to the native module
    nativeBinding: "/path/to/custom/duckdb_module.node"
});
```

## Working with Entities

Entities in TypeORM with DuckDB work similar to other database drivers:

```typescript
import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export class User {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    firstName: string;

    @Column()
    lastName: string;

    @Column()
    age: number;

    @Column({ type: "boolean", default: true })
    isActive: boolean;

    @Column({ type: "timestamp", default: () => "CURRENT_TIMESTAMP" })
    createdAt: Date;

    @Column({ type: "simple-array", nullable: true })
    skills: string[];

    @Column({ type: "simple-json", nullable: true })
    metadata: { [key: string]: any };
}
```

### DuckDB Type Mapping

| TypeORM Type       | DuckDB Type        | Notes                               |
|--------------------|--------------------|------------------------------------|
| `boolean`          | `BOOLEAN`          |                                    |
| `int`, `integer`   | `INTEGER`          |                                    |
| `smallint`         | `SMALLINT`         |                                    |
| `bigint`           | `BIGINT`           |                                    |
| `float`            | `FLOAT`            |                                    |
| `double`           | `DOUBLE`           |                                    |
| `decimal`          | `DECIMAL(p,s)`     | With precision and scale           |
| `varchar`, `string`| `VARCHAR`          |                                    |
| `text`             | `TEXT`             |                                    |
| `date`             | `DATE`             |                                    |
| `time`             | `TIME`             |                                    |
| `timestamp`        | `TIMESTAMP`        |                                    |
| `json`             | `JSON`             | Special handling for JSON data     |
| `simple-array`     | `TEXT`             | Stores comma-separated values      |
| `simple-json`      | `TEXT`             | Stores JSON as string              |
| `uuid`             | `UUID`             |                                    |
| `blob`             | `BLOB`             | Binary data                        |

### Special DuckDB Types

DuckDB has unique data types that can be used with raw SQL:

```typescript
// Create a table with DuckDB-specific types
await dataSource.query(`
    CREATE TABLE analytics (
        id INTEGER PRIMARY KEY,
        tags VARCHAR[],                           -- Array type
        page_views MAP(VARCHAR, INTEGER),         -- Map type
        user_agent STRUCT(browser VARCHAR, os VARCHAR), -- Struct type
        user_data UNION(name VARCHAR, id INTEGER) -- Union type
    )
`);

// Insert data with complex types
await dataSource.query(`
    INSERT INTO analytics VALUES (
        1,
        ['tag1', 'tag2', 'tag3'],
        MAP(['home', 'profile'], [10, 5]),
        {'browser': 'Chrome', 'os': 'Windows'},
        union_value(name := 'John')
    )
`);
```

## TypeORM CRUD Operations

### Creating Records

```typescript
// Create a new user
const user = new User();
user.firstName = "John";
user.lastName = "Doe";
user.age = 30;
user.skills = ["TypeScript", "SQL", "Node.js"];
user.metadata = {
    department: "Engineering",
    location: "Remote"
};

// Save to database
await dataSource.manager.save(user);
```

### Reading Records

```typescript
// Find all users
const allUsers = await dataSource.manager.find(User);

// Find with conditions
const youngUsers = await dataSource.manager.find(User, {
    where: { age: LessThan(30) }
});

// Find one specific record
const user = await dataSource.manager.findOneBy(User, { id: 1 });

// Find with relations
const userWithPosts = await dataSource.manager.findOne(User, {
    where: { id: 1 },
    relations: {
        posts: true,
        posts: {
            categories: true
        }
    }
});

// Use QueryBuilder for complex queries
const engineers = await dataSource
    .createQueryBuilder()
    .select("user")
    .from(User, "user")
    .where("user.metadata->>'department' = :dept", { dept: "Engineering" })
    .andWhere("user.age > :age", { age: 25 })
    .orderBy("user.firstName", "ASC")
    .getMany();
```

### Updating Records

```typescript
// Method 1: Find then update
const user = await dataSource.manager.findOneBy(User, { id: 1 });
if (user) {
    user.age = 31;
    user.skills = [...user.skills, "DuckDB"];
    await dataSource.manager.save(user);
}

// Method 2: Update directly
await dataSource.manager.update(User, { id: 1 }, {
    age: 31,
    isActive: false
});

// Method 3: Use QueryBuilder
await dataSource
    .createQueryBuilder()
    .update(User)
    .set({ isActive: false })
    .where("age > :age", { age: 40 })
    .execute();
```

### Deleting Records

```typescript
// Method 1: Find then remove
const user = await dataSource.manager.findOneBy(User, { id: 1 });
if (user) {
    await dataSource.manager.remove(user);
}

// Method 2: Delete directly
await dataSource.manager.delete(User, { id: 1 });

// Method 3: Use QueryBuilder
await dataSource
    .createQueryBuilder()
    .delete()
    .from(User)
    .where("isActive = :active", { active: false })
    .execute();
```

### Raw Queries

```typescript
// Execute raw SQL
const users = await dataSource.manager.query(`
    SELECT * FROM user WHERE age > ? AND isActive = ?
`, [25, true]);

// Complex analytical query with DuckDB features
const analytics = await dataSource.manager.query(`
    SELECT
        date_trunc('month', createdAt) as month,
        COUNT(*) as count,
        AVG(age) as avg_age,
        ARRAY_AGG(DISTINCT firstName) as unique_names
    FROM user
    GROUP BY month
    ORDER BY month DESC
`);
```

## Transactions

DuckDB supports transactions for ensuring data consistency:

### Using Transaction Manager

```typescript
await dataSource.manager.transaction(async (transactionalEntityManager) => {
    // All operations inside this callback are part of the same transaction

    // Create a user
    const user = new User();
    user.firstName = "Alice";
    user.lastName = "Johnson";
    user.age = 28;
    await transactionalEntityManager.save(user);

    // Create a related post
    const post = new Post();
    post.title = "DuckDB Transaction Example";
    post.content = "Content of the post...";
    post.author = user;
    await transactionalEntityManager.save(post);

    // If any operation fails, all changes will be rolled back
});
```

### Using QueryRunner

```typescript
// Get a query runner
const queryRunner = dataSource.createQueryRunner();

// Establish real database connection
await queryRunner.connect();

// Start transaction
await queryRunner.startTransaction();

try {
    // Execute operations
    const user = new User();
    user.firstName = "Bob";
    user.lastName = "Smith";
    user.age = 35;

    await queryRunner.manager.save(user);

    // Simulate some condition that might fail
    if (user.age > 30) {
        const post = new Post();
        post.title = "DuckDB is Amazing";
        post.content = "Let me tell you why...";
        post.author = user;

        await queryRunner.manager.save(post);
    }

    // Commit transaction
    await queryRunner.commitTransaction();
} catch (err) {
    // Rollback transaction on error
    await queryRunner.rollbackTransaction();
    throw err;
} finally {
    // Release query runner
    await queryRunner.release();
}
```

## Migrations

DuckDB supports database migrations for schema evolution:

### Setting Up Migrations

```typescript
// In your TypeORM configuration
const dataSource = new DataSource({
    type: "duckdb",
    database: "production.db",
    entities: [User, Post, Category],
    migrations: ["migrations/*.ts"],
    migrationsTableName: "typeorm_migrations",
    logging: true
});
```

### Creating a Migration

You can generate migrations automatically:

```bash
npx typeorm migration:generate -d path/to/datasource.ts -n CreateUserTable
```

Or create them manually:

```typescript
// migrations/1699123456789-CreateUserTable.ts
import { MigrationInterface, QueryRunner, Table } from "typeorm";

export class CreateUserTable1699123456789 implements MigrationInterface {
    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.createTable(new Table({
            name: "user",
            columns: [
                {
                    name: "id",
                    type: "integer",
                    isPrimary: true,
                    isGenerated: true,
                    generationStrategy: "increment"
                },
                {
                    name: "firstName",
                    type: "varchar",
                },
                {
                    name: "lastName",
                    type: "varchar",
                },
                {
                    name: "age",
                    type: "integer",
                },
                {
                    name: "isActive",
                    type: "boolean",
                    default: true
                }
            ]
        }), true);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.dropTable("user");
    }
}
```

### Running Migrations

```typescript
// Run pending migrations
await dataSource.runMigrations();

// Revert the last migration
await dataSource.undoLastMigration();
```

## Advanced DuckDB Features

DuckDB provides powerful analytical capabilities that can be leveraged with TypeORM:

### Complex Analytical Queries

```typescript
// Analytical query with window functions
const results = await dataSource.manager.query(`
    SELECT
        u.firstName,
        u.lastName,
        COUNT(p.id) as post_count,
        ROW_NUMBER() OVER (ORDER BY COUNT(p.id) DESC) as rank
    FROM user u
    LEFT JOIN post p ON p.authorId = u.id
    GROUP BY u.id, u.firstName, u.lastName
    QUALIFY rank <= 5  -- DuckDB-specific: filter after window functions
`);

// Using DuckDB's table-producing functions
const stats = await dataSource.manager.query(`
    SELECT
        generate_series as month,
        (SELECT COUNT(*) FROM user WHERE EXTRACT(MONTH FROM createdAt) = generate_series) as new_users
    FROM generate_series(1, 12)
`);
```

### Working with CSV and Other File Formats

DuckDB excels at querying external data directly:

```typescript
// Register a CSV file as a virtual table
await dataSource.manager.query(`
    CREATE VIEW external_sales AS
    SELECT * FROM read_csv_auto('/path/to/sales_data.csv');
`);

// Join external data with database tables
const results = await dataSource.manager.query(`
    SELECT
        u.firstName,
        u.lastName,
        e.revenue,
        e.region
    FROM user u
    JOIN external_sales e ON u.externalId = e.user_id
    WHERE e.revenue > 1000
    ORDER BY e.revenue DESC
`);

// Export query results to CSV
await dataSource.manager.query(`
    COPY (
        SELECT u.id, u.firstName, u.lastName, COUNT(p.id) as postCount
        FROM user u
        LEFT JOIN post p ON p.authorId = u.id
        GROUP BY u.id, u.firstName, u.lastName
    ) TO '/path/to/output.csv' (HEADER);
`);
```

### Using Extensions

DuckDB has a powerful extension system:

```typescript
// Load the spatial extension for GIS functionality
await dataSource.manager.query(`INSTALL spatial; LOAD spatial;`);

// Use spatial functions
const spatialResults = await dataSource.manager.query(`
    SELECT
        id,
        firstName,
        ST_Point(latitude, longitude) as location,
        ST_Distance(ST_Point(latitude, longitude), ST_Point(40.7128, -74.0060)) as distance_from_nyc
    FROM user
    ORDER BY distance_from_nyc ASC
    LIMIT 10
`);

// Load JSON extension
await dataSource.manager.query(`INSTALL json; LOAD json;`);

// Use JSON functions
const jsonResults = await dataSource.manager.query(`
    SELECT
        id,
        firstName,
        json_extract(metadata, '$.department') as department
    FROM user
    WHERE json_extract(metadata, '$.location') = 'New York'
`);
```

## Performance Optimization

DuckDB is designed for analytical performance:

### Query Optimization

```typescript
// Enable profiling to analyze query performance
await dataSource.manager.query(`SET enable_profiling=true;`);
await dataSource.manager.query(`SET profiling_output='query_profile.json';`);

// Run a complex query
const result = await dataSource.manager.query(`
    SELECT /* your complex query */
`);

// Analyze the profile
const profile = await dataSource.manager.query(`SELECT * FROM pragma_last_profiling_output()`);
console.log(profile);
```

### Parallel Query Execution

```typescript
// Set thread count for parallel execution
await dataSource.manager.query(`SET threads=8;`);

// Query that will utilize parallel execution
const results = await dataSource.manager.query(`
    SELECT
        date_trunc('day', createdAt) as day,
        COUNT(*) as count
    FROM large_event_log
    GROUP BY day
    ORDER BY day
`);
```

### Batch Inserts for Performance

```typescript
// Create a prepared statement for bulk insert
const queryRunner = dataSource.createQueryRunner();
await queryRunner.connect();

try {
    // Start a transaction for better performance
    await queryRunner.startTransaction();

    // Prepare data
    const users = Array.from({ length: 10000 }, (_, i) => ({
        firstName: `User${i}`,
        lastName: `Lastname${i}`,
        age: 20 + (i % 50),
        isActive: i % 2 === 0
    }));

    // Batch insert using a single query with multiple values
    const valuePlaceholders = users.map(() => "(?, ?, ?, ?)").join(", ");
    const valueParams = users.flatMap(u => [u.firstName, u.lastName, u.age, u.isActive]);

    await queryRunner.query(`
        INSERT INTO user (firstName, lastName, age, isActive)
        VALUES ${valuePlaceholders}
    `, valueParams);

    // Commit transaction
    await queryRunner.commitTransaction();
} catch (err) {
    await queryRunner.rollbackTransaction();
    throw err;
} finally {
    await queryRunner.release();
}
```

## Limitations and Considerations

When using the DuckDB driver with TypeORM, be aware of these limitations:

### Database-Specific Constraints

- DuckDB is optimized for analytical queries (OLAP), not transactional workloads (OLTP)
- Concurrency is limited compared to client-server databases
- Some TypeORM features might behave differently due to DuckDB's design

### Schema Manipulation

Some schema operations that work differently with DuckDB:

- Adding/dropping constraints may require table recreation
- Certain schema changes might not be supported directly and require workarounds
- Check if DuckDB syntax differs for your specific schema modifications

### Production Usage

Considerations for production:

- DuckDB files can be used concurrently, but with limited writer connections
- For web applications, consider connection pooling carefully
- Backup strategies should be implemented for data durability
- Monitor memory usage as DuckDB operates in-process

## Troubleshooting

### Common Issues

#### Connection Problems

```
Error: Unable to open database file
```

- Verify the database path is correct and accessible
- Check file permissions
- Ensure the directory exists

#### Type Conversion Issues

```
Error: Invalid input for type X
```

- Verify the data type mappings between TypeORM and DuckDB
- Use explicit type casting in queries when necessary
- Check for NULL values causing conversion errors

#### Performance Issues

- Use DuckDB's EXPLAIN statement to analyze query plans
- Consider creating appropriate indexes for frequently queried columns
- Monitor memory usage and adjust configuration if needed
- Use batch operations for bulk data processing

#### Schema Synchronization Errors

- If `synchronize: true` is causing issues, try using migrations instead
- Review entity definitions for DuckDB compatibility
- Some complex relational patterns might need manual handling

### Getting Help

- Check the DuckDB documentation: https://duckdb.org/docs/
- TypeORM GitHub issues: https://github.com/typeorm/typeorm/issues
- DuckDB GitHub issues: https://github.com/duckdb/duckdb/issues

---

With this comprehensive guide, you should be able to effectively use DuckDB with TypeORM for building powerful analytical applications. The combination provides the developer-friendly ORM capabilities of TypeORM with the analytical performance of DuckDB.
